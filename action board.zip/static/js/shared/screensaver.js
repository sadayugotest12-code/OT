(() => {
  const IDLE_DELAY = 60 * 1000;
  const PAGE_DELAY = 5 * 1000;
  const TRANSITION_DELAY = 450;
  const ACTIVE_KEY = "actionBoardScreensaverActive";
  const routes = [
    "/",
    "/oneday_flow",
    "/status",
    "/personal",
    "/bodycheck",
    "/pm_year",
    "/pm_month",
    "/summary_monthly",
    "/summary_yearly",
    "/exercise",
    "/5s",
    "/action_board"
  ];

  let idleTimer;
  let pageTimer;
  let transitionTimer;

  const transitionStyle = document.createElement("style");
  transitionStyle.textContent = `
    @keyframes screensaverEnter {
      from { opacity: 0; transform: translateX(32px); }
      to { opacity: 1; transform: translateX(0); }
    }
    @keyframes screensaverExit {
      from { opacity: 1; transform: translateX(0); }
      to { opacity: 0; transform: translateX(-32px); }
    }
    body.screensaver-enter {
      animation: screensaverEnter ${TRANSITION_DELAY}ms ease-out both;
    }
    body.screensaver-exit {
      animation: screensaverExit ${TRANSITION_DELAY}ms ease-in both;
      pointer-events: none;
    }
    @media (prefers-reduced-motion: reduce) {
      body.screensaver-enter,
      body.screensaver-exit { animation: none; }
    }
  `;
  document.head.appendChild(transitionStyle);

  function canonicalPath(pathname) {
    if (/^\/statusmt[123]$/.test(pathname) || pathname === "/statusut") {
      return "/status";
    }
    return pathname;
  }

  function nextRoute() {
    const currentPath = canonicalPath(window.location.pathname);
    const currentIndex = routes.indexOf(currentPath);
    return routes[(currentIndex + 1) % routes.length];
  }

  function clearPageTimer() {
    window.clearTimeout(pageTimer);
    window.clearTimeout(transitionTimer);
  }

  function scheduleNextPage() {
    clearPageTimer();
    pageTimer = window.setTimeout(() => {
      document.body.classList.add("screensaver-exit");
      transitionTimer = window.setTimeout(() => {
        window.location.assign(nextRoute());
      }, TRANSITION_DELAY);
    }, PAGE_DELAY);
  }

  function stopScreensaver() {
    window.sessionStorage.removeItem(ACTIVE_KEY);
    clearPageTimer();
  }

  function resetIdleTimer() {
    stopScreensaver();
    window.clearTimeout(idleTimer);
    idleTimer = window.setTimeout(() => {
      window.sessionStorage.setItem(ACTIVE_KEY, "true");
      scheduleNextPage();
    }, IDLE_DELAY);
  }

  function handleActivity() {
    if (window.sessionStorage.getItem(ACTIVE_KEY) === "true") {
      stopScreensaver();
      if (window.location.pathname !== "/") {
        window.location.assign("/");
      }
      return;
    }
    resetIdleTimer();
  }

  ["mousemove", "mousedown", "keydown", "touchstart", "wheel"].forEach((eventName) => {
    document.addEventListener(eventName, handleActivity, { passive: true });
  });

  if (window.sessionStorage.getItem(ACTIVE_KEY) === "true") {
    document.body.classList.add("screensaver-enter");
    scheduleNextPage();
  } else {
    resetIdleTimer();
  }
})();
