const VALID_FACTORIES = ["mt1", "mt2", "mt3", "ut"];
let factory = VALID_FACTORIES.includes(document.body.dataset.factory)
    ? document.body.dataset.factory
    : "mt1";

async function changeFactory(newFactory){
    if (!VALID_FACTORIES.includes(newFactory) || newFactory === factory) return;

    factory = newFactory;

    updateFactoryTabs();

    await loadEmployees();
}

function updateFactoryTabs() {
    document.querySelectorAll(".factory-buttons button").forEach(button => {
        const isActive = button.dataset.factory === factory;
        button.classList.toggle("active", isActive);
        button.setAttribute("aria-pressed", String(isActive));
    });
}

   
const fsBtn = document.getElementById("fsBtn");

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
    fsBtn.textContent = "ออกจากเต็มจอ";
  } else {
    document.exitFullscreen();
    fsBtn.textContent = "แตะเพื่อแสดงเต็มจอ";
  }
}

fsBtn.addEventListener("click", toggleFullscreen);


const monthNames = [
    "January","February","March","April","May","June",
    "July","August","September","October","November","December"
];

let employees = [];

async function loadEmployees() {
    const tbody = document.querySelector("#attTable tbody");
    tbody.innerHTML = '<tr><td colspan="3">กำลังโหลดข้อมูล...</td></tr>';

    try {
        const response = await fetch(`/api/employees?factory=${encodeURIComponent(factory)}`);
        if (!response.ok) throw new Error(`โหลดรายชื่อไม่สำเร็จ (${response.status})`);
        const data = await response.json();

        employees = data.map(emp => ({
        code: emp.emp_code,
        name: emp.emp_name || emp.emp_code,
        position: emp.position || ""

    }));

        loadTable(monthSel.value, yearSel.value);
    } catch (error) {
        console.error(error);
        tbody.innerHTML = '<tr><td colspan="3">ไม่สามารถโหลดข้อมูลได้</td></tr>';
    }

}

function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        "'": "&#39;",
        '"': "&quot;"
    }[character]));
}

function daysInMonth(month, year) {
    return new Date(year, month, 0).getDate();
}

function loadTable(month, year) {
    const tbody = document.querySelector("#attTable tbody");
    const header = document.getElementById("headerRow");
    const title = document.getElementById("titleMonth");

    title.innerText = `Attendance Exercise Activity for ${monthNames[month-1]} ${year}`;

    tbody.innerHTML = "";
    header.innerHTML = "<th>No.</th><th>Name</th><th>Position</th>";

    const days = daysInMonth(month, year);
    for (let d = 1; d <= days; d++) {
        header.innerHTML += `<th>${d}</th>`;
    }

    employees.forEach((emp, i) => {

    let row = `<tr>
        <td>${i + 1}</td>
        <td>${escapeHtml(emp.name)}</td>
        <td>${escapeHtml(emp.position)}</td>`;

    for (let d = 1; d <= days; d++) {

        row += `<td class="cell"
                data-code="${escapeHtml(emp.code)}"
                data-name="${escapeHtml(emp.name)}"
                data-position="${escapeHtml(emp.position)}"
                data-day="${d}">
            </td>`;

    }

    row += "</tr>";
    tbody.innerHTML += row;

});


    document.querySelectorAll(".cell").forEach(cell => {
    cell.innerText = "";
    cell.className = "cell";
});


    // ⭐⭐ จุดสำคัญมาก
    loadSavedData(month, year);
}

/* สลับสถานะในเซลล์ */
function toggle(cell) {

    if (cell.innerText === "") {
        cell.innerText = "✓";
        cell.className = "cell check";

    } else if (cell.innerText === "✓") {
        cell.innerText = "X";
        cell.className = "cell cross";

    } else {
        cell.innerText = "";
        cell.className = "cell";
    }

    const empCode = cell.dataset.code;
    const empName = cell.dataset.name;
    const position = cell.dataset.position;
    const day = cell.dataset.day;
    const year = yearSel.value;
    const month = monthSel.value;

    const dateStr =
        `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;

    if (cell.innerText === "") {

        fetch("/api/delete_exercise", {
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body: JSON.stringify({

            factory: factory,
            emp_code: empCode,
            emp_name: empName,
            position: position,
            exercise_date: dateStr,
            status: cell.innerText

            })
        }).then(response => {
            if (!response.ok) throw new Error(`ลบข้อมูลไม่สำเร็จ (${response.status})`);
        }).catch(error => console.error(error));

        return;
    }

    fetch("/api/save_exercise", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify({

        factory: factory,
        emp_code: empCode,
        emp_name: empName,
        position: position,
        exercise_date: dateStr,
        status: cell.innerText

    })
}).then(response => {
    if (!response.ok) throw new Error(`บันทึกข้อมูลไม่สำเร็จ (${response.status})`);
}).catch(error => console.error(error));
}


/* โหลดข้อมูลที่บันทึกไว้ */
function loadSavedData(month, year) {

    fetch(`/api/get_exercise/${year}/${month}?factory=${encodeURIComponent(factory)}`)
    .then(res => {
        if (!res.ok) throw new Error(`โหลดข้อมูล Exercise ไม่สำเร็จ (${res.status})`);
        return res.json();
    })
    .then(data => {

        document.querySelectorAll("#attTable tbody tr").forEach(row => {

            const code = row.querySelector(".cell")?.dataset.code;

            row.querySelectorAll(".cell").forEach((cell, index) => {

                const day = index + 1;

                const dateStr =
                    `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;

                const record = data.find(d =>
                    d.emp_code === code && d.date === dateStr
                );

                if (record) {

                    cell.innerText = record.status;

                    if (record.status === "✓")
                        cell.className = "cell check";
                    else if (record.status === "X")
                        cell.className = "cell cross";
                    else
                        cell.className = "cell";

                }

            });

        });

    })
    .catch(error => console.error(error));

}





/* Month / Year selector */
const monthSel = document.getElementById("month");
const yearSel = document.getElementById("year");

for (let m = 1; m <= 12; m++) {
    monthSel.innerHTML += `<option value="${m}">${monthNames[m-1]}</option>`;
}

for (let y = 2026; y <= 2035; y++) {
    yearSel.innerHTML += `<option value="${y}">${y}</option>`;
}

const today = new Date();
monthSel.value = today.getMonth() + 1;
yearSel.value = today.getFullYear();

monthSel.onchange = yearSel.onchange = () =>
    loadTable(monthSel.value, yearSel.value);

document.querySelectorAll(".factory-buttons button").forEach(button => {
    button.addEventListener("click", () => changeFactory(button.dataset.factory));
});

updateFactoryTabs();

loadEmployees();


/* Export CSV */
function exportCSV() {
    let csv = "\uFEFF"; // UTF-8 BOM

    const monthName = monthNames[monthSel.value - 1];
    const year = yearSel.value;

    // ⭐ บรรทัดบอกเดือน/ปี
    csv += `Attendance Exercise Activity for ${monthName} ${year}\n\n`;

    const rows = document.querySelectorAll("#attTable tr");
    rows.forEach(row => {
        const cols = row.querySelectorAll("th, td");
        const data = Array.from(cols).map(c => c.innerText);
        csv += data.join(",") + "\n";
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `exercise_${monthName}_${year}.csv`;
    link.click();
}

// ✅ ใส่แค่ครั้งเดียวตรงนี้เท่านั้น
document.addEventListener("click", function(e) {

    if (e.target.classList.contains("cell")) {
        toggle(e.target);
    }

});
