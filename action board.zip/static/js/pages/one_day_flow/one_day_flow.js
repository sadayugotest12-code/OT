/* ===== DATE ===== */
document.getElementById("today").innerText =
    new Date().toLocaleDateString("th-TH");

/* ===== INDEXED DB ===== */
const dbName = "OneDayFlowDB";
const storeName = "flow";
const DATE_KEY = "one_day_flow_date";
const canEdit = document.body.dataset.canEdit === "true";

let db;

/* ===== TODAY ===== */
function todayStr(){
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

let newDayCheck;
let midnightResetTimer;

/* ===== OPEN DB ===== */
const req = indexedDB.open(dbName,1);

req.onupgradeneeded = e=>{
    db = e.target.result;

    if(!db.objectStoreNames.contains(storeName)){
        db.createObjectStore(storeName,{ keyPath:"key" });
    }
};

req.onsuccess = e=>{
    db = e.target.result;

    checkNewDay().catch(error=>{
        console.error("ตรวจสอบวันใหม่ของ One Day Flow ไม่สำเร็จ", error);
    }).finally(()=>{
        render();
        scheduleNewDayCheck();
    });
};

req.onerror = e=>{
    console.error("เปิดฐานข้อมูล One Day Flow ไม่สำเร็จ", e.target.error);
    document.getElementById("flowBody").innerHTML =
        '<tr><td colspan="7">ไม่สามารถเปิดพื้นที่บันทึกข้อมูลในเบราว์เซอร์ได้</td></tr>';
};

/* ===== RESET NEW DAY ===== */
function checkNewDay(){
    if(newDayCheck){
        return newDayCheck;
    }

    const today = todayStr();
    const savedDate = localStorage.getItem(DATE_KEY);

    if(savedDate === today){
        return Promise.resolve(false);
    }

    newDayCheck = new Promise(resolve=>{
        const tx = db.transaction(storeName,"readwrite");
        const store = tx.objectStore(storeName);
        store.clear();

        tx.oncomplete = ()=>{
            localStorage.setItem(DATE_KEY, today);
            console.log("Reset One Day Flow for new day:", today);
            resolve(true);
        };

        tx.onerror = ()=>{
            console.error("ล้างข้อมูล One Day Flow ไม่สำเร็จ", tx.error);
            resolve(false);
        };

        tx.onabort = ()=>{
            console.error("การล้างข้อมูล One Day Flow ถูกยกเลิก", tx.error);
            resolve(false);
        };
    }).finally(()=>{
        newDayCheck = null;
    });

    return newDayCheck;
}

function scheduleNewDayCheck(){
    clearTimeout(midnightResetTimer);

    const now = new Date();
    const nextMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    midnightResetTimer = setTimeout(async ()=>{
        try{
            if(await checkNewDay()){
                render();
            }
        }catch(error){
            console.error("ตรวจสอบวันใหม่ของ One Day Flow ไม่สำเร็จ", error);
        }finally{
            scheduleNewDayCheck();
        }
    }, nextMidnight.getTime() - now.getTime());
}

document.addEventListener("visibilitychange", async ()=>{
    if(!db || document.visibilityState !== "visible"){
        return;
    }

    try{
        if(await checkNewDay()){
            render();
        }
    }catch(error){
        console.error("ตรวจสอบวันใหม่ของ One Day Flow ไม่สำเร็จ", error);
    }
});

/* ===== DATA ===== */
const rows = [

{
 time:"07:30",
 action:"การเปิดเครื่องจักรที่ใช้ในการผลิต",
 method:"เอกสารคู่มือการเปิดเครื่อง (WI ถ้ามี)",
 no:"1",
 index:"",
 leader:true,
 foreman:false
},
{
 time:"07.30",
 action:"การรายงานสภาพร่างกาย",
 method:"วิธีการรายงานสภาพร่างกายของแต่ละคน(Body Checked)",
 no:"2",
 index:"บอร์ดการรายงานสุขภาพร่างกายAction board",
 leader:true,
 foreman:false
},
{
 time:"07:50",
 action:"กายบริหาร / เคารพธงชาติ",
 method:"",
 no:"3",
 index:"บันทึกการเข้าร่วมAttendance sheet",
 leader:false,
 foreman:true
},
{
 time:"07:50",
 action:"ตรวจอุปกรณ์ความปลอดภัยส่วนบุคคล",
 method:"ขั้นตอนการตรวจสอบอุปกรณ์PPEด้วย ชี้นิ้วปากย้ำ",
 no:"4",
 index:"บอร์ดการยืนยันความพร้อมใน Action board",
 leader:false,
 foreman:true
},
{
 time:"08:05",
 action:"การประชุมตอนเช้า(Morning Meeting)",
 method:"ขั้นตอนการประชุมตอนเช้าตาม Time of Action(One day flow)",
 no:"5",
 index:"",
 leader:false,
 foreman:true
},
{
 time:"08:05",
 action:"การควบคุมการเปลี่ยนแปลง 4M",
 method:"วิธีการใช้บอร์ดควบคุมการเปลี่ยนแปลง 4M/Skill control",
 no:"6",
 index:"ยืนยันการเปลี่ยนแปลง change point control ใน Action board",
 leader:true,
 foreman:false
},
{
 time:"08:05",
 action:"การมอบหมายงานประจำวัน",
 method:"อ้างอิงเอกสารPlan Preventive maintenance",
 no:"7",
 index:"ตาราง PM ประจำเดือน",
 leader:false,
 foreman:true
},
{
 time:"08:30",
 action:"การตรวจสอบหน้างานโดยForeman(Shop patrol)",
 method:"เอกสารขั้นตอนตรวจสอบ Patrol 1",
 no:"8",
 index:"ใบบันทึกการตรวจสอบPatrol 1",
 leader:false,
 foreman:true
},
{
 time:"10:00",
 action:"การตรวจสภาพของพื้นที่ทำงาน,พัดลม,ไฟ",
 method:"ขั้นตอนการตรวจสอบตามTime of Action(One day flow)",
 no:"9",
 index:"บอร์ดการยืนยันความพร้มใน Action board",
 leader:true,
 foreman:false
},
{
 time:"11:00-11:30",
 action:"การตรวจสอบหน้างานโดยForeman(Shop patrol)",
 method:"เอกสารขั้นตอนตรวจสอบ Patrol 2",
 no:"10",
 index:"ใบบันทึกการตรวจสอบPatrol 2",
 leader:false,
 foreman:true
},
{
 time:"11:30",
 action:"การตรวจสอบสภาพของพื้นที่ทำงาน พัดลม,ไฟ",
 method:"ขั้นตอนการตรวจสอบตาม Time of Action(One day flow)",
 no:"11",
 index:"บอร์ดการยืนยันความพร้อมใน Action board",
 leader:true,
 foreman:false
},
{
 time:"11:45-12:45",
 action:"พักเที่ยง 60 นาที",
 method:"",
 no:"",
 index:"",
 leader:false,
 foreman:false
},
{
 time:"12:45-13:00",
 action:"การประชุมตอนบ่าย(Afternoon Meeting)",
 method:"ขั้นตอนการประชุมตอนบ่ายตาม Time of Action",
 no:"12",
 index:"",
 leader:false,
 foreman:true
},
{
 time:"13:00",
 action:"การตรวจสอบหน้างานโดยForeman(Shop Patrol)",
 method:"เอกสารขั้นตอนการตรวจสอบ Patrol 3 ",
 no:"13",
 index:"ใบบันทึกการตรวจสอบ Patrol",
 leader:false,
 foreman:true
},
{
 time:"14:50",
 action:"การตรวจสอบสภาพของพื้นที่ทำงาน พัดลม ไฟ",
 method:"ขั้นตอนการตรวจสอบตาม Time of Action(One day flow)",
 no:"14",
 index:"บอร์ดการยืนยันความพร้อมใน Action board",
 leader:true,
 foreman:false
},
{
 time:"15:00-15:15",
 action:"พักย่อย 10 นาที",
 method:"",
 no:"15",
 index:"",
 leader:false,
 foreman:false
},
{
 time:"16:00",
 action:"การตรวจสอบหน้างานโดยForeman(Shop Patrol)",
 method:"เอกสารขั้นตอนการตรวจสอบ Patrol 4 ",
 no:"16",
 index:"ใบบันทึกการตรวจสอบ Patrol",
 leader:false,
 foreman:true
},
{
 time:"16:55",
 action:"การตรวจสอบสภาพพื้นที่ทำงาน,ปิดเครื่องจักร,พัดลม,ไฟ",
 method:"ขั้นตอนการตรวจสอบ Time of Action",
 no:"17",
 index:"บอร์ดการยืนยันความพร้อมใน Action board",
 leader:true,
 foreman:false
},
{
 time:"17:00",
 action:"การยืนยันความปลอดภัยในการจราจร",
 method:"",
 no:"18",
 index:"",
 leader:false,
 foreman:true
}

];

/* ===== RENDER CELL ===== */
function renderCell(role, related, data, key){

    if(!related){
        return `<div class="na">✖</div>`;
    }

    const done = data?.[role];

    if(!canEdit){
        return `<span class="status-readonly ${done ? 'pass':'fail'}">${done ? '✔' : 'ไม่ได้ทำ'}</span>`;
    }

    return `
    <button class="btn-check ${done ? 'pass':'fail'}"
        onclick="toggle('${key}','${role}', this)">
        ${done ? '✔' : 'ไม่ได้ทำ'}
    </button>
    `;
}

/* ===== FULLSCREEN ===== */
const fsBtn = document.getElementById("fsBtn");

function updateFullscreenButton(){
    const isFullscreen = Boolean(document.fullscreenElement);

    fsBtn.textContent = isFullscreen
        ? "ออกจากเต็มจอ"
        : "แตะเพื่อเปิดเต็มหน้าจอ";
    fsBtn.setAttribute("aria-pressed", String(isFullscreen));
}

async function toggleFullscreen(){

    try{
        if(!document.fullscreenElement){
            if(!document.documentElement.requestFullscreen){
                throw new Error("Fullscreen API ไม่รองรับในเบราว์เซอร์นี้");
            }

            await document.documentElement.requestFullscreen();
        }else if(document.exitFullscreen){
            await document.exitFullscreen();
        }

        updateFullscreenButton();
    }catch(error){
        console.error("เปลี่ยนโหมดเต็มจอไม่สำเร็จ", error);
    }
}

fsBtn.addEventListener("click", toggleFullscreen);
document.addEventListener("fullscreenchange", updateFullscreenButton);

/* ===== RENDER TABLE ===== */
function render(){

    const tbody = document.getElementById("flowBody");
    tbody.innerHTML = "";

    const tx = db.transaction(storeName,"readonly");
    const store = tx.objectStore(storeName);

    rows.forEach((r,i)=>{

        const key = `row_${i}`;
        const tr = document.createElement("tr");

        store.get(key).onsuccess = e=>{

            const d = e.target.result || {};

            tr.innerHTML = `
                <td>${r.time}</td>
                <td>${r.action}</td>
                <td>${r.method}</td>
                <td>${r.no}</td>
                <td>${r.index}</td>

                <td class="cell">
                    ${renderCell("leader", r.leader, d, key)}
                </td>

                <td class="cell">
                    ${renderCell("foreman", r.foreman, d, key)}
                </td>
            `;
        };

        tbody.appendChild(tr);
    });
}

/* ===== TOGGLE ===== */
function toggle(key, role, btn){

    if(!canEdit){
        return;
    }

    const tx = db.transaction(storeName,"readwrite");
    const store = tx.objectStore(storeName);

    store.get(key).onsuccess = e=>{

        const d = e.target.result || { key };

        d[role] = !d[role];

        store.put(d);

        btn.classList.toggle("pass", d[role]);
        btn.classList.toggle("fail", !d[role]);

        btn.innerText = d[role]
            ? "✔"
            : "ไม่ได้ทำ";
    };
}
