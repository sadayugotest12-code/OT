/* 1. PDF.js setup and viewer state */
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

let currentFactory = null;
let currentPDF = null;
let currentPage = 1;
let totalPages = 0;
let zoom = 1;
let baseScale = 1;
let renderToken = 0;
let activeRenderTask = null;
const viewer = document.getElementById('pdfViewer');
const documentOverlay = document.getElementById('documentOverlay');
const documentClose = document.getElementById('documentClose');
const documentPrevious = document.getElementById('documentPrevious');
const documentNext = document.getElementById('documentNext');
let fullscreenDocument = false;

/* 2. API helper */
async function getJSON(url) {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Request failed (${response.status})`);
    return response.json();
}

/* 3. Factory loading */
async function loadFactories() {
    try {
        const data = await getJSON('/api/factories');
        
        const select = document.getElementById("factorySelect");
        const uploadSelect = document.getElementById("uploadFactory");
        
        select.innerHTML = "";
        if (uploadSelect) {
            uploadSelect.innerHTML = '<option value="">-- โรงงาน --</option>';
        }
        
        data.factories.forEach(f => {
            let opt = document.createElement("option");
            opt.value = f;
            opt.text = f;
            select.appendChild(opt);

            if (uploadSelect) {
                const uploadOption = opt.cloneNode(true);
                uploadSelect.appendChild(uploadOption);
            }
        });
        
        if(data.factories.length > 0) {
            currentFactory = data.factories[0];
            select.value = currentFactory;
            loadFiles();
        }
    } catch(e) {
        console.error('Error loading factories:', e);
    }
}

/* 4. File list loading and selection synchronization */
async function loadFiles() {
    const factory = document.getElementById("factorySelect").value;
    currentFactory = factory;
    const deleteFactory = document.getElementById("delFactory");
    if (deleteFactory) {
        deleteFactory.value = factory;
    }
    
    try {
        const data = await getJSON('/api/pdf_list?factory=' + encodeURIComponent(factory));
        
        const select = document.getElementById("fileSelect");
        select.innerHTML = "";
        
        data.files.forEach(f => {
            let opt = document.createElement("option");
            opt.value = f;
            opt.text = f;
            select.appendChild(opt);
        });
        
        if(data.files.length > 0) {
            await loadPDF();
        } else {
            resetViewer();
        }
    } catch(e) {
        console.error('Error loading files:', e);
        resetViewer();
    }
}

/* 5. PDF loading */
async function loadPDF() {
    const file = document.getElementById("fileSelect").value;
    if(!file || !currentFactory) {
        resetViewer();
        return;
    }
    
    try {
        currentPDF = null;
        renderToken++;
        viewer.scrollTo(0, 0);
        const url = `/uploads/${encodeURIComponent(currentFactory)}/${encodeURIComponent(file)}`;
        currentPDF = await pdfjsLib.getDocument(url).promise;
        totalPages = currentPDF.numPages;
        currentPage = 1;
        zoom = 1;
        await renderPage(currentPage, true);
    } catch(e) {
        console.error('Error loading PDF:', e);
        alert('❌ ไม่สามารถโหลด PDF ได้');
        resetViewer();
    }
}

/* 6. Page rendering and render cancellation */
async function renderPage(num, fitToViewer = false) {
    if(!currentPDF || num < 1 || num > totalPages) return;
    
    const token = ++renderToken;

    if (activeRenderTask) {
        activeRenderTask.cancel();
        activeRenderTask = null;
    }
    let renderTask = null;

    try {
        const page = await currentPDF.getPage(num);
        if (token !== renderToken) return;
        const canvas = document.getElementById('pdfCanvas');
        const ctx = canvas.getContext('2d');

        if (fitToViewer || !baseScale) {
            const naturalViewport = page.getViewport({ scale: 1 });
            const surface = fullscreenDocument ? documentOverlay : viewer;
            const availableWidth = Math.max(240, surface.clientWidth - 32);
            const availableHeight = Math.max(240, surface.clientHeight - 64);
            baseScale = Math.min(
                availableWidth / naturalViewport.width,
                availableHeight / naturalViewport.height
            );
            baseScale = Math.min(Math.max(baseScale, 0.25), 2.5);
        }

        const scale = baseScale * zoom;
        const viewport = page.getViewport({ scale });
        
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        
        renderTask = page.render({
            canvasContext: ctx,
            viewport: viewport
        });
        activeRenderTask = renderTask;
        await renderTask.promise;

        if (token !== renderToken) return;
        
        document.getElementById('pageNum').textContent = num;
        document.getElementById('pageTotal').textContent = totalPages;
        document.getElementById('documentPageNum').textContent = num;
        document.getElementById('documentPageTotal').textContent = totalPages;
        documentPrevious.disabled = num <= 1;
        documentNext.disabled = num >= totalPages;
    } catch(e) {
        if (e?.name !== 'RenderingCancelledException') {
            console.error('Error rendering page:', e);
        }
    } finally {
        if (activeRenderTask === renderTask) activeRenderTask = null;
    }
}

/* 7. Page navigation */
function previousPage() {
    if(currentPage > 1) {
        currentPage--;
        if (fullscreenDocument) documentOverlay.scrollTo(0, 0);
        renderPage(currentPage);
    }
}

function nextPage() {
    if(currentPage < totalPages) {
        currentPage++;
        if (fullscreenDocument) documentOverlay.scrollTo(0, 0);
        renderPage(currentPage);
    }
}

/* 8. Zoom controls */
function zoomIn() {
    zoom = Math.min(4, Math.round((zoom + 0.2) * 10) / 10);
    renderPage(currentPage);
}

function zoomOut() {
    if (zoom > 0.5) {
        zoom = Math.max(0.5, Math.round((zoom - 0.2) * 10) / 10);
        renderPage(currentPage);
    }
}

function resetZoom() {
    zoom = 1;
    renderPage(currentPage);
}

document.getElementById('zoomInBtn').addEventListener('click', zoomIn);
document.getElementById('zoomOutBtn').addEventListener('click', zoomOut);
document.getElementById('resetZoomBtn').addEventListener('click', resetZoom);
documentPrevious.addEventListener('click', previousPage);
documentNext.addEventListener('click', nextPage);

/* 9. Fullscreen document viewer */
function openDocument() {
    if (!currentPDF || fullscreenDocument) return;
    fullscreenDocument = true;
    documentOverlay.appendChild(document.getElementById('pdfCanvas'));
    documentOverlay.classList.add('is-open');
    documentOverlay.setAttribute('aria-hidden', 'false');
    zoom = 1;
    baseScale = 1;
    documentOverlay.scrollTo(0, 0);
    renderPage(currentPage, true);
    documentClose.focus();
}

function closeDocument() {
    if (!fullscreenDocument) return;
    fullscreenDocument = false;
    viewer.appendChild(document.getElementById('pdfCanvas'));
    documentOverlay.classList.remove('is-open');
    documentOverlay.setAttribute('aria-hidden', 'true');
    zoom = 1;
    baseScale = 1;
    viewer.scrollTo(0, 0);
    renderPage(currentPage, true);
}

document.getElementById('pdfCanvas').addEventListener('click', openDocument);
documentClose.addEventListener('click', closeDocument);
document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && fullscreenDocument) closeDocument();
});

documentOverlay.addEventListener('wheel', event => {
    if (!fullscreenDocument || !currentPDF) return;
    event.preventDefault();
    if (event.deltaY < 0) zoomIn();
    else if (event.deltaY > 0) zoomOut();
}, { passive: false });

/* 10. Reset and viewer drag scrolling */
function resetViewer() {
    renderToken++;
    if (activeRenderTask) {
        activeRenderTask.cancel();
        activeRenderTask = null;
    }
    const canvas = document.getElementById('pdfCanvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 0;
    canvas.height = 0;
    currentPDF = null;
    currentPage = 1;
    totalPages = 0;
    baseScale = 1;
    zoom = 1;
    viewer.scrollTo(0, 0);
    if (fullscreenDocument) closeDocument();
    document.getElementById('pageNum').textContent = '-';
    document.getElementById('pageTotal').textContent = '-';
}

let dragging = false;
let dragStartX = 0;
let dragStartY = 0;
let scrollStartLeft = 0;
let scrollStartTop = 0;

viewer.addEventListener('pointerdown', event => {
    if (!currentPDF || viewer.scrollWidth <= viewer.clientWidth && viewer.scrollHeight <= viewer.clientHeight) return;
    dragging = true;
    viewer.setPointerCapture(event.pointerId);
    dragStartX = event.clientX;
    dragStartY = event.clientY;
    scrollStartLeft = viewer.scrollLeft;
    scrollStartTop = viewer.scrollTop;
    viewer.classList.add('is-dragging');
});

viewer.addEventListener('pointermove', event => {
    if (!dragging) return;
    viewer.scrollLeft = scrollStartLeft - (event.clientX - dragStartX);
    viewer.scrollTop = scrollStartTop - (event.clientY - dragStartY);
});

function stopDragging(event) {
    if (!dragging) return;
    dragging = false;
    if (event?.pointerId !== undefined && viewer.hasPointerCapture(event.pointerId)) {
        viewer.releasePointerCapture(event.pointerId);
    }
    viewer.classList.remove('is-dragging');
}

viewer.addEventListener('pointerup', stopDragging);
viewer.addEventListener('pointercancel', stopDragging);

let overlayDragging = false;
let overlayDragStartX = 0;
let overlayDragStartY = 0;
let overlayScrollStartLeft = 0;
let overlayScrollStartTop = 0;

/* 11. Fullscreen overlay drag scrolling */
documentOverlay.addEventListener('pointerdown', event => {
    if (event.target.closest('.document-navigation, .document-close') || !currentPDF) return;
    overlayDragging = true;
    documentOverlay.setPointerCapture(event.pointerId);
    overlayDragStartX = event.clientX;
    overlayDragStartY = event.clientY;
    overlayScrollStartLeft = documentOverlay.scrollLeft;
    overlayScrollStartTop = documentOverlay.scrollTop;
    documentOverlay.classList.add('is-dragging');
});

documentOverlay.addEventListener('pointermove', event => {
    if (!overlayDragging) return;
    documentOverlay.scrollLeft = overlayScrollStartLeft - (event.clientX - overlayDragStartX);
    documentOverlay.scrollTop = overlayScrollStartTop - (event.clientY - overlayDragStartY);
});

function stopOverlayDragging(event) {
    if (!overlayDragging) return;
    overlayDragging = false;
    if (event?.pointerId !== undefined && documentOverlay.hasPointerCapture(event.pointerId)) {
        documentOverlay.releasePointerCapture(event.pointerId);
    }
    documentOverlay.classList.remove('is-dragging');
}

documentOverlay.addEventListener('pointerup', stopOverlayDragging);
documentOverlay.addEventListener('pointercancel', stopOverlayDragging);

/* 12. Resize and startup */
window.addEventListener('resize', () => {
    if (currentPDF && zoom === 1) renderPage(currentPage, true);
});

document.addEventListener('DOMContentLoaded', loadFactories);
