pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";

const canEdit = document.body.dataset.canEdit === "true";

        const selectedFactory = document.body.dataset.factory;
        const tabs = [selectedFactory.toUpperCase()];
        const sections = ["KPI", "Manpower", "problem", "OverTime"];

        const store = tabs.reduce((acc, tab) => {
            acc[tab] = sections.reduce((sectionAcc, sectionName) => {
                sectionAcc[sectionName] = {
                    images: [],
                    currentIndex: 0,
                    sourceName: "",
                    pageCount: 0
                };
                return sectionAcc;
            }, {});
            return acc;
        }, {});

        let activeTab = tabs[0];

        const globalStatus = document.getElementById("globalStatus");
        const selectedTab = document.getElementById("selectedTab");
        const sectionElements = Array.from(document.querySelectorAll(".section"));

        selectedTab.textContent = activeTab;
        globalStatus.textContent = `หน้าปัจจุบัน: ${activeTab} | ข้อมูลแต่ละหน้าแยกกันอิสระ`;

        console.log(`[INIT] Found ${sectionElements.length} sections`);
        
        sectionElements.forEach((sectionEl) => {
            const sectionName = sectionEl.dataset.section;
            console.log(`[INIT] Setting up section: ${sectionName}`);
            
            const uploadButton = sectionEl.querySelector('[data-action="upload"]');
            const deleteButton = sectionEl.querySelector('[data-action="delete"]');
            const prevButton = sectionEl.querySelector('[data-action="prev"]');
            const nextButton = sectionEl.querySelector('[data-action="next"]');
            const fileInput = sectionEl.querySelector(".file-input");

            console.log(`[INIT] ${sectionName} - uploadBtn:${!!uploadButton}, fileInput:${!!fileInput}`);

            if (!fileInput) {
                console.error(`[ERROR] No file input found for ${sectionName}`);
                return;
            }

            if (uploadButton) {
                uploadButton.addEventListener("click", () => {
                    console.log(`[CLICK] Upload button clicked for ${sectionName}`);
                    fileInput.click();
                });
            }

            fileInput.addEventListener("change", async (event) => {
                console.log(`[CHANGE] File input changed for ${sectionName}`);
                const files = event.target.files;
                console.log(`[CHANGE] files object:`, files);
                console.log(`[CHANGE] files.length:`, files ? files.length : "N/A");
                
                if (!files || files.length === 0) {
                    console.log(`[CHANGE] No files to process`);
                    return;
                }

                console.log(`[CHANGE] Processing ${files.length} file(s) for ${sectionName}`);
                
                // วนลูปไฟล์ก่อน แล้วค่อยรีเซ็ต fileInput
                const filesToProcess = [];
                for (let i = 0; i < files.length; i++) {
                    filesToProcess.push({
                        file: new File([files[i]], files[i].name, { type: files[i].type }),
                        index: i
                    });
                }
                
                // รีเซ็ต input หลังจากสำเร็จการอ่านไฟล์
                fileInput.value = "";

                // problem section สามารถอัปไฟล์หลายไฟล์
                if (sectionName === "problem") {
                    const data = getCurrentData(sectionName);
                    const hasExistingImages = data.images.length > 0;
                    
                    for (let i = 0; i < filesToProcess.length; i++) {
                        console.log(`[UPLOAD] Processing problem file ${i+1}/${filesToProcess.length}: ${filesToProcess[i].file.name}`);
                        // ไฟล์แรก: ถ้าไม่มีไฟล์เก่า ใช้ replace, ถ้ามี ใช้ append
                        const shouldReplace = !hasExistingImages && i === 0;
                        await handlePdfUpload(sectionName, filesToProcess[i].file, shouldReplace);
                    }
                } else {
                    // section อื่นอัปทีละไฟล์เดียว
                    console.log(`[UPLOAD] Processing single file for ${sectionName}: ${filesToProcess[0].file.name}`);
                    await handlePdfUpload(sectionName, filesToProcess[0].file, true);
                }
            });

            if (deleteButton) {
                deleteButton.addEventListener("click", async () => {
                    const data = getCurrentData(sectionName);
                    if (!data.images.length) {
                        globalStatus.textContent = `${activeTab} / ${sectionName}: ไม่มีรายการให้ลบ`;
                        return;
                    }
                
                    if (!confirm('ยืนยันการลบรูปภาพทั้งหมดของ ' + sectionName + '?')) {
                        return;
                    }

                    try {
                        const factory = activeTab.toLowerCase();
                        const res = await fetch(`/api/actionboard/delete/${factory}/${sectionName}`, {
                            method: 'POST'
                        });

                        if (res.ok) {
                            data.images = [];
                            data.currentIndex = 0;
                            data.sourceName = "";
                            data.pageCount = 0;
                            globalStatus.textContent = `${activeTab} / ${sectionName}: ลบรูปภาพเรียบร้อย`;
                            renderSection(sectionName);
                        }
                    } catch (error) {
                        console.error('Delete error:', error);
                        globalStatus.textContent = `${activeTab} / ${sectionName}: ลบไม่สำเร็จ`;
                    }
                });
            }

            prevButton.addEventListener("click", () => {
                const data = getCurrentData(sectionName);
                if (!data.images.length) {
                    return;
                }
                data.currentIndex = (data.currentIndex - 1 + data.images.length) % data.images.length;
                renderSection(sectionName);
            });

            nextButton.addEventListener("click", () => {
                const data = getCurrentData(sectionName);
                if (!data.images.length) {
                    return;
                }
                data.currentIndex = (data.currentIndex + 1) % data.images.length;
                renderSection(sectionName);
            });

            if (uploadButton) {
                ["dragenter", "dragover"].forEach((eventName) => {
                    sectionEl.addEventListener(eventName, (event) => {
                        event.preventDefault();
                        uploadButton.classList.add("drag-over");
                    });
                });

                ["dragleave", "drop"].forEach((eventName) => {
                    sectionEl.addEventListener(eventName, (event) => {
                        event.preventDefault();
                        uploadButton.classList.remove("drag-over");
                    });
                });
            }

            sectionEl.addEventListener("drop", async (event) => {
                const files = event.dataTransfer && event.dataTransfer.files;
                if (!files || files.length === 0) {
                    return;
                }

                // problem section สามารถอัปไฟล์หลายไฟล์
                if (sectionName === "problem") {
                    const data = getCurrentData(sectionName);
                    const hasExistingImages = data.images.length > 0;
                    
                    for (let i = 0; i < files.length; i++) {
                        const shouldReplace = !hasExistingImages && i === 0;
                        await handlePdfUpload(sectionName, files[i], shouldReplace);
                    }
                } else {
                    // section อื่นอัปทีละไฟล์เดียว
                    await handlePdfUpload(sectionName, files[0], true);
                }
            });
        });

        function getCurrentData(sectionName) {
            return store[activeTab][sectionName];
        }

        async function handlePdfUpload(sectionName, file, replace = true) {
            if (!canEdit) {
                globalStatus.textContent = "กรุณาเข้าสู่ระบบก่อนอัปโหลดไฟล์";
                return;
            }
            const isPdf = file.type === "application/pdf";
            const isImage = file.type.startsWith("image/");

            if (!isPdf && !isImage) {
                globalStatus.textContent = `${activeTab} / ${sectionName}: รองรับเฉพาะไฟล์ PDF หรือรูปภาพเท่านั้น`;
                return;
            }

            const data = getCurrentData(sectionName);
            const mode = replace ? "แทนที่" : "เพิ่มเติม";
            
            if (isPdf) {
                globalStatus.textContent = `${activeTab} / ${sectionName}: กำลังแปลง PDF (${mode})...`;
            } else {
                globalStatus.textContent = `${activeTab} / ${sectionName}: กำลังอัปโหลดรูป (${mode})...`;
            }

            try {
                let imagesToUpload = [];

                if (isPdf) {
                    // แปลง PDF เป็นรูปภาพ (client-side)
                    imagesToUpload = await convertPdfToImages(file);
                } else {
                    // สำหรับรูปภาพ ให้ใช้โดยตรง
                    imagesToUpload = [await convertImageToDataUrl(file)];
                }

                if (imagesToUpload.length === 0) {
                    throw new Error('ไม่สามารถดึงข้อมูลจากไฟล์ได้');
                }

                globalStatus.textContent = `${activeTab} / ${sectionName}: อัปโหลด ${imagesToUpload.length} รูป (${mode})...`;

                // สร้าง FormData เพื่อส่งรูปภาพ
                const formData = new FormData();
                formData.append('factory', activeTab.toLowerCase());
                formData.append('section', sectionName);
                formData.append('replace', replace ? 'true' : 'false');
                
                // เพิ่มแต่ละ image เป็น blob file
                for (let i = 0; i < imagesToUpload.length; i++) {
                    const blob = await (await fetch(imagesToUpload[i])).blob();
                    formData.append('images', blob, `page_${i+1}.png`);
                }

                console.log('Uploading:', { factory: activeTab.toLowerCase(), section: sectionName, replace, imageCount: imagesToUpload.length });

                // Upload ไปยัง backend
                const res = await fetch('/actionboard/upload', {
                    method: 'POST',
                    body: formData
                });

                if (!res.ok) {
                    let errorMsg = `ข้อผิดพลาด HTTP ${res.status}`;
                    try {
                        const error = await res.json();
                        errorMsg = error.error || errorMsg;
                    } catch(e) {}
                    throw new Error(errorMsg);
                }

                const result = await res.json();
                console.log('Upload response:', result);

                if (result.success) {
                    if (replace) {
                        data.sourceName = file.name;
                    } else {
                        // append mode - เพิ่มชื่อไฟล์เข้าไป
                        data.sourceName = (data.sourceName ? data.sourceName + ", " : "") + file.name;
                    }
                    data.pageCount = result.count;
                    globalStatus.textContent = `${activeTab} / ${sectionName}: ✓ อัปโหลดสำเร็จ ${result.count} รูป`;
                    
                    // โหลดรูปภาพที่บันทึกแล้ว
                    await loadSectionImages(sectionName);
                    renderSection(sectionName);
                } else {
                    throw new Error(result.error || 'อัปโหลดไม่สำเร็จ');
                }
            } catch (error) {
                console.error('Upload error:', error);
                globalStatus.textContent = `❌ ${activeTab} / ${sectionName}: ${error.message}`;
            }
        }

        async function convertImageToDataUrl(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (e) => resolve(e.target.result);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        }

        async function convertPdfToImages(file) {
            const buffer = await file.arrayBuffer();
            const pdf = await pdfjsLib.getDocument({ data: buffer }).promise;
            const output = [];

            for (let pageNum = 1; pageNum <= pdf.numPages; pageNum += 1) {
                const page = await pdf.getPage(pageNum);
                const viewport = page.getViewport({ scale: 1.7 });
                const canvas = document.createElement("canvas");
                const ctx = canvas.getContext("2d", { alpha: false });
                canvas.width = Math.floor(viewport.width);
                canvas.height = Math.floor(viewport.height);
                await page.render({
                    canvasContext: ctx,
                    viewport
                }).promise;
                output.push(canvas.toDataURL("image/png", 0.92));
            }

            return output;
        }

        async function loadSectionImages(sectionName) {
            try {
                const factory = activeTab.toLowerCase();
                const res = await fetch(`/api/actionboard/images/${factory}/${sectionName}`);
                if (!res.ok) {
                    throw new Error(`API error: ${res.status}`);
                }
                
                const data = await res.json();
                console.log(`Loading images for ${sectionName}:`, data);
                
                if (data.images && data.images.length > 0) {
                    const imageUrls = data.images.map(img => 
                        `/uploads/${factory}/actionboard/${sectionName}/${img}`
                    );
                    getCurrentData(sectionName).images = imageUrls;
                    getCurrentData(sectionName).currentIndex = 0;
                    console.log(`Loaded ${imageUrls.length} images for ${sectionName}`);
                }
            } catch (error) {
                console.error(`Failed to load images for ${sectionName}:`, error);
            }
        }

        async function deleteIndividualFile(sectionName, imageIndex) {
            if (!canEdit) {
                globalStatus.textContent = "กรุณาเข้าสู่ระบบก่อนลบไฟล์";
                return;
            }
            try {
                const data = getCurrentData(sectionName);
                if (!data.images || imageIndex >= data.images.length) {
                    return;
                }

                const imageSrc = data.images[imageIndex];
                // ดึง filename จาก URL (เช่น /uploads/mt1/actionboard/problem/problem_001.png)
                const urlParts = imageSrc.split('/');
                const filename = urlParts[urlParts.length - 1];

                globalStatus.textContent = `${activeTab} / ${sectionName}: กำลังลบรูป...`;

                const factory = activeTab.toLowerCase();
                const res = await fetch(`/api/actionboard/delete/${factory}/${sectionName}/${filename}`, {
                    method: 'POST'
                });

                if (res.ok) {
                    // โหลดรูปภาพใหม่หลังจากลบสำเร็จ
                    await loadSectionImages(sectionName);
                    globalStatus.textContent = `${activeTab} / ${sectionName}: ✓ ลบรูปสำเร็จ`;
                    renderSection(sectionName);
                } else {
                    throw new Error('ลบไฟล์ไม่สำเร็จ');
                }
            } catch (error) {
                console.error('Delete file error:', error);
                globalStatus.textContent = `❌ ${activeTab} / ${sectionName}: ลบไม่สำเร็จ - ${error.message}`;
            }
        }

        function renderAllSections() {
            sections.forEach(async (sectionName) => {
                await loadSectionImages(sectionName);
                renderSection(sectionName);
            });
        }

        function renderSection(sectionName) {
            const sectionEl = sectionElements.find((el) => el.dataset.section === sectionName);
            if (!sectionEl) {
                return;
            }

            const frame = sectionEl.querySelector('[data-role="frame"]');
            const meta = sectionEl.querySelector('[data-role="meta"]');
            const thumbs = sectionEl.querySelector('[data-role="thumbs"]');
            const prevButton = sectionEl.querySelector('[data-action="prev"]');
            const nextButton = sectionEl.querySelector('[data-action="next"]');

            const data = getCurrentData(sectionName);
            const hasImages = data.images.length > 0;

            frame.innerHTML = "";
            thumbs.innerHTML = "";

            if (!hasImages) {
                const empty = document.createElement("div");
                empty.className = "empty-state";
                const textContent = canEdit
                    ? (sectionName === "problem"
                        ? "Drop PDF หรือรูปหลายรูปที่นี่ หรือกด Upload"
                        : "Drop PDF หรือรูป ที่นี่ หรือกด Upload")
                    : "ยังไม่มีไฟล์ในส่วนนี้";
                empty.textContent = textContent;
                frame.appendChild(empty);
                meta.textContent = `${activeTab} / ${sectionName}: ยังไม่มีไฟล์`;
                prevButton.disabled = true;
                nextButton.disabled = true;
                return;
            }

            const currentSrc = data.images[data.currentIndex];
            const image = document.createElement("img");
            image.className = "preview-image";
            image.src = currentSrc;
            image.alt = `${sectionName} page ${data.currentIndex + 1}`;
            image.style.cursor = "pointer";
            image.addEventListener("click", () => {
                openFullscreen(sectionName, data.currentIndex);
            });
            frame.appendChild(image);

            data.images.forEach((src, idx) => {
                const thumbBtn = document.createElement("button");
                thumbBtn.className = `thumb ${idx === data.currentIndex ? "active" : ""}`;
                thumbBtn.type = "button";
                thumbBtn.title = `หน้า ${idx + 1}`;
                thumbBtn.style.position = "relative";

                const thumbImg = document.createElement("img");
                thumbImg.src = src;
                thumbImg.alt = `Thumbnail ${idx + 1}`;
                thumbBtn.appendChild(thumbImg);

                // เพิ่ม delete button สำหรับ problem section
                if (sectionName === "problem") {
                    const deleteBtn = document.createElement("button");
                    deleteBtn.className = "thumb-delete";
                    deleteBtn.type = "button";
                    deleteBtn.textContent = "✕";
                    deleteBtn.title = "ลบรูปนี้";
                    deleteBtn.onclick = (e) => {
                        e.stopPropagation();
                        if (confirm(`ยืนยันการลบรูปที่ ${idx + 1}?`)) {
                            deleteIndividualFile(sectionName, idx);
                        }
                    };
                    thumbBtn.appendChild(deleteBtn);
                }

                thumbBtn.addEventListener("click", () => {
                    data.currentIndex = idx;
                    renderSection(sectionName);
                });

                thumbs.appendChild(thumbBtn);
            });

            meta.textContent = `${activeTab} / ${sectionName}: ${data.sourceName || "PDF"} | หน้า ${data.currentIndex + 1}/${data.images.length}`;
            prevButton.disabled = data.images.length <= 1;
            nextButton.disabled = data.images.length <= 1;
        }

        // ═══════════════════════════════════════════════════════════════
        // FULLSCREEN VIEWER FUNCTIONS
        // ═══════════════════════════════════════════════════════════════
        
        let fullscreenState = {
            active: false,
            section: null,
            currentIndex: 0,
            zoom: 100,
            maxZoom: 300,
            minZoom: 50,
            zoomStep: 20
        };

        function openFullscreen(sectionName, imageIndex) {
            fullscreenState.active = true;
            fullscreenState.section = sectionName;
            fullscreenState.currentIndex = imageIndex;
            fullscreenState.zoom = 100;

            const modal = document.getElementById('fullscreenModal');
            const data = store[activeTab][sectionName];
            
            modal.classList.add('active');
            updateFullscreenImage();
            updatePageIndicator();
            
            document.body.style.overflow = 'hidden';
            
            // Add keyboard support
            document.addEventListener('keydown', handleFullscreenKeydown);
        }

        function closeFullscreen() {
            fullscreenState.active = false;
            const modal = document.getElementById('fullscreenModal');
            modal.classList.remove('active');
            document.body.style.overflow = 'auto';
            document.removeEventListener('keydown', handleFullscreenKeydown);
        }

        function updateFullscreenImage() {
            const data = store[activeTab][fullscreenState.section];
            const img = document.getElementById('fullscreenImage');
            const title = document.getElementById('fullscreenTitle');
            
            img.src = data.images[fullscreenState.currentIndex];
            img.style.transform = `scale(${fullscreenState.zoom / 100})`;
            title.textContent = `${activeTab} / ${fullscreenState.section} - หน้า ${fullscreenState.currentIndex + 1}`;
            
            document.getElementById('zoomLevel').textContent = fullscreenState.zoom + '%';
        }

        function updatePageIndicator() {
            const data = store[activeTab][fullscreenState.section];
            const indicator = document.getElementById('pageIndicator');
            const prevBtn = document.getElementById('prevNavBtn');
            const nextBtn = document.getElementById('nextNavBtn');
            
            indicator.textContent = `${fullscreenState.currentIndex + 1} / ${data.images.length}`;
            prevBtn.disabled = fullscreenState.currentIndex === 0;
            nextBtn.disabled = fullscreenState.currentIndex === data.images.length - 1;
        }

        function zoomIn() {
            if (fullscreenState.zoom < fullscreenState.maxZoom) {
                fullscreenState.zoom += fullscreenState.zoomStep;
                if (fullscreenState.zoom > fullscreenState.maxZoom) {
                    fullscreenState.zoom = fullscreenState.maxZoom;
                }
                updateFullscreenImage();
            }
        }

        function zoomOut() {
            if (fullscreenState.zoom > fullscreenState.minZoom) {
                fullscreenState.zoom -= fullscreenState.zoomStep;
                if (fullscreenState.zoom < fullscreenState.minZoom) {
                    fullscreenState.zoom = fullscreenState.minZoom;
                }
                updateFullscreenImage();
            }
        }

        function prevFullscreenImage() {
            if (fullscreenState.currentIndex > 0) {
                fullscreenState.currentIndex--;
                fullscreenState.zoom = 100;
                updateFullscreenImage();
                updatePageIndicator();
            }
        }

        function nextFullscreenImage() {
            const data = store[activeTab][fullscreenState.section];
            if (fullscreenState.currentIndex < data.images.length - 1) {
                fullscreenState.currentIndex++;
                fullscreenState.zoom = 100;
                updateFullscreenImage();
                updatePageIndicator();
            }
        }

        function handleFullscreenKeydown(event) {
            switch(event.key) {
                case 'Escape':
                    closeFullscreen();
                    break;
                case 'ArrowLeft':
                    prevFullscreenImage();
                    event.preventDefault();
                    break;
                case 'ArrowRight':
                    nextFullscreenImage();
                    event.preventDefault();
                    break;
                case '+':
                case '=':
                    zoomIn();
                    event.preventDefault();
                    break;
                case '-':
                case '_':
                    zoomOut();
                    event.preventDefault();
                    break;
                case '0':
                    fullscreenState.zoom = 100;
                    updateFullscreenImage();
                    event.preventDefault();
                    break;
            }
        }

        // Close modal when clicking outside the image
        document.getElementById('fullscreenContent').addEventListener('click', (e) => {
            if (e.target.id === 'fullscreenContent') {
                closeFullscreen();
            }
        });

        renderAllSections();
