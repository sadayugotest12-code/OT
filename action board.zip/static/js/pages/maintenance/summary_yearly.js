const fsBtn = document.getElementById("fsBtn");

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
    fsBtn.textContent = "ออกจากเต็มจอ";
  } else {
    document.exitFullscreen();
    fsBtn.textContent = "แตะเพื่อแสดงเต็มจอ";
  }
}

fsBtn.addEventListener("click", toggleFullscreen);


const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];


/* โหลดข้อมูลทั้งหมดจาก store ที่ระบุ */
function dbLoadAll(store, callback) {
  const tx = db.transaction(store, "readonly");
  const req = tx.objectStore(store).getAll();
  req.onsuccess = () => callback(req.result);
}


let chart;
/* โหลดกราฟ PM Summary */

function loadChart() {

  const year = document.getElementById("year").value;
  const month = document.getElementById("month").value;

  fetch(`/api/pm/summary?year=${year}&month=${month}`)
    .then(res => res.json())
    .then(rows => {

      let labels = [];
      let pData = [];
      let aData = [];

      if (month) {

        const m = rows[0] || { p: 0, a: 0 };

        const plan = m.p;
        const actual = m.a;

        const percentA = plan > 0 ? (actual / plan * 100) : 0;

        labels = ["PM"];
        pData = [plan > 0 ? 100 : 0];
        aData = [percentA];

      } else {

        for (let i = 1; i <= 12; i++) {

          const found = rows.find(r => r.month == i) || { p: 0, a: 0 };

          const plan = found.p;
          const actual = found.a;

          const percentA = plan > 0 ? (actual / plan * 100) : 0;

          labels.push(monthNames[i - 1]);
          pData.push(plan > 0 ? 100 : 0);
          aData.push(percentA);
        }
      }

      if (chart) chart.destroy();

      chart = new Chart(document.getElementById("pmChart"), {
        type: "bar",
        data: {
          labels,
          datasets: [
            { label: "P (%)", data: pData, backgroundColor: "blue" },
            { label: "A (%)", data: aData, backgroundColor: "Green" }
          ]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true,
              max: 100,
              ticks: {
                callback: value => value + "%"
              }
            }
          }
        }
      });

    });
}

/* สรุปข้อมูล PM จาก rows ที่โหลดมา */
function summarizePM(rows, year, month) {
  const result = {};

  rows.forEach(r => {
    const [mc, y, m, w, type] = r.id.split("_");

    if (y !== year) return;
    if (month && m !== month) return;

    if (!result[m]) {
      result[m] = { p: 0, a: 0, plan: 0 };
    }

    if (type === "P") {
      result[m].p++;
      result[m].plan++; // ✅ P = แผน
    }

    if (type === "A") {
      result[m].a++;
    }
  });

  return result;
}




window.addEventListener("DOMContentLoaded", () => {
  loadChart();
});


/* ส่งออกกราฟเป็นรูปภาพ */
function exportChart() {
  if (!chart) {
    alert("ยังไม่มีกราฟให้ export");
    return;
  }

  const link = document.createElement("a");
  link.href = chart.toBase64Image();
  link.download = `PM_Summary_${document.getElementById("year").value}.png`;
  link.click();
}

function exportPDF() {
  if (!chart) {
    alert("ยังไม่มีกราฟให้ export");
    return;
  }

  const { jsPDF } = window.jspdf;

  // PDF แนวนอน A4
  const pdf = new jsPDF("landscape", "mm", "a4");

  const year = document.getElementById("year").value;
  const month = document.getElementById("month").value || "All Year";

  // ===== Title =====
  pdf.setFontSize(18);
  pdf.text("PM SUMMARY REPORT", 14, 15);

  pdf.setFontSize(12);
  pdf.text(`Year: ${year}`, 14, 25);
  pdf.text(`Month: ${month}`, 14, 32);

  // ===== Chart Image =====
  const imgData = chart.toBase64Image();

  // กำหนดตำแหน่งและขนาดกราฟ
  pdf.addImage(
    imgData,
    "PNG",
    14,
    40,
    270,
    120
  );

  // ===== Footer =====
  pdf.setFontSize(10);
  pdf.text(
    `Generated: ${new Date().toLocaleString()}`,
    14,
    190
  );

  // ===== Save =====
  pdf.save(`PM_Summary_${year}.pdf`);
}
