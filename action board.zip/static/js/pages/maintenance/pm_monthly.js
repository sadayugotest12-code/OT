const fsBtn = document.getElementById("fsBtn");

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
    fsBtn.textContent = "ออกจากเต็มจอ";
  } else {
    document.exitFullscreen();
    fsBtn.textContent = "แตะเพื่อแสดงเต็มจอ";
  }
}

fsBtn.addEventListener("click", toggleFullscreen);




/* ================= CONFIG ================= */
const ITEMS_PER_PAGE = 20;
let currentPage = 1;

const monthNames=[
 "January","February","March","April","May","June",
 "July","August","September","October","November","December"
];

/* 🔧 เครื่องจักร (รวมทุกข้อมูลไว้ด้วยกัน) */
const machines = [
  { name:"Iron Melting Furnace m/c-2",model:"500 Hz",code:"MF-02-FC",group:"FC"},
  { name:"Iron Melting Furnace m/c-3",model:"500 Hz",code:"MF-03-FC",group:"FC"},    
  { name:"Iron Melting Furnace m/c-4",model:"500 Hz",code:"MF-04-FC",group:"FC"},
  { name:"Iron Melting Furnace m/c-5",model:"500 Hz",code:"MF-05-FC",group:"FC"},  
  { name:"Al.Crucibie gas holding furnace",model:"300kg",code:"MF-02-AL",group:"BC"},
    
    { name:"Al.Crucibie gas melting furnace",model:"2000kg",code:"MF-04-AL",group:"BC"},
    { name:"Gas Bubble fill",model:"LP",code:"GBF-02",group:"LP"},
    { name:"Gas Bubble fill",model:"BC",code:"GBF-03",group:"BC"},
    { name:"FC Casting line & BIg Ladle ",model:"FC",code:"FC-CL-02",group:"FC"},
    { name:"Al Casting line pouring",model:"BC",code:"AL-CL-02",group:"BC"},
    { name:"Casting machine",model:"LP",code:"LP-01",group:"LP"},
    { name:"Casting machine",model:"LP",code:"LP-02",group:"LP"},
    { name:"Shell MOld machine",model:"CT-650",code:"MO-01",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-02",group:"MO"},
    { name:"Shell MOld machine",model:"CT-650",code:"MO-03",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-04",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-05",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-06",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-07",group:"MO"},
    { name:"Shell Mold machine",model:"CT-865",code:"MO-08",group:"MO"},
    { name:"Shell Mold machine",model:"CT-865",code:"MO-09",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-10",group:"MO"},

    { name:"Shell Mold machine",model:"CT-650",code:"MO-12",group:"BC"},

    { name:"H-TOP mold making ",model:"750-B",code:"H-TOP-2",group:"MO"},
    { name:"H-TOP mold making ",model:"750-B",code:"H-TOP-3",group:"MO"},
    { name:"H-TOP mold making ",model:"750-small",code:"H-TOP-4",group:"MO"},
    { name:"H-TOP mold making ",model:"750-small",code:"H-TOP-5",group:"MO"},
    { name:"Shell core machine ",model:"TD-440",code:"CO-03",group:"CO"},
    { name:"Shell core machine ",model:"TD-440",code:"CO-04",group:"CO"},
    { name:"Shell core machine ",model:"TD-45AN",code:"CO-05",group:"CO"},
    { name:"Shell core machine ",model:"TD-45AN",code:"CO-06",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-07",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-08",group:"CO"},
  
    { name:"Shell core machine ",model:"TD-530",code:"CO-10",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-11",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-12",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-13",group:"CO"},
    
    { name:"Shell core machine ",model:"TD-530",code:"CO-15",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-16",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-17",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-18",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-19",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-20",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-21",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-22",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-23",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-24",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-25",group:"CO"},
    { name:"Shot Blasting machine",model:"TC-120",code:"SB-01",group:"PP"},
    { name:"Shot Blasting machine",model:"TC-120",code:"SB-02",group:"PP"},
    { name:"Shot Blasting machine",model:"PFH-67",code:"SB-05",group:"PP"},
    { name:"Shot Blasting machine",model:"GW-10",code:"SB-GW-10",group:"PP"},
    { name:"Shot Blasting machine",model:"SNB-II",code:"SB-Sinto-01",group:"PP"},
    { name:"Shot Blasting machine",model:"IRH-9",code:"SB-IRH-9",group:"PP"},
    { name:"Shot Blasting machine",model:"SNB-II",code:"SB-Sinto-02",group:"PP"},
    { name:"Shot Blasting machine",model:"SNB-II",code:"SB-Sinto-03",group:"PP"},
    { name:"Shot Blasting machine",model:"TC-312DM-AD",code:"SB-TC-312DM",group:"PP"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-01",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-02",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-03",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-04",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-05",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-06",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-07",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-08",group:"FCDB"},
   
    { name:"Test Leak machine",model:"Cosmo",code:"TL-10",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL",group:"BC"},

    { name:"Heat Treatment furnace",model:"PP",code:"HE-01",group:"PP"},
    { name:"Heat Treatment furnace",model:"PP",code:"HE-02",group:"HT"},
    { name:"Heat Treatment furnace",model:"PP",code:"HE-03",group:"HT"},
    { name:"Magnetic tester machine",model:"FCDB",code:"MGT-01",group:"FCDB"},
    { name:"Knock out",model:"BC",code:"KO-03",group:"BC"},
    { name:"Riser cutting machine",model:"BC",code:"CT-03-BC",group:"BC"},
    { name:"Riser cutting machine",model:"Taiwan",code:"CT-04-LP",group:"LP"},
    { name:"Riser cutting machine",model:"Indo",code:"CT-05-BC",group:"BC"},
    { name:"DMC mark",model:"DMC",code:"DMC-01",group:"FCDB"},
    { name:"DMC mark",model:"DMC",code:"DMC-02",group:"FCDB"},
    { name:"CNC Lathe",model:"TC-3-01",code:"CNC-L-04",group:"FCDB"},
    { name:"CNC Lathe",model:"TC-3-02",code:"CNC-L-05",group:"BC"},
    { name:"CNC Machine Center",model:"Kira",code:"CNC-M-01",group:"FCDB"},
    { name:"CNC Machine Center",model:"Brother",code:"TC-S2A-01",group:"FCDB"},
    { name:"CNC Machine Center",model:"Brother",code:"TC-S2A-04",group:"FCDB"},
    { name:"CNC Machine Center",model:"Brother",code:"TC-S2A-05",group:"FCDB"},
    { name:"Boring machine",model:"FCDB",code:"Boring-01",group:"FCDB"},
    { name:"Boring machine",model:"FCDB",code:"Boring-02",group:"BC"},
    { name:"Crane",model:"DEMAG",code:"Crane-1-1",group:"MO"},
    { name:"Crane",model:"DEMAG",code:"Crane-1-2",group:"BC"},
    { name:"Crane",model:"DEMAG",code:"Crane-1-3",group:"CO"},
    { name:"Crane",model:"DEMAG",code:"Crane-1-4",group:"CO"},
    { name:"Crane",model:"DEMAG",code:"Crane-1-5",group:"FC"},
    { name:"Crane",model:"KONE",code:"Crane-1-6",group:"PP"},
    { name:"Crane",model:"KONE",code:"Crane-1-10",group:"FC"},
    { name:"Crane",model:"KONE",code:"Crane-1-11",group:"FC(DM)"},
    { name:"Hoist",model:"1 TON",code:"CH-01-FC2",group:"FC"},
    { name:"Hoist",model:"1 TON",code:"CH-02-FC2",group:"FC"},
    { name:"Hoist",model:"2 TON",code:"CH-03-FC2",group:"FC"},
    { name:"Hoist",model:"2 TON",code:"CH-04-FC2",group:"FC"},
    { name:"Hoist",model:"4 TON",code:"CH-05-FC2",group:"FC"},
    { name:"Hoist",model:"Air Hoist",code:"CH-06-FC2",group:"FC"},
    { name:"Auto Pouring",model:"Pro1500",code:"Puma Machine",group:"FC"},
    { name:"Auto Deburing",model:"TX6i-FDS12R-331GR",code:"331GR-01",group:"FCDB"},
    { name:"Auto Deburing",model:"TX6i-FDS22R-455GR",code:"445GR-01",group:"FCDB"},
    { name:"Auto Deburing",model:"TX6i-FDS12R-331GR",code:"331GR-02",group:"FCDB"},
    { name:"Auto Deburing",model:"TX6i-FDS12R-331GR",code:"331GR-03",group:"FCDB"},
    { name:"Auto Deburing",model:"TX6i-FDS12R-331GR",code:"331GR-04",group:"FCDB"},
    { name:"Sand Blast",model:"FDHV-3-A-SD-NV-502-J",code:"Sand Blast",group:"FCDB"},
   
];

/* ================= SELECT ================= */
const monthSel=document.getElementById("month");
const yearSel=document.getElementById("year");

monthNames.forEach((m,i)=>{
    monthSel.innerHTML+=`<option value="${i+1}">${m}</option>`;
});
for(let y=2026;y<=2035;y++){
    yearSel.innerHTML+=`<option value="${y}">${y}</option>`;
}

monthSel.value=new Date().getMonth()+1;
yearSel.value=new Date().getFullYear();

/* ================= FUNCTIONS ================= */
function daysInMonth(m,y){
    return new Date(y,m,0).getDate();
}

function loadTable(m,y,page){
    currentPage = page;

    const title = document.getElementById("title");
    const header = document.getElementById("header");
    const body = document.querySelector("#pmTable tbody");

    title.innerText = `PM Monthly for ${monthNames[m-1]} ${y} (Page ${page})`;

    /* ===== HEADER ===== */
    header.innerHTML = `
        <th>No.</th>
        <th>M/C Name</th>
        <th>MODEL</th>
        <th>M/C-Code</th>
        <th>M/C-Group</th>
        <th>P/A</th>
    `;

    const days = daysInMonth(m,y);
    for(let d=1; d<=days; d++){
        header.innerHTML += `<th>${d}</th>`;
    }

    /* ===== BODY ===== */
    body.innerHTML = "";

    const start = (page-1)*ITEMS_PER_PAGE;
    const end = start + ITEMS_PER_PAGE;
    const pageMachines = machines.slice(start,end);

    pageMachines.forEach((mc,i)=>{
        ["P","A"].forEach(type=>{
            let tr = `<tr>
                <td>${type==="P" ? start+i+1 : ""}</td>
                <td>${type==="P" ? mc.name : ""}</td>
                <td>${type==="P" ? mc.model : ""}</td>
                <td>${type==="P" ? mc.code : ""}</td>
                <td>${type==="P" ? mc.group : ""}</td>
                <td>${type}</td>
            `;

            for(let d=1; d<=days; d++){
                tr += `
                <td class="cell"
                    data-key="${y}-${m}-${mc.code}-${type}-${d}"
                    data-type="${type}"
                    onclick="toggle(this)">
                </td>`;
            }

            tr += "</tr>";
            body.innerHTML += tr;
        });
    });

    loadFromServer(); 
    renderPagination();
}


function toggle(cell){

    const rowType = cell.dataset.type;   // "P" หรือ "A"

    // ===== แถว P : มีแค่ ว่าง <-> P =====
    if(rowType === "P"){

        if(cell.innerText === ""){
            cell.innerText = "P";
            cell.classList.add("p-cell");
            cell.classList.remove("a-cell","delay-cell");
        }else{
            cell.innerText = "";
            cell.classList.remove("p-cell");
        }

        saveCell(cell);
        checkDelay();
        return;
    }

    // ===== แถว A : ว่าง / A / เลื่อน =====
    if(rowType === "A"){

        if(cell.innerText === "" || cell.innerText === "เลื่อน"){
            cell.innerText = "A";
            cell.classList.add("a-cell");
            cell.classList.remove("delay-cell");
        }
        else if(cell.innerText === "A"){
            cell.innerText = "";
            cell.classList.remove("a-cell");
        }

        saveCell(cell);
        checkDelay();
        return;
    }
}



/* ================= SAVE / LOAD ================= */

function loadFromServer(){

    fetch(`/api/pm_monthly/load?year=${yearSel.value}&month=${monthSel.value}`)
        .then(res=>res.json())
        .then(rows=>{

            document.querySelectorAll(".cell").forEach(c=>{
                c.innerText="";
                c.classList.remove("p-cell","a-cell","delay-cell");
            });

            rows.forEach(r=>{
                const key = `${yearSel.value}-${monthSel.value}-${r.machine_code}-${r.type}-${r.day}`;
                const cell = document.querySelector(`[data-key="${key}"]`);

                if(cell){
                    cell.innerText = r.status;
                    if(r.status==="P") cell.classList.add("p-cell");
                    if(r.status==="A") cell.classList.add("a-cell");
                    if(r.status==="เลื่อน") cell.classList.add("delay-cell");
                }
            });
        });
}


/* ================= P / A ================= */
function saveCell(cell){

    const parts = cell.dataset.key.split("-");

    const year = parts[0];
    const month = parts[1];

    const day = parts.pop();        // ดึงตัวท้าย
    const type = parts.pop();       // ดึงรองท้าย

    parts.shift(); // year
    parts.shift(); // month

    const machine = parts.join("-");   // รวมกลับเป็น MF-02-FC

    fetch("/api/pm_monthly/save", {
        method:"POST",
        keepalive:true,
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({
            year: year,
            month: month,
            machine_code: machine,
            day: day,
            type: type,
            status: cell.innerText || null
        })
    }).then(response=>{
        if(!response.ok){
            throw new Error(`บันทึก PM Monthly ไม่สำเร็จ (${response.status})`);
        }
    }).catch(error=>{
        console.error("บันทึก PM Monthly ไม่สำเร็จ", error);
        cell.title = "บันทึกไม่สำเร็จ กรุณาลองเลือกสถานะอีกครั้ง";
    });
}



/* ================= CHECK DELAY ================= */

function checkDelay(){

    const today = new Date();
    const curYear = parseInt(yearSel.value);
    const curMonth = parseInt(monthSel.value) - 1;

    document.querySelectorAll(".cell[data-type='P']").forEach(pCell=>{

        if(pCell.innerText !== "P") return;

        const parts = pCell.dataset.key.split("-");
        const day = parseInt(parts[parts.length-1]);
        const cellDate = new Date(curYear, curMonth, day);

        if(cellDate > today) return;

        const aKey = pCell.dataset.key.replace("-P-","-A-");
        const aCell = document.querySelector(`[data-key="${aKey}"]`);

        if(aCell && aCell.innerText===""){
            aCell.innerText="เลื่อน";
            aCell.classList.add("delay-cell");
            saveCell(aCell);
        }

    });
}








/* ================= CSV ================= */
function exportCSV(){
    let csv="\uFEFF";
    document.querySelectorAll("#pmTable tr").forEach(tr=>{
        let row=[];
        tr.querySelectorAll("th,td").forEach(td=>{
            row.push(td.innerText.trim());
        });
        csv+=row.join(",")+"\n";
    });

    const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"});
    const a=document.createElement("a");
    a.href=URL.createObjectURL(blob);
    a.download="PM_Monthly.csv";
    a.click();
}

/* ================= PAGINATION ================= */
function renderPagination(){
    const totalPages=Math.ceil(machines.length/ITEMS_PER_PAGE);
    const div=document.getElementById("pagination");
    div.innerHTML="";

    for(let p=1;p<=totalPages;p++){
        const btn=document.createElement("button");
        btn.innerText=p;
        if(p===currentPage){
            btn.style.background="#1e40af";
            btn.style.color="#fff";
        }
        btn.onclick=()=>loadTable(monthSel.value,yearSel.value,p);
        div.appendChild(btn);
    }
}

monthSel.onchange = yearSel.onchange = ()=>loadTable(monthSel.value,yearSel.value,1);


// โหลดทันทีตอนเปิดหน้า
loadTable(monthSel.value, yearSel.value, 1);
