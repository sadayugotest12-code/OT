const canEdit = document.body.dataset.canEdit === "true";

function apiSave(id){
if (!canEdit) return;
fetch("/api/pm/save",{
method:"POST",
headers:{'Content-Type':'application/json'},
body:JSON.stringify({id})
});
}

function apiDelete(id){
if (!canEdit) return;
fetch("/api/pm/delete",{
method:"POST",
headers:{'Content-Type':'application/json'},
body:JSON.stringify({id})
});
}


  const monthNames = [
  "Jan","Feb","Mar","Apr","May","Jun",
  "Jul","Aug","Sep","Oct","Nov","Dec"
];



const fsBtn = document.getElementById("fsBtn");

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
    fsBtn.textContent = "ออกจากเต็มจอ";
  } else {
    document.exitFullscreen();
    fsBtn.textContent = "แตะเพื่อแสดงเต็มจอ";
  }
}

fsBtn.addEventListener("click", toggleFullscreen);



function updateStickyHeaderOffsets() {
  const thead = document.querySelector("#pmTable thead");
  const headerRows = thead.querySelectorAll("tr");

  thead.style.setProperty(
    "--header-row-1-height",
    `${headerRows[0].getBoundingClientRect().height}px`
  );
  thead.style.setProperty(
    "--header-row-2-height",
    `${headerRows[1].getBoundingClientRect().height}px`
  );
}

updateStickyHeaderOffsets();
window.addEventListener("resize", updateStickyHeaderOffsets);


Promise.all([
  fetch("/api/pm/load").then(r=>r.json()),
  fetch("/api/profile/load").then(r=>r.json())
])
.then(([pmRows, proRows])=>{

  pmData = {};

  pmRows.forEach(k=>pmData[k]=1);
  proRows.forEach(k=>pmData[k]=1);

  renderTable();
});



const pageSize = 20;   // เครื่องจักรต่อหน้า
let currentPage = 1;

function getPagedMachines() {
  const start = (currentPage - 1) * pageSize;
  return machines.slice(start, start + pageSize);
}


const machines = [
  { name:"Iron Melting Furnace m/c-2",model:"500 Hz",code:"MF-02-FC",group:"FC"},
  { name:"Iron Melting Furnace m/c-3",model:"500 Hz",code:"MF-03-FC",group:"FC"},    
  { name:"Iron Melting Furnace m/c-4",model:"500 Hz",code:"MF-04-FC",group:"FC"},
  { name:"Iron Melting Furnace m/c-5",model:"500 Hz",code:"MF-05-FC",group:"FC"},  
  { name:"Al.Crucibie gas holding furnace",model:"300kg",code:"MF-02-AL",group:"BC"},
    
    { name:"Al.Crucibie gas melting furnace",model:"2000kg",code:"MF-04-AL",group:"BC"},
    { name:"Gas Bubble fill",model:"LP",code:"GBF-02",group:"LP"},
    { name:"Gas Bubble fill",model:"BC",code:"GBF-03",group:"BC"},
    { name:"FC Casting line & BIg Ladle ",model:"FC",code:"FC-CL-02",group:"FC"},
    { name:"Al Casting line pouring",model:"BC",code:"AL-CL-02",group:"BC"},
    { name:"Casting machine",model:"LP",code:"LP-01",group:"LP"},
    { name:"Casting machine",model:"LP",code:"LP-02",group:"LP"},
    { name:"Shell MOld machine",model:"CT-650",code:"MO-01",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-02",group:"MO"},
    { name:"Shell MOld machine",model:"CT-650",code:"MO-03",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-04",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-05",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-06",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-07",group:"MO"},
    { name:"Shell Mold machine",model:"CT-865",code:"MO-08",group:"MO"},
    { name:"Shell Mold machine",model:"CT-865",code:"MO-09",group:"MO"},
    { name:"Shell Mold machine",model:"CT-650",code:"MO-10",group:"MO"},

    { name:"Shell Mold machine",model:"CT-650",code:"MO-12",group:"BC"},

    { name:"H-TOP mold making ",model:"750-B",code:"H-TOP-2",group:"MO"},
    { name:"H-TOP mold making ",model:"750-B",code:"H-TOP-3",group:"MO"},
    { name:"H-TOP mold making ",model:"750-small",code:"H-TOP-4",group:"MO"},
    { name:"H-TOP mold making ",model:"750-small",code:"H-TOP-5",group:"MO"},
    { name:"Shell core machine ",model:"TD-440",code:"CO-03",group:"CO"},
    { name:"Shell core machine ",model:"TD-440",code:"CO-04",group:"CO"},
    { name:"Shell core machine ",model:"TD-45AN",code:"CO-05",group:"CO"},
    { name:"Shell core machine ",model:"TD-45AN",code:"CO-06",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-07",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-08",group:"CO"},
  
    { name:"Shell core machine ",model:"TD-530",code:"CO-10",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-11",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-12",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-13",group:"CO"},
    
    { name:"Shell core machine ",model:"TD-530",code:"CO-15",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-16",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-17",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-18",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-19",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-20",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-21",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-22",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-23",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-24",group:"CO"},
    { name:"Shell core machine ",model:"TD-530",code:"CO-25",group:"CO"},
    { name:"Shot Blasting machine",model:"TC-120",code:"SB-01",group:"PP"},
    { name:"Shot Blasting machine",model:"TC-120",code:"SB-02",group:"PP"},
    { name:"Shot Blasting machine",model:"PFH-67",code:"SB-05",group:"PP"},
    { name:"Shot Blasting machine",model:"GW-10",code:"SB-GW-10",group:"PP"},
    { name:"Shot Blasting machine",model:"SNB-II",code:"SB-Sinto-01",group:"PP"},
    { name:"Shot Blasting machine",model:"IRH-9",code:"SB-IRH-9",group:"PP"},
    { name:"Shot Blasting machine",model:"SNB-II",code:"SB-Sinto-02",group:"PP"},
    { name:"Shot Blasting machine",model:"SNB-II",code:"SB-Sinto-03",group:"PP"},
    { name:"Shot Blasting machine",model:"TC-312DM-AD",code:"SB-TC-312DM",group:"PP"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-01",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-02",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-03",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-04",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-05",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-06",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-07",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL-08",group:"FCDB"},
   
    { name:"Test Leak machine",model:"Cosmo",code:"TL-10",group:"FCDB"},
    { name:"Test Leak machine",model:"Cosmo",code:"TL",group:"BC"},

    { name:"Heat Treatment furnace",model:"PP",code:"HE-01",group:"PP"},
    { name:"Heat Treatment furnace",model:"PP",code:"HE-02",group:"HT"},
    { name:"Heat Treatment furnace",model:"PP",code:"HE-03",group:"HT"},
    { name:"Magnetic tester machine",model:"FCDB",code:"MGT-01",group:"FCDB"},
    { name:"Knock out",model:"BC",code:"KO-03",group:"BC"},
    { name:"Riser cutting machine",model:"BC",code:"CT-03-BC",group:"BC"},
    { name:"Riser cutting machine",model:"Taiwan",code:"CT-04-LP",group:"LP"},
    { name:"Riser cutting machine",model:"Indo",code:"CT-05-BC",group:"BC"},
    { name:"DMC mark",model:"DMC",code:"DMC-01",group:"FCDB"},
    { name:"DMC mark",model:"DMC",code:"DMC-02",group:"FCDB"},
    { name:"CNC Lathe",model:"TC-3-01",code:"CNC-L-04",group:"FCDB"},
    { name:"CNC Lathe",model:"TC-3-02",code:"CNC-L-05",group:"BC"},
    { name:"CNC Machine Center",model:"Kira",code:"CNC-M-01",group:"FCDB"},
    { name:"CNC Machine Center",model:"Brother",code:"TC-S2A-01",group:"FCDB"},
    { name:"CNC Machine Center",model:"Brother",code:"TC-S2A-04",group:"FCDB"},
    { name:"CNC Machine Center",model:"Brother",code:"TC-S2A-05",group:"FCDB"},
    { name:"Boring machine",model:"FCDB",code:"Boring-01",group:"FCDB"},
    { name:"Boring machine",model:"FCDB",code:"Boring-02",group:"BC"},
    { name:"Crane",model:"DEMAG",code:"Crane-1-1",group:"MO"},
    { name:"Crane",model:"DEMAG",code:"Crane-1-2",group:"BC"},
    { name:"Crane",model:"DEMAG",code:"Crane-1-3",group:"CO"},
    { name:"Crane",model:"DEMAG",code:"Crane-1-4",group:"CO"},
    { name:"Crane",model:"DEMAG",code:"Crane-1-5",group:"FC"},
    { name:"Crane",model:"KONE",code:"Crane-1-6",group:"PP"},
    { name:"Crane",model:"KONE",code:"Crane-1-10",group:"FC"},
    { name:"Crane",model:"KONE",code:"Crane-1-11",group:"FC(DM)"},
    { name:"Hoist",model:"1 TON",code:"CH-01-FC2",group:"FC"},
    { name:"Hoist",model:"1 TON",code:"CH-02-FC2",group:"FC"},
    { name:"Hoist",model:"2 TON",code:"CH-03-FC2",group:"FC"},
    { name:"Hoist",model:"2 TON",code:"CH-04-FC2",group:"FC"},
    { name:"Hoist",model:"4 TON",code:"CH-05-FC2",group:"FC"},
    { name:"Hoist",model:"Air Hoist",code:"CH-06-FC2",group:"FC"},
    { name:"Auto Pouring",model:"Pro1500",code:"Puma Machine",group:"FC"},
    { name:"Auto Deburing",model:"TX6i-FDS12R-331GR",code:"331GR-01",group:"FCDB"},
    { name:"Auto Deburing",model:"TX6i-FDS22R-455GR",code:"445GR-01",group:"FCDB"},
    { name:"Auto Deburing",model:"TX6i-FDS12R-331GR",code:"331GR-02",group:"FCDB"},
    { name:"Auto Deburing",model:"TX6i-FDS12R-331GR",code:"331GR-03",group:"FCDB"},
    { name:"Auto Deburing",model:"TX6i-FDS12R-331GR",code:"331GR-04",group:"FCDB"},
    { name:"Sand Blast",model:"FDHV-3-A-SD-NV-502-J",code:"Sand Blast",group:"FCDB"},
   
];


const yearSelect = document.getElementById("yearSelect");
let pmData = {}; 
// key = machine_year_month_week_type  value = 1

function keyOf(mc, y, m, w, type) {
  return `${mc}_${y}_${m}_${w}_${type}`;
}


/* Toggle cell จุด */
function toggleCell(td, key, type) {
  if (!canEdit) return;

  if (!pmData[key]) {

    td.innerText = type;
    td.classList.add(type === "P" ? "p" : "a");

    pmData[key] = 1;
    apiSave(key);

  } else {

    td.innerText = "";
    td.classList.remove("p", "a");

    delete pmData[key];
    apiDelete(key);
  }
}



function togglePro(td, mc, year, type) {
  if (!canEdit) return;

  const key = `PRO_${mc}_${year}_${type}`;

  if (td.innerText === "●") {

    td.innerText = "";
    td.classList.remove("on");

    delete pmData[key];
    apiDelete(key);

  } else {

    td.innerText = "●";
    td.classList.add("on");

    pmData[key] = 1;
    apiSave(key);

    const other = type === "FC" ? "AL" : "FC";
    const otherKey = `PRO_${mc}_${year}_${other}`;

    delete pmData[otherKey];
    apiDelete(otherKey);

    const otherCell = td.parentElement.querySelector(
      type === "FC" ? ".sticky-al" : ".sticky-fc"
    );
    if (otherCell) {
      otherCell.innerText = "";
      otherCell.classList.remove("on");
    }
  }
}



function renderTable() {
  const tbody = document.getElementById("tableBody");
  tbody.innerHTML = "";

  const year = yearSelect.value;

  getPagedMachines().forEach((mc, i) => {


    ["P","A"].forEach((type) => {
  const tr = document.createElement("tr");

  if (type === "P") {
  tr.innerHTML += `<td rowspan="2" class="no-column sticky-col sticky-no">${(currentPage-1)*pageSize + i + 1}</td>`;
  tr.innerHTML += `<td rowspan="2" class="sticky-col sticky-name">${mc.name}</td>`;

  // ⭐⭐ เพิ่ม 2 ช่องที่หายไป ⭐⭐
  tr.innerHTML += `<td rowspan="2" class="sticky-col sticky-code">${mc.code}</td>`;
  tr.innerHTML += `<td rowspan="2" class="sticky-col sticky-group">${mc.group}</td>`;

  const fcKey = `PRO_${mc.name}_${year}_FC`;
  const alKey = `PRO_${mc.name}_${year}_AL`;

  tr.innerHTML += `
    <td rowspan="2" class="sticky-col sticky-fc dot ${pmData[fcKey] ? "on" : ""}"
        onclick="togglePro(this,'${mc.name}','${year}','FC')">
      ${pmData[fcKey] ? "●" : ""}
    </td>

    <td rowspan="2" class="sticky-col sticky-al dot ${pmData[alKey] ? "on" : ""}"
        onclick="togglePro(this,'${mc.name}','${year}','AL')">
      ${pmData[alKey] ? "●" : ""}
    </td>
  `;
}


  // 🔹 คอลัมน์ P / A (ต้องอยู่ตรงนี้เท่านั้น)
  tr.innerHTML += `<td class="sticky-col sticky-pa pa-label pa-label-${type.toLowerCase()}" data-type="${type}">${type}</td>`;

  // 🔹 ช่องเดือน 12 × 4 = 48 ช่อง
  for (let m = 1; m <= 12; m++) {
    for (let w = 1; w <= 4; w++) {
      const k = keyOf(mc.name, year, m, w, type);
      const checked = pmData[k];

      tr.innerHTML += `
        <td class="cell ${checked ? (type==="P"?"p":"a") : ""}"
            onclick="toggleCell(this,'${k}','${type}')">
          ${checked ? type : ""}
        </td>`;
    }
  }

  tbody.appendChild(tr);
});
  });

  updatePageInfo();
}

/* ✅ reload PRO ทุกครั้งที่ render */



function totalPages() {
  return Math.ceil(machines.length / pageSize);
}

function updatePageInfo() {
  document.getElementById("pageInfo").innerText =
    `Page ${currentPage} / ${totalPages()}`;
}

function prevPage() {
  if (currentPage > 1) {
    currentPage--;
    renderTable();
  }
}

function nextPage() {
  if (currentPage < totalPages()) {
    currentPage++;
    renderTable();
  }
}


yearSelect.onchange = renderTable;
renderTable();


function exportCSV() {

  const year = yearSelect.value; // 🔥 FIX ตัวจริง

  if (!machines || machines.length === 0) {
    alert("ไม่พบข้อมูลเครื่อง");
    return;
  }

  let csv = [];

  let header = [
    "No","M/C Name","M/C-Code","M/C-Group","Pro.FC","Pro.AL","P/A"
  ];

  for (let m = 1; m <= 12; m++) {
    for (let w = 1; w <= 4; w++) {
      header.push(`${monthNames[m-1]}-W${w}`);
    }
  }
  csv.push(header.map(csvSafe).join(","));

  machines.forEach((mc, i) => {
    ["P","A"].forEach(type => {

      let row = [
        i+1,
        mc.name,
        mc.code,
        mc.group
      ];

      const fcKey = `PRO_${mc.name}_${year}_FC`;
      const alKey = `PRO_${mc.name}_${year}_AL`;

      row.push(pmData[fcKey] ? "●" : "");
      row.push(pmData[alKey] ? "●" : "");
      row.push(type);

      for (let m = 1; m <= 12; m++) {
        for (let w = 1; w <= 4; w++) {
          const k = keyOf(mc.name, year, m, w, type);
          row.push(pmData[k] ? type : "");
        }
      }

      csv.push(row.map(csvSafe).join(","));
    });
  });

  downloadCSV(csv.join("\n"), year);
}


  // ===== DOWNLOAD =====
  function downloadCSV(text, year) {
  const blob = new Blob(["\ufeff" + text], {
    type: "text/csv;charset=utf-8;"
  });

  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = `MT1_PM_Yearly_Plan_${year}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  URL.revokeObjectURL(url);
}

function csvSafe(v) {
  if (v === null || v === undefined) return "";
  return `"${String(v).replace(/"/g, '""')}"`;
}

document.getElementById("clearPM").onclick = ()=>{

  if (!canEdit) return;

  if(!confirm("ลบ PM ทั้งปี ?")) return;

  fetch("/api/pm/clear",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({
      year: yearSelect.value
    })
  })
  .then(()=> fetch("/api/pm/load"))
  .then(r=>r.json())
  .then(rows=>{

    pmData = {};
    rows.forEach(k=>pmData[k] = 1);

    renderTable();   // ⭐ redraw จาก DB จริง
  });

};
