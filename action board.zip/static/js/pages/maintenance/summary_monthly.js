const fsBtn = document.getElementById("fsBtn");

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
    fsBtn.textContent = "ออกจากเต็มจอ";
  } else {
    document.exitFullscreen();
    fsBtn.textContent = "แตะเพื่อแสดงเต็มจอ";
  }
}

fsBtn.addEventListener("click", toggleFullscreen);



const monthNames=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const monthSel=document.getElementById("month");
const yearSel=document.getElementById("year");

monthNames.forEach((m,i)=>monthSel.innerHTML+=`<option value="${i+1}">${m}</option>`);
for(let y=2025;y<=2035;y++) yearSel.innerHTML+=`<option>${y}</option>`;

monthSel.value=new Date().getMonth()+1;
yearSel.value=new Date().getFullYear();

let summaryChart;

/* ================= LOAD FROM SERVER ================= */

function loadSummary(){

    fetch(`http://27.254.143.93:5000/api/pm_monthly/load?year=${yearSel.value}&month=${monthSel.value}`)
    .then(r=>r.json())
    .then(rows=>{

        const days=new Date(yearSel.value,monthSel.value,0).getDate();
        const dailyP=Array(days).fill(0);
        const dailyA=Array(days).fill(0);

        rows.forEach(r=>{
            const d=parseInt(r.day)-1;
            if(r.status==="P") dailyP[d]++;
            if(r.status==="A") dailyA[d]++;
        });

        drawCombinedChart(dailyP,dailyA);
    });
}


/* ================= COMBINED BAR + LINE ================= */

function drawCombinedChart(dailyP,dailyA){

    if(summaryChart) summaryChart.destroy();

    const cumP=[], cumA=[];
    dailyP.reduce((s,v,i)=>(cumP[i]=s+v),0);
    dailyA.reduce((s,v,i)=>(cumA[i]=s+v),0);

    summaryChart = new Chart(document.getElementById("summaryChart"),{
        data:{
            labels: dailyP.map((_,i)=>i+1),
            datasets:[

                // BAR
                {
                    type:"bar",
                    label:"Plan (P)",
                    data:dailyP,
                    backgroundColor:"#3b82f6",
                    yAxisID:"y"
                },
                {
                    type:"bar",
                    label:"Actual (A)",
                    data:dailyA,
                    backgroundColor:"#42bd41",
                    yAxisID:"y"
                },

                // LINE
                {
                    type:"line",
                    label:"Cumulative P",
                    data:cumP,
                    borderColor:"#7e57c2",
                    borderWidth:2,
                    tension:.3,
                    yAxisID:"y1"
                },
                {
                    type:"line",
                    label:"Cumulative A",
                    data:cumA,
                    borderColor:"#F6C8B6",
                    borderWidth:2,
                    tension:.3,
                    yAxisID:"y1"
                }
            ]
        },
        options:{
            responsive:true,
            interaction:{mode:"index",intersect:false},
            scales:{
                y:{
                    beginAtZero:true,
                    position:"left",
                    title:{display:true,text:"Job"}
                },
                y1:{
                    beginAtZero:true,
                    position:"right",
                    grid:{drawOnChartArea:false},
                    title:{display:true,text:"Cumulative"}
                }
            }
        }
    });
}


/* ================= PDF ================= */

async function exportPDF(){

    const { jsPDF }=window.jspdf;
    const canvas=await html2canvas(graphArea,{scale:2});

    const pdf=new jsPDF("landscape","mm","a4");
    const w=pdf.internal.pageSize.getWidth();
    const h=canvas.height*w/canvas.width;

    pdf.addImage(canvas.toDataURL(),"PNG",0,15,w,h);
    pdf.save(`PM_${yearSel.value}_${monthSel.value}.pdf`);
}

loadSummary();
