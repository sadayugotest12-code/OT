const fsBtn = document.getElementById("fsBtn");
const layoutBtn = document.getElementById("layoutBtn");
const grid = document.querySelector(".grid");

layoutBtn.addEventListener("click", () => {
  const compact = grid.classList.toggle("compact");
  layoutBtn.textContent = compact ? "▦ 3×3" : "▦ Compact";
  layoutBtn.setAttribute("aria-pressed", String(compact));
});

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
    fsBtn.textContent = "ออกจากเต็มจอ";
  } else {
    document.exitFullscreen();
    fsBtn.textContent = "เต็มจอ";
  }
}

fsBtn.addEventListener("click", toggleFullscreen);


function updateClock(){
  const now=new Date();
  document.getElementById("clock").innerText=
    now.toLocaleDateString()+"  "+now.toLocaleTimeString();
}
setInterval(updateClock,1000);
updateClock();

/* สำหรับเลือกแสดง หน่วยงาน */
function changeFactory(factory){
    window.location.href = "/set_factory/" + factory;
}

