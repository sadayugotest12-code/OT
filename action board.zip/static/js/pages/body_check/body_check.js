const fsBtn = document.getElementById("fsBtn");
const rootStyle = document.documentElement;
const VALID_FACTORIES = ["mt1", "mt2", "mt3", "ut"];
let pageFactory = VALID_FACTORIES.includes(document.body.dataset.factory)
  ? document.body.dataset.factory
  : "mt1";
let totalPeople = 11;

function getStorageKey(prefix) {
  return `${prefix}:${pageFactory}`;
}

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen().catch(() => {
      fsBtn.textContent = "เต็มจอใช้ไม่ได้";
    });
  } else {
    document.exitFullscreen().catch(() => {});
  }
}

fsBtn.addEventListener("click", toggleFullscreen);

function updateFactoryTab() {
  document.querySelectorAll(".factory-tabs button").forEach(button => {
    const isActive = button.dataset.factory === pageFactory;
    button.classList.toggle("active", isActive);
    button.setAttribute("aria-pressed", String(isActive));
  });

  const factoryName = document.getElementById("factoryName");
  if (factoryName) factoryName.textContent = `Section : ${pageFactory.toUpperCase()}`;
}

async function changeFactory(newFactory) {
  if (!VALID_FACTORIES.includes(newFactory) || newFactory === pageFactory) return;

  pageFactory = newFactory;
  document.body.dataset.factory = pageFactory;
  updateFactoryTab();

  const table = document.getElementById("healthTable");
  table.querySelectorAll(".dot").forEach(dot => dot.remove());
  await loadEmployeeProfiles();
  checkNewDay();
  loadStatus();
  updateLayoutMetrics();
}

document.querySelectorAll(".factory-tabs button").forEach(button => {
  button.addEventListener("click", () => changeFactory(button.dataset.factory));
});

function updateLayoutMetrics() {
  const table = document.getElementById("healthTable");
  const statusCell = table.querySelector('tr[data-row] td[data-col]');
  const nameCell = table.querySelector('tr.name td[data-col]');

  if (!statusCell) {
    return;
  }

  const statusRect = statusCell.getBoundingClientRect();
  const nameRect = nameCell ? nameCell.getBoundingClientRect() : statusRect;
  const dotSize = Math.max(18, Math.min(34, statusRect.height * 0.5, statusRect.width * 0.32));
  const statusFontSize = Math.max(12, Math.min(18, statusRect.height * 0.26));
  const profileFontSize = Math.max(11, Math.min(14, nameRect.height * 0.18));
  const profileImageSize = Math.max(22, Math.min(38, nameRect.height * 0.42));

  rootStyle.style.setProperty("--dot-size", `${dotSize}px`);
  rootStyle.style.setProperty("--status-font-size", `${statusFontSize}px`);
  rootStyle.style.setProperty("--profile-font-size", `${profileFontSize}px`);
  rootStyle.style.setProperty("--profile-image-size", `${profileImageSize}px`);
}

function readStatus() {
  try {
    const value = JSON.parse(localStorage.getItem(getStorageKey("healthStatus")) || "{}");
    return value && typeof value === "object" && !Array.isArray(value) ? value : {};
  } catch (error) {
    localStorage.removeItem(getStorageKey("healthStatus"));
    return {};
  }
}

function updateSummary(status) {
  const selected = Object.keys(status).length;
  const count = document.getElementById("selectedCount");
  const updated = document.getElementById("lastUpdated");
  if (count) count.textContent = `เลือกแล้ว ${selected} / ${totalPeople} คน`;
  if (updated) updated.textContent = `อัปเดตล่าสุด ${new Date().toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" })}`;
}

/* ===== ตรวจวันใหม่ (หลังเที่ยงคืน) ===== */
function checkNewDay() {
  const today = new Date().toDateString();
  const dateKey = getStorageKey("healthStatusDate");
  const savedDate = localStorage.getItem(dateKey);

  if (savedDate !== today) {
    resetToOffWork();
    localStorage.setItem(dateKey, today);
  }
}

/* ===== รีเซ็ตทุกคนไปที่ เลิกงาน ===== */
function resetToOffWork() {
  const table = document.getElementById("healthTable");
  table.querySelectorAll(".dot").forEach(d => d.remove());

  const status = {};
  table.querySelectorAll('tr[data-row="off"] td[data-col]').forEach(td => {
    const col = td.dataset.col;
    const personCell = table.querySelector(`tr.name td[data-col="${col}"]`);
    const personKey = personCell?.dataset.empCode || `column:${col}`;
    const dot = document.createElement("div");
    dot.className = "dot";
    td.appendChild(dot);
    status[personKey] = "off";
  });

  localStorage.setItem(getStorageKey("healthStatus"), JSON.stringify(status));
}

/* ===== เลือกสถานะ ===== */
function selectStatus(cell) {
  const col = cell.dataset.col;
  const row = cell.closest("tr").dataset.row;
  const table = document.getElementById("healthTable");
  const personCell = table.querySelector(`tr.name td[data-col="${col}"]`);
  const personKey = personCell?.dataset.empCode || `column:${col}`;

  // ลบจุดเดิมในคอลัมน์
  table.querySelectorAll(`[data-col="${col}"] .dot`).forEach(d => d.remove());

  // ใส่จุดใหม่
  const dot = document.createElement("div");
  dot.className = "dot";
  cell.appendChild(dot);

  // บันทึก
  const status = readStatus();
  status[personKey] = row;
  localStorage.setItem(getStorageKey("healthStatus"), JSON.stringify(status));
  updateSummary(status);
}

/* ===== โหลดสถานะกลับมา ===== */
function loadStatus() {
  const table = document.getElementById("healthTable");
  table.querySelectorAll(".dot").forEach(dot => dot.remove());
  const savedStatus = readStatus();
  const status = {};
  const usedColumns = new Set();

  Object.entries(savedStatus).forEach(([personKey, row]) => {
    let col = null;
    if (personKey.startsWith("column:")) {
      col = personKey.slice("column:".length);
    } else {
      const personCell = [...table.querySelectorAll("tr.name td[data-emp-code]")]
        .find(cell => cell.dataset.empCode === personKey);
      col = personCell?.dataset.col;
    }

    if (col === null || col === undefined || usedColumns.has(col)) return;
    const cell = table.querySelector(
      `tr[data-row="${row}"] td[data-col="${col}"]`
    );
    if (cell) {
      usedColumns.add(col);
      status[personKey] = row;
      const dot = document.createElement("div");
      dot.className = "dot";
      cell.appendChild(dot);
    }
  });
  localStorage.setItem(getStorageKey("healthStatus"), JSON.stringify(status));
  updateSummary(status);
  repairProfileImages();
}

  function repairProfileImages() {
    document.querySelectorAll(".profile img").forEach((image) => {
    if (image.nextElementSibling?.classList.contains("avatar-fallback")) return;
      const fallback = document.createElement("span");
      fallback.className = "avatar-fallback";
      fallback.textContent = image.nextElementSibling?.textContent?.trim()?.slice(0, 2) || "ID";
      image.insertAdjacentElement("afterend", fallback);
      image.addEventListener("error", () => {
        image.classList.add("broken");
        fallback.classList.add("visible");
      }, { once: true });
    });
  }

  async function loadEmployeeProfiles() {
    const cells = [...document.querySelectorAll("tr.name td")].slice(1);
    try {
      const response = await fetch(`/api/employees?factory=${encodeURIComponent(pageFactory)}`);
      if (!response.ok) throw new Error(`Employee API returned ${response.status}`);
      const employees = await response.json();
      totalPeople = employees.length || 11;
      updateSummary(readStatus());
      const usedNames = new Set();

      employees.slice(0, cells.length).forEach((employee, index) => {
        const cell = cells[index];
        const employeeCode = String(employee.emp_code || `column:${index}`);
        const baseName = String(employee.emp_name || employeeCode).trim();
        const displayName = usedNames.has(baseName)
          ? `${baseName} (${employeeCode})`
          : baseName;
        usedNames.add(baseName);

        cell.dataset.col = String(index);
        cell.dataset.empCode = employeeCode;
        const name = cell.querySelector(".profile span:last-child");
        const image = cell.querySelector(".profile img");
        if (name) name.textContent = displayName;
        if (image && employee.avatar) {
          image.src = `/static/images.${pageFactory}/${encodeURIComponent(employee.avatar)}`;
        }
      });
    } catch (error) {
    }
  }

/* ===== เริ่มทำงาน ===== */
updateFactoryTab();
loadEmployeeProfiles().then(() => {
  checkNewDay();
  loadStatus();
  updateLayoutMetrics();
});
updateLayoutMetrics();

window.addEventListener("resize", updateLayoutMetrics);
document.addEventListener("fullscreenchange", () => {
  fsBtn.textContent = document.fullscreenElement ? "ออกจากเต็มจอ" : "แสดงเต็มจอ";
  updateLayoutMetrics();
});
