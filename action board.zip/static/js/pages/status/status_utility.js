const employees = [
  {name:"xxxx", avatar:"xxxx.jpg"},
  {name:"xxxx ", avatar:"xxab.jpg"},
  {name:"xxxx ", avatar:"xxxsiam.jpg"},
  {name:"xxxx", avatar: "xxxbat.jpg"},
  {name:"xxxxx  ", avatar: "xxxxk.jpg"},
  {name:"xxxxx ", avatar: "xxxx.jpg"},
  {name:"xxxxx ", avatar: "xxp.jpg"},
  {name:"xxxx", avatar: "xxxro.jpg"}

];

document.querySelector("table tbody").insertAdjacentHTML("beforeend", employees.map(emp => `
<tr>

<td class="emp-name">
  <img src="/static/images.mt2/${emp.avatar}"
       class="avatar">

  ${emp.name}
</td>

${["mt","ypmt1","ypmt2","ypmt3","ypmt4","ypmt5"].map((f,i)=>`
<td>
  <input type="checkbox"
         class="status-check"
         data-name="${emp.name}"
         data-field="${f}"
         data-color="${["green","blue","purple","yellow","orange","pink"][i]}">
</td>
`).join("")}

</tr>
`).join(""));

const now = new Date();
const todayKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
const storageKey = `status_ut_${todayKey}`;
const scrollStorageKey = `location-scroll:${window.location.pathname}`;

window.addEventListener("pagehide", () => {
  sessionStorage.setItem(scrollStorageKey, String(window.scrollY));
});




  const navigation = performance.getEntriesByType("navigation")[0];
  const savedScrollY = sessionStorage.getItem(scrollStorageKey);
  sessionStorage.removeItem(scrollStorageKey);
  if(navigation?.type === "reload" && savedScrollY !== null){
    requestAnimationFrame(() => window.scrollTo(0, Number(savedScrollY)));
  }
const machineByField = {
  mt: ["MT1","MT2","MT3","MT5","FRONT OFFICE"],

ypmt1  : ["CAM SHAFT LINE NO.4","CAM SHAFT LINE NO.6","CAM SHAFT LINE NO.6","CAM SHAFT LINE NO.7",
        "CAM SHAFT LINE NO.8","CAM SHAFT LINE NO.9(AUTO LOAD 1)","CAM SHAFT LINE NO.10(AUTO LOAD 2)",
        "CAM SHAFT LINE NO.11","CAM SHAFT LINE NO.12 P4#1","CAM SHAFT LINE NO.12 P4#2","CAM SHAFT LINE NO.12 P4#3"
      ],

ypmt2 : ["MTA B/H OP1-2 C1","MTA B/H OP1-2 C2","MTA B/H OP1-2 C3","MTA B/H OP3-10 C1",
      "MTA B/H OP3-10 C2","MTA B/H OP3-10 C3","IHI ET30 ROUGH B/H NO.1","IHI ET30 ROUGH B/H NO.2",
      "IHI ET30 ROUGH B/H OP10-20 C1","IHI ET30 ROUGH B/H OP10-20 C2","IHI ET30 ROUGH B/H OP10-20 C3",
      "IHI ET30 ROUGH B/H OP30-100 C1","IHI ET30 ROUGH B/H OP30-100 C2","IHI ET30 ROUGH B/H OP30-100 C3"
      ],

ypmt3 :["BB8 CASE FAN.BB8 ASSIST GRIP,6EG","COM726-727","COM251,COM290","BRKT6700-6710",
      "NEW 7 PARTS AAT(A380)"
       ],


};



const fsBtn = document.getElementById("fsBtn");

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
    fsBtn.textContent = "ออกจากเต็มจอ";
  } else {
    document.exitFullscreen();
    fsBtn.textContent = "แตะเพื่อแสดงเต็มจอ";
  }
}

fsBtn.addEventListener("click", toggleFullscreen);



document.getElementById("date").innerText =
new Date().toLocaleDateString("th-TH",{weekday:"long",year:"numeric",month:"long",day:"numeric"});


let activeCheckbox=null;

document.querySelectorAll(".status-check").forEach(cb=>{
  cb.addEventListener("change",()=>{
    if(cb.checked){
  activeCheckbox = cb;

  const field = cb.dataset.field;   // fc / mo / core / bc
  const select = document.getElementById("machineSelect");

  // ล้างรายการเดิม
  select.innerHTML = `<option value="">-- เลือก --</option>`;

  // ใส่เฉพาะรหัสเครื่องของคอลัมน์นั้น
  if(machineByField[field]){
    machineByField[field].forEach(mc=>{
      const opt = document.createElement("option");
      opt.value = mc;
      opt.textContent = mc;
      select.appendChild(opt);
    });
  }

  machinePopup.style.display = "flex";


    }else{
      cb.dataset.machine="";
      cb.closest("td").style.background="";
      updateSummary();
      saveToLocal(cb);

    }
  });
});



function saveToLocal(changedCheckbox){
  const data = [];

  document.querySelectorAll(".status-check").forEach(cb=>{
    if(cb.checked){
      data.push({
        name: cb.dataset.name,
        field: cb.dataset.field,
        machine: cb.dataset.machine || ""
      });
    }
  });

  localStorage.setItem(storageKey, JSON.stringify(data));

  if(changedCheckbox){
    fetch("/api/location/status", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        date: todayKey,
        name: changedCheckbox.dataset.name,
        field: changedCheckbox.dataset.field,
        machine: changedCheckbox.dataset.machine || "",
        selected: changedCheckbox.checked
      })
    }).then(response => {
      if(!response.ok) throw new Error(`บันทึกไม่สำเร็จ (${response.status})`);
    }).catch(error => console.error("บันทึกสถานะ Location ไม่สำเร็จ", error));
  }
}

async function loadFromLocal(){
  let saved;
  try{
    const response = await fetch(`/api/location/status?date=${encodeURIComponent(todayKey)}`);
    if(!response.ok) throw new Error(`โหลดไม่สำเร็จ (${response.status})`);
    saved = await response.json();
    localStorage.setItem(storageKey, JSON.stringify(saved));
  }catch(error){
    saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
    console.error("โหลดสถานะ Location จากฐานข้อมูลไม่สำเร็จ", error);
  }
  
  // สร้าง colorMap ไว้ใช้ซ้ำ
  const colorMap = {
    green: "#c6efce", blue: "#cfe2ff", purple: "#e2d9f3", 
    red: "#f8cbad", yellow: "#fff2cc", orange: "#fce5cd"
  };

  saved.forEach(item=>{
    const cb = document.querySelector(
      `.status-check[data-name="${item.name}"][data-field="${item.field}"]`
    );
    if(cb){
      cb.checked = true;
      cb.dataset.machine = item.machine;
      if(item.machine){
        // ใช้ colorMap แทน getComputedStyle เพื่อความชัวร์
        cb.closest("td").style.background = colorMap[cb.dataset.color] || "#fff";
      }
    }
  });

  updateSummary();
}



function updateSummary() {
    const counts = { mt: 0, ypmt1: 0, ypmt2: 0 ,ypmt3:0 , ypmt4:0 ,ypmt5:0 };
    const details = { mt: [], ypmt1: [], ypmt2: [] , ypmt3: [] , ypmt4:[] , ypmt5: []};

    document.querySelectorAll(".status-check:checked").forEach(cb => {
        const field = cb.dataset.field;
        const name = cb.dataset.name;
        const mc = cb.dataset.machine || "ไม่ระบุ";

        if (counts.hasOwnProperty(field)) {
            counts[field]++;
            details[field].push(`${name} (${mc})`);
        }
    });

    // อัปเดตตัวเลขและ Tooltip
    for (const key in counts) {
        const span = document.getElementById(key);
        const tip = document.getElementById(key + "Tip");
        if (span) span.innerText = `${key.toUpperCase()}: ${counts[key]}`;
        if (tip) tip.innerText = details[key].length > 0 ? details[key].join("\n") : "ไม่มีข้อมูล";
    }
}

// ปรับปรุงฟังก์ชัน confirmMachine ให้ดึงสีได้แน่นอนขึ้น
function confirmMachine(){
    const v = document.getElementById("machineSelect").value;
    if(!v) return alert("โปรดเลือกรหัสเครื่อง");
    
    activeCheckbox.dataset.machine = v;
    
    // กำหนดสี Map ตาม field โดยตรงเพื่อความชัวร์
    const colorMap = {
        green: "#c6efce", blue: "#cfe2ff", purple: "#e2d9f3", 
        red: "#f8cbad", yellow: "#fff2cc", orange: "#fce5cd"
    };
    
    const colorClass = activeCheckbox.dataset.color;
    activeCheckbox.closest("td").style.background = colorMap[colorClass] || "#fff";
    
    document.getElementById("machinePopup").style.display = "none";
    updateSummary();
    saveToLocal(activeCheckbox);
}



function cancelMachine(){
  if(activeCheckbox){
    activeCheckbox.checked = false;      // เอาติ๊กออก
    activeCheckbox.dataset.machine = "";
    activeCheckbox.closest("td").style.background = "";
  }
  closePopup();
}

function cancelPopup(e){
  if(e.target.id === "machinePopup"){
    cancelMachine(); // คลิกพื้นหลังมืด
  }
}

function closePopup(){
  document.getElementById("machinePopup").style.display = "none";
  document.getElementById("machineSelect").value = "";
  activeCheckbox = null;
}


loadFromLocal();
