const employees = [
  {name:"AA", avatar:"xarongrit.jpg"},
  {name:"BB ", avatar:"xnupong.jpg"},
  {name:"CC ", avatar:"xen.jpg"},
  {name:"DD", avatar: "xattawat.jpg"},
  {name:"EE ", avatar: "xorakoch.jpg"},
  {name:"FF ", avatar: "xutep.jpg"},
  {name:"GG", avatar: "xhanachai.jpg"},
  {name:"HH", avatar: "xhanakon.jpg"},
  {name:"II", avatar: "xhaiya.jpg"}
];

document.querySelector("table tbody").insertAdjacentHTML("beforeend", employees.map(emp => `
<tr>

<td class="emp-name">
  <img src="/static/images.mt2/${emp.avatar}"
       class="avatar">

  ${emp.name}
</td>

${["mt","fc2","mo","core","lp","bc","db"].map((f,i)=>`
<td>
  <input type="checkbox"
         class="status-check"
         data-name="${emp.name}"
         data-field="${f}"
         data-color="${["green","blue","purple","red","yellow","green","orange"][i]}">
</td>
`).join("")}

</tr>
`).join(""));

const now = new Date();
const todayKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
const storageKey = `status_mt1_${todayKey}`;
const scrollStorageKey = `location-scroll:${window.location.pathname}`;

window.addEventListener("pagehide", () => {
  sessionStorage.setItem(scrollStorageKey, String(window.scrollY));
});




  const navigation = performance.getEntriesByType("navigation")[0];
  const savedScrollY = sessionStorage.getItem(scrollStorageKey);
  sessionStorage.removeItem(scrollStorageKey);
  if(navigation?.type === "reload" && savedScrollY !== null){
    requestAnimationFrame(() => window.scrollTo(0, Number(savedScrollY)));
  }
const machineByField = {
  mt: ["MT1","MT2","MT3","MT5","FRONT OFFICE"],

  fc2: ["Air Hoist", "Bucket Conveyor No.4", "Bucket Conveyor No.5","Crane NO.1-5","Crusher Return","MF-02","MF-03","MF-04","MF-05",
  "Hoist EE.1","Hoist EE.2","HOist EE.5","Hydralic DRive unit","Overhead Line","Pouring Line","Preheat Ladle","Puma M/C",
  "Rotation Device","Transfer No.1","Transfer NO.2","X-Lift"],

  core: ["CO-03", "CO-04", "CO-05","CO-06","CO-08","CO-09","CO-10","CO-11","CO-12","CO-13","CO-15","CO-16","CO-17","CO-18","CO-19","CO-20",
    "CO-21","CO-22","CO-23","CO-24","CO-25","Crane No.1-3","Crane No.1-4"],

  mo: ["MO-01", "MO-02","MO-03","MO-04","MO-05","MO-06","MO-07","MO-08","MO-09","MO-10","H-TOP-02","H-TOP-03","H-TOP-04","H-TOP-05",
    "Crane-1-1"],

  lp:["LP-01", "LP-02","LP-Riser CUT-02(Taiwan)","GBF-02"],

  bc: ["Pouring", "MO-12","CO-07","CO-13","Body K/O-03","Body S/B PFH-67","Body Riser CUT-03","Body Riser CUT-05(Indo)",
    "Crane No.1-2","CNC-L-05(Takisawa)","Boring-02","MF-02 AL","MF-04 AL(Taiwan)","GBF-03","TL"],

  pp: ["Sinto-01", "Sinto-02","Sinto-03","TC-120 No.1","TC-120 No.2","IRH-9-2","HE-01(T6)","HE-02(T-2)","HE-03(T6 TW)",
  "Crane No.1-6","GW-10","Auto DB-01","TC-312DM-AD"],

  db: ["TL-01","TL-02","TL-03","TL-04","TL-05","TL-06","TL-07","TL-08","TL-09","TL-10","TL-11","MGT-01","DMV-01","DMC-02","DMC-03",
    "CNC-M-01 Kira","TC-S2A-01","TC-S2A-02","TC-S2A-03","TC-S2A-04","TC-S2A-05","Boring-01","Auto DB-02",
    "CNC-L-04(Takisawa)","Sandblast"]

};



const fsBtn = document.getElementById("fsBtn");

function toggleFullscreen() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
    fsBtn.textContent = "ออกจากเต็มจอ";
  } else {
    document.exitFullscreen();
    fsBtn.textContent = "แตะเพื่อแสดงเต็มจอ";
  }
}

fsBtn.addEventListener("click", toggleFullscreen);



document.getElementById("date").innerText =
new Date().toLocaleDateString("th-TH",{weekday:"long",year:"numeric",month:"long",day:"numeric"});


let activeCheckbox=null;

document.querySelectorAll(".status-check").forEach(cb=>{
  cb.addEventListener("change",()=>{
    if(cb.checked){
  activeCheckbox = cb;

  const field = cb.dataset.field;   // fc / mo / core / bc
  const select = document.getElementById("machineSelect");

  // ล้างรายการเดิม
  select.innerHTML = `<option value="">-- เลือก --</option>`;

  // ใส่เฉพาะรหัสเครื่องของคอลัมน์นั้น
  if(machineByField[field]){
    machineByField[field].forEach(mc=>{
      const opt = document.createElement("option");
      opt.value = mc;
      opt.textContent = mc;
      select.appendChild(opt);
    });
  }

  machinePopup.style.display = "flex";


    }else{
      cb.dataset.machine="";
      cb.closest("td").style.background="";
      updateSummary();
      saveToLocal(cb);

    }
  });
});



function saveToLocal(changedCheckbox){
  const data = [];

  document.querySelectorAll(".status-check").forEach(cb=>{
    if(cb.checked){
      data.push({
        name: cb.dataset.name,
        field: cb.dataset.field,
        machine: cb.dataset.machine || ""
      });
    }
  });

  localStorage.setItem(storageKey, JSON.stringify(data));

  if(changedCheckbox){
    fetch("/api/location/status", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        date: todayKey,
        name: changedCheckbox.dataset.name,
        field: changedCheckbox.dataset.field,
        machine: changedCheckbox.dataset.machine || "",
        selected: changedCheckbox.checked
      })
    }).then(response => {
      if(!response.ok) throw new Error(`บันทึกไม่สำเร็จ (${response.status})`);
    }).catch(error => console.error("บันทึกสถานะ Location ไม่สำเร็จ", error));
  }
}

async function loadFromLocal(){
  let saved;
  try{
    const response = await fetch(`/api/location/status?date=${encodeURIComponent(todayKey)}`);
    if(!response.ok) throw new Error(`โหลดไม่สำเร็จ (${response.status})`);
    saved = await response.json();
    localStorage.setItem(storageKey, JSON.stringify(saved));
  }catch(error){
    saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
    console.error("โหลดสถานะ Location จากฐานข้อมูลไม่สำเร็จ", error);
  }
  
  // สร้าง colorMap ไว้ใช้ซ้ำ
  const colorMap = {
    green: "#c6efce", blue: "#cfe2ff", purple: "#e2d9f3", 
    red: "#f8cbad", yellow: "#fff2cc", orange: "#fce5cd"
  };

  saved.forEach(item=>{
    const cb = document.querySelector(
      `.status-check[data-name="${item.name}"][data-field="${item.field}"]`
    );
    if(cb){
      cb.checked = true;
      cb.dataset.machine = item.machine;
      if(item.machine){
        // ใช้ colorMap แทน getComputedStyle เพื่อความชัวร์
        cb.closest("td").style.background = colorMap[cb.dataset.color] || "#fff";
      }
    }
  });

  updateSummary();
}



function updateSummary() {
    const counts = { mt: 0, fc2: 0, mo: 0, core: 0, lp: 0, bc: 0, pp: 0, db: 0 };
    const details = { mt: [], fc2: [], mo: [], core: [], lp: [], bc: [], pp: [], db: [] };

    document.querySelectorAll(".status-check:checked").forEach(cb => {
        const field = cb.dataset.field;
        const name = cb.dataset.name;
        const mc = cb.dataset.machine || "ไม่ระบุ";

        if (counts.hasOwnProperty(field)) {
            counts[field]++;
            details[field].push(`${name} (${mc})`);
        }
    });

    // อัปเดตตัวเลขและ Tooltip
    for (const key in counts) {
        const span = document.getElementById(key);
        const tip = document.getElementById(key + "Tip");
        if (span) span.innerText = `${key.toUpperCase()}: ${counts[key]}`;
        if (tip) tip.innerText = details[key].length > 0 ? details[key].join("\n") : "ไม่มีข้อมูล";
    }
}

// ปรับปรุงฟังก์ชัน confirmMachine ให้ดึงสีได้แน่นอนขึ้น
function confirmMachine(){
    const v = document.getElementById("machineSelect").value;
    if(!v) return alert("โปรดเลือกรหัสเครื่อง");
    
    activeCheckbox.dataset.machine = v;
    
    // กำหนดสี Map ตาม field โดยตรงเพื่อความชัวร์
    const colorMap = {
        green: "#c6efce", blue: "#cfe2ff", purple: "#e2d9f3", 
        red: "#f8cbad", yellow: "#fff2cc", orange: "#fce5cd"
    };
    
    const colorClass = activeCheckbox.dataset.color;
    activeCheckbox.closest("td").style.background = colorMap[colorClass] || "#fff";
    
    document.getElementById("machinePopup").style.display = "none";
    updateSummary();
    saveToLocal(activeCheckbox);
}



function cancelMachine(){
  if(activeCheckbox){
    activeCheckbox.checked = false;      // เอาติ๊กออก
    activeCheckbox.dataset.machine = "";
    activeCheckbox.closest("td").style.background = "";
  }
  closePopup();
}

function cancelPopup(e){
  if(e.target.id === "machinePopup"){
    cancelMachine(); // คลิกพื้นหลังมืด
  }
}

function closePopup(){
  document.getElementById("machinePopup").style.display = "none";
  document.getElementById("machineSelect").value = "";
  activeCheckbox = null;
}


loadFromLocal();
