const API = "/api/attendance";
const VALID_FACTORIES = ["mt1", "mt2", "mt3", "ut"];

let factory = VALID_FACTORIES.includes(document.body.dataset.factory)
  ? document.body.dataset.factory
  : "mt1";
let today = "";
let selectedDate = "";

// ================= DATE =================
function setToday() {
  const now = new Date();

  today =
    now.getFullYear() + "-" +
    String(now.getMonth() + 1).padStart(2, "0") + "-" +
    String(now.getDate()).padStart(2, "0");

  document.getElementById("date").innerText =
    now.toLocaleDateString("th-TH");

  document.getElementById("date").dataset.date = today;
  document.getElementById("historyDate").value = today;
  document.getElementById("historyDate").max = today;
  selectedDate = today;
}

async function loadHistoryDates() {
  const response = await fetch(`/api/attendance/history?factory=${encodeURIComponent(factory)}`);
  if (!response.ok) throw new Error(`โหลดประวัติไม่สำเร็จ (${response.status})`);

  await response.json();
  document.getElementById("historyDate").max = today;
}

// ================= CHECKBOX =================
function createCheckbox(code, field, color = "") {
  return `
  <td>
    <input type="checkbox"
      data-name="${escapeHtml(code)}"
      data-field="${escapeHtml(field)}"
      data-color="${escapeHtml(color)}">
  </td>`;
}

// ================= CHANGE FACTORY =================
async function changeFactory(newFactory, btn) {

  if (!VALID_FACTORIES.includes(newFactory) || (newFactory === factory && btn?.classList.contains("active"))) {
    return;
  }

  factory = newFactory;

  document.querySelectorAll(".factory-buttons button")
    .forEach(button => {
      const isActive = button.dataset.factory === factory;
      button.classList.toggle("active", isActive);
      button.setAttribute("aria-pressed", String(isActive));
    });

  setToday();
  await loadHistoryDates();
  await loadEmployees();
}

// ================= LOAD EMPLOYEES =================
async function loadEmployees() {

  const tbody = document.getElementById("empTable");
  tbody.innerHTML = '<tr><td colspan="8">กำลังโหลดข้อมูล...</td></tr>';

  try {
    const response = await fetch(`/api/employees?factory=${encodeURIComponent(factory)}`);
    if (!response.ok) throw new Error(`โหลดรายชื่อไม่สำเร็จ (${response.status})`);

    const list = await response.json();

    let html = "";

    list.forEach(emp => {
      const avatar = encodeURIComponent(emp.avatar || "");

      html += `
      <tr>
        <td class="emp-name">
          <img src="/static/images.${factory}/${avatar}"
          class="avatar" alt="" loading="lazy">

          ${escapeHtml(emp.emp_name)}
        </td>

        ${createCheckbox(emp.emp_code,"work","green")}
        ${createCheckbox(emp.emp_code,"absent")}
        ${createCheckbox(emp.emp_code,"night","blue")}
        ${createCheckbox(emp.emp_code,"special","purple")}
        ${createCheckbox(emp.emp_code,"sick","red")}
        ${createCheckbox(emp.emp_code,"vacation","yellow")}
        ${createCheckbox(emp.emp_code,"leave","orange")}
      </tr>
      `;
    });

    tbody.innerHTML = html || '<tr><td colspan="8">ไม่พบข้อมูลพนักงาน</td></tr>';

    await loadData();
  } catch (error) {
    console.error(error);
    tbody.innerHTML = '<tr><td colspan="8">ไม่สามารถโหลดข้อมูลได้</td></tr>';
  }
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    '"': "&quot;"
  }[character]));
}

// ================= LOAD ATTENDANCE =================
async function loadData() {

  if (!today) setToday();

  const date = selectedDate || today;
  const response = await fetch(`${API}?date=${date}&factory=${encodeURIComponent(factory)}`);
  if (!response.ok) throw new Error(`โหลดสถานะไม่สำเร็จ (${response.status})`);

  const result = await response.json();

  document.querySelectorAll("input[type=checkbox]").forEach(cb => {
    cb.disabled = date !== today;
    const td = cb.parentElement;
    cb.checked = false;
    td.classList.remove("green","blue","purple","red","yellow","orange");
  });

  document.querySelectorAll("input[type=checkbox]").forEach(cb => {

    const code = cb.dataset.name;
    const field = cb.dataset.field;

    const checked = result?.[code]?.[field] === true;

    const td = cb.parentElement;
    const color = cb.dataset.color;

    cb.checked = checked;

    if (checked && color) {
      td.classList.add(color);
    }
  });
}

// ================= EVENTS =================
function bindEvents() {

  document.getElementById("historyDate").addEventListener("change", async event => {
    selectedDate = event.target.value || today;
    document.getElementById("date").innerText = selectedDate === today
      ? new Date(`${today}T00:00:00`).toLocaleDateString("th-TH")
      : `ประวัติ: ${new Date(`${selectedDate}T00:00:00`).toLocaleDateString("th-TH")}`;
    await loadData();
  });

  document.getElementById("historyToday").addEventListener("click", async () => {
    setToday();
    document.getElementById("date").innerText = selectedDate === today
      ? new Date(`${today}T00:00:00`).toLocaleDateString("th-TH")
      : `ประวัติ: ${new Date(`${selectedDate}T00:00:00`).toLocaleDateString("th-TH")}`;
    await loadData();
  });

  document.getElementById("empTable").addEventListener("change", function (e) {

    if (e.target.type !== "checkbox") return;

    const cb = e.target;
    const row = cb.closest("tr");
    const code = cb.dataset.name;

    const payload = {
      date: selectedDate || today,
      factory: factory,
      emp_code: code,
      emp_name: row.querySelector(".emp-name").innerText.trim(),
      work: row.querySelector('[data-field="work"]').checked,
      absent: row.querySelector('[data-field="absent"]').checked,
      night: row.querySelector('[data-field="night"]').checked,
      special: row.querySelector('[data-field="special"]').checked,
      sick: row.querySelector('[data-field="sick"]').checked,
      vacation: row.querySelector('[data-field="vacation"]').checked,
      leave: row.querySelector('[data-field="leave"]').checked
    };

    fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    })
    .then(response => {
      if (!response.ok) throw new Error(`บันทึกข้อมูลไม่สำเร็จ (${response.status})`);
      return loadData();
    })
    .catch(error => console.error(error));
  });
}

// ================= FULLSCREEN =================
function toggleFullscreen() {
  const fsBtn = document.getElementById("fsBtn");

  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
    fsBtn.textContent = "ออกจากเต็มจอ";
  } else {
    document.exitFullscreen();
    fsBtn.textContent = "แตะเพื่อแสดงเต็มจอ";
  }
}

// ================= INIT =================
window.addEventListener("load", () => {

  setToday();
  bindEvents();

  document.querySelectorAll(".factory-buttons button").forEach(button => {
    const isActive = button.dataset.factory === factory;
    button.classList.toggle("active", isActive);
    button.setAttribute("aria-pressed", String(isActive));
  });

  loadHistoryDates().then(loadEmployees).catch(error => {
    console.error(error);
    loadEmployees();
  });
});
