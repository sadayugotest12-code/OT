"""Database connection and factory-schema helpers."""

# ---------------------------------------------------------------------------
# Imports and environment loading
# ---------------------------------------------------------------------------
import os

import psycopg2
from psycopg2 import sql

try:
    from dotenv import load_dotenv
except ImportError:
    def load_dotenv():
        env_file = os.path.join(os.path.dirname(__file__), ".env")
        if not os.path.exists(env_file):
            return False

        with open(env_file, encoding="utf-8") as file:
            for line in file:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))
        return True


load_dotenv()

VALID_FACTORIES = ("mt1", "mt2", "mt3", "ut")


# ---------------------------------------------------------------------------
# Connection management
# ---------------------------------------------------------------------------
def get_connection():
    return psycopg2.connect(
        host=os.getenv("DB_HOST", "27.254.143.93"),
        port=int(os.getenv("DB_PORT", "5432")),
        user=os.getenv("DB_USER", "postgres"),
        password=os.getenv("DB_PASSWORD", "@1234"),
        dbname=os.getenv("DB_NAME", "testdata"),
        sslmode=os.getenv("DB_SSLMODE", "disable"),
        connect_timeout=int(os.getenv("DB_CONNECT_TIMEOUT", "15")),
        options="-c statement_timeout=60000 -c lock_timeout=15000",
    )


# ---------------------------------------------------------------------------
# Factory schema helpers
# ---------------------------------------------------------------------------
def validate_factory(factory):
    if factory not in VALID_FACTORIES:
        raise ValueError("Invalid factory")
    return factory


def set_factory_schema(cursor, factory):
    validate_factory(factory)
    cursor.execute(sql.SQL("SET search_path TO {}, public").format(sql.Identifier(factory)))


def employee_from_db(cursor, factory, emp_code):
    set_factory_schema(cursor, factory)
    cursor.execute(
        "SELECT emp_code, emp_name, position FROM employees WHERE emp_code = %s",
        (emp_code,),
    )
    return cursor.fetchone()
