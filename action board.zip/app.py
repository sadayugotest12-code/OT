"""Flask application entry point.

Routes remain in this file for compatibility. Section markers group the
feature areas so they can be debugged and split into blueprints later.
"""

# ---------------------------------------------------------------------------
# Imports and application configuration
# ---------------------------------------------------------------------------
import bcrypt
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, jsonify, session
from werkzeug.utils import secure_filename
from flask_cors import CORS
from datetime import date
import os

from database_connection import (
    VALID_FACTORIES,
    employee_from_db,
    get_connection,
    set_factory_schema,
    validate_factory,
)

 
app = Flask(
    __name__,
    static_folder="static",
    template_folder="templates"
)

app.secret_key = os.getenv("APP_SECRET_KEY", "change-this-session-secret")
CORS(app)


def get_conn():
    return get_connection()

VALID_FACTORY = list(VALID_FACTORIES)

# ---------------------------------------------------------------------------
# Authentication and request guards
# ---------------------------------------------------------------------------
@app.before_request
def require_login_for_edit_routes():
    protected_edit_endpoints = {
        "pm_save", "pm_delete", "profile_save", "clear_pm",
        "page_5s", "delete_latest", "delete_all",
        "actionboard_upload", "actionboard_delete", "actionboard_delete_file",
    }
    api_edit_endpoints = {
        "pm_save", "pm_delete", "profile_save", "clear_pm",
        "actionboard_upload", "actionboard_delete", "actionboard_delete_file",
    }
    is_edit_request = request.method != "GET"
    if request.endpoint in protected_edit_endpoints and is_edit_request and "employee_id" not in session:
        if request.endpoint in api_edit_endpoints or request.path.startswith("/api/") or request.is_json:
            return jsonify({"error": "Authentication required to edit"}), 401
        return redirect(url_for("login", next=request.path))
    return None


# ---------------------------------------------------------------------------
# Authentication and factory selection routes
# ---------------------------------------------------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        employee_code = request.form.get("employee_code", "").strip()
        password = request.form.get("password", "")

        conn = get_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id, employee_code, name, role, team_key,
                           password_hash, must_change_password
                    FROM public.employees
                    WHERE employee_code = %s
                      AND is_active = TRUE
                      AND role IN ('admin', 'supervisor')
                    """,
                    (employee_code,),
                )
                employee = cur.fetchone()
        finally:
            conn.close()

        password_matches = employee and bcrypt.checkpw(
            password.encode("utf-8"), employee[5].encode("utf-8")
        )
        if not password_matches:
            return render_template("pages/auth/login.html", error="รหัสพนักงานหรือรหัสผ่านไม่ถูกต้อง"), 401

        session.clear()
        session.update({
            "employee_id": employee[0],
            "employee_code": employee[1],
            "employee_name": employee[2],
            "role": employee[3],
            "team_key": employee[4],
            "must_change_password": employee[6],
        })
        next_url = request.form.get("next") or url_for("home")
        safe_next_url = next_url if next_url.startswith("/") and not next_url.startswith("//") else url_for("home")
        return redirect(safe_next_url)

    return render_template("pages/auth/login.html", next_url=request.args.get("next", ""))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/set_factory/<factory>")
def set_factory(factory):
    if factory not in VALID_FACTORY:
        return "Invalid factory"
    session["factory"] = factory
    return redirect("/")


@app.route("/")
def home():
    factory = session.get("factory", "mt1")
    return render_template("pages/home/home.html", factory=factory, current_user=session)


# ---------------------------------------------------------------------------
# Page routes
# ---------------------------------------------------------------------------
@app.route("/personal")
def personal():
    factory = session.get("factory", "mt1")
    return render_template("pages/attendance/attendance.html", factory=factory)

@app.route("/bodycheck")
def bodycheck():
    factory = session.get("factory", "mt1")
    return render_template("pages/body_check/body_check.html", factory=factory)

@app.route("/oneday_flow")
def oneday():
    factory = session.get("factory", "mt1")
    return render_template("pages/one_day_flow/one_day_flow.html", factory=factory, can_edit="employee_id" in session)


@app.route("/exercise")
def exercise():
    factory = session.get("factory", "mt1")
    return render_template("pages/exercise/exercise.html", factory=factory)

@app.route("/pm_year")
def pm_year():
    factory = session.get("factory", "mt1")
    return render_template("pages/maintenance/pm_yearly.html", factory=factory, can_edit="employee_id" in session)

@app.route("/pm_month")
def pm_month():
    factory = session.get("factory", "mt1")
    return render_template("pages/maintenance/pm_monthly.html", factory=factory)

@app.route("/summary_monthly")
def summary_monthly():
    factory = session.get("factory", "mt1")
    return render_template("pages/maintenance/summary_monthly.html", factory=factory)

@app.route("/summary_yearly")
def summary_yearly():
    factory = session.get("factory", "mt1")
    return render_template("pages/maintenance/summary_yearly.html", factory=factory)


@app.route("/status")
def status():
    factory = session.get("factory", "mt1")
    return redirect(url_for({
        "mt1": "status_mt1",
        "mt2": "statusmt2",
        "mt3": "statusmt3",
        "ut": "statusut",
    }[factory]))

@app.route("/statusmt2")
def statusmt2():
    if session.get("factory", "mt1") != "mt2":
        return redirect(url_for("status"))
    return render_template("pages/status/status_mt2.html")

@app.route("/statusmt3")
def statusmt3():
    if session.get("factory", "mt1") != "mt3":
        return redirect(url_for("status"))
    return render_template("pages/status/status_mt3.html")

@app.route("/statusut")
def statusut():
    if session.get("factory", "mt1") != "ut":
        return redirect(url_for("status"))
    return render_template("pages/status/status_utility.html")


@app.route("/statusmt1")
def status_mt1():
    if session.get("factory", "mt1") != "mt1":
        return redirect(url_for("status"))
    return render_template("pages/status/status_mt1.html")


@app.route("/api/status", methods=["GET", "POST"])
def location_status():
    if request.method == "GET":
        work_date = request.args.get("date", date.today().isoformat())
    else:
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"error": "Invalid request body"}), 400
        work_date = payload.get("date", "")

    try:
        work_date = date.fromisoformat(work_date).isoformat()
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid date"}), 400

    factory = session.get("factory", "mt1")
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            set_factory_schema(cur, factory)
            if request.method == "GET":
                cur.execute("""
                    SELECT emp_name, field, machine
                    FROM location_status
                    WHERE work_date = %s
                    ORDER BY emp_name, field
                """, (work_date,))
                rows = cur.fetchall()
                return jsonify([
                    {"name": name, "field": field, "machine": machine}
                    for name, field, machine in rows
                ])

            name = payload.get("name")
            field = payload.get("field")
            machine = payload.get("machine", "")
            selected = payload.get("selected")
            if (
                not isinstance(name, str) or not name.strip() or len(name) > 150
                or not isinstance(field, str) or not field.strip() or len(field) > 50
                or not isinstance(machine, str) or len(machine) > 255
                or not isinstance(selected, bool)
            ):
                return jsonify({"error": "Invalid status selection"}), 400

            if selected:
                cur.execute("""
                    INSERT INTO location_status (work_date, emp_name, field, machine)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (work_date, emp_name, field)
                    DO UPDATE SET machine = EXCLUDED.machine, updated_at = NOW()
                """, (work_date, name.strip(), field.strip(), machine))
            else:
                cur.execute("""
                    DELETE FROM location_status
                    WHERE work_date = %s AND emp_name = %s AND field = %s
                """, (work_date, name.strip(), field.strip()))
            conn.commit()
            return jsonify({"ok": True})
    finally:
        conn.close()

@app.route('/test_sparepart')
def test_sparepart():
    return render_template('test_sparepart.html')

@app.route("/bodycheck2")
def bodycheck2():
    return render_template("bodycheck2.html")


# =========================
# EMPLOYEES
# =========================
# ---------------------------------------------------------------------------
# Employee and attendance APIs
# ---------------------------------------------------------------------------
@app.route("/api/employees")
def employees():

    factory = request.args.get("factory")
    if factory not in VALID_FACTORY:
        return jsonify({"error": "Invalid factory"}), 400

    conn = get_conn()
    try:
        with conn.cursor() as cur:
            set_factory_schema(cur, factory)
            cur.execute("""
                SELECT emp_code, emp_name, position, avatar
                FROM employees
                WHERE active = TRUE
                ORDER BY emp_code
            """)
            rows = cur.fetchall()
        return jsonify([
            {"emp_code": code, "emp_name": name, "position": position, "avatar": avatar}
            for code, name, position, avatar in rows
        ])
    finally:
        conn.close()

# =========================
# ATTENDANCE
# =========================
@app.route("/api/attendance", methods=["GET", "POST"])
def attendance():

    conn = get_conn()
    cur = conn.cursor()

    def archive_previous_days():
        set_factory_schema(cur, factory)
        cur.execute("""
            INSERT INTO attendance_history
                (work_date, emp_code, emp_name, work, absent, night,
                 special, sick, vacation, leave_day)
            SELECT work_date, emp_code, emp_name, work, absent, night,
                   special, sick, vacation, leave_day
            FROM attendance
            WHERE work_date < CURRENT_DATE
            ON CONFLICT (work_date, emp_code) DO NOTHING
        """)
        cur.execute("DELETE FROM attendance WHERE work_date < CURRENT_DATE")
        conn.commit()

    # ================= GET =================
    if request.method == "GET":

        work_date = request.args.get("date")
        factory = request.args.get("factory")

        if factory not in VALID_FACTORY:
            cur.close()
            conn.close()
            return jsonify({"error": "Invalid factory"}), 400
        archive_previous_days()
        set_factory_schema(cur, factory)

        cur.execute("SELECT CURRENT_DATE")
        current_date = cur.fetchone()[0]
        source_table = "attendance" if str(work_date) == current_date.isoformat() else "attendance_history"
        cur.execute(f"""
            SELECT emp_code, work, absent, night,
                   special, sick, vacation, leave_day
            FROM {source_table}
            WHERE work_date = %s
        """, (work_date,))

        rows = cur.fetchall()

        result = {}

        for r in rows:
            result[r[0]] = {
                "work": bool(r[1]),
                "absent": bool(r[2]),
                "night": bool(r[3]),
                "special": bool(r[4]),
                "sick": bool(r[5]),
                "vacation": bool(r[6]),
                "leave": bool(r[7])
            }

        cur.close()
        conn.close()

        return jsonify(result)
    

    # =========================
    # POST
    # =========================
    if request.method == "POST":

        data = request.get_json()

        factory = data["factory"]

        if factory not in VALID_FACTORY:
            cur.close()
            conn.close()
            return jsonify({"error": "Invalid factory"}), 400
        archive_previous_days()

        cur.execute("SELECT CURRENT_DATE")
        if str(data.get("date")) != cur.fetchone()[0].isoformat():
            cur.close()
            conn.close()
            return jsonify({"error": "Historical attendance is read-only"}), 409

        employee = employee_from_db(cur, factory, data.get("emp_code"))
        if employee is None:
            cur.close()
            conn.close()
            return jsonify({"error": "Employee not found"}), 404
        emp_code, emp_name, _position = employee

        cur.execute("""
            INSERT INTO attendance
            (work_date, emp_code, emp_name,
             work, absent, night, special,
             sick, vacation, leave_day)

            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)

            ON CONFLICT (work_date, emp_code)
            DO UPDATE SET
                emp_name = EXCLUDED.emp_name,
                work = EXCLUDED.work,
                absent = EXCLUDED.absent,
                night = EXCLUDED.night,
                special = EXCLUDED.special,
                sick = EXCLUDED.sick,
                vacation = EXCLUDED.vacation,
                leave_day = EXCLUDED.leave_day
        """, (
            data["date"],
            emp_code,
            emp_name,
            data["work"],
            data["absent"],
            data["night"],
            data["special"],
            data["sick"],
            data["vacation"],
            data["leave"]
        ))

        conn.commit()

        cur.close()
        conn.close()

        return jsonify({"status": "ok"})


@app.route("/api/attendance/history")
def attendance_history():
    factory = request.args.get("factory")
    if factory not in VALID_FACTORY:
        return jsonify({"error": "Invalid factory"}), 400

    conn = get_conn()
    try:
        with conn.cursor() as cur:
            set_factory_schema(cur, factory)
            cur.execute("""
                INSERT INTO attendance_history
                    (work_date, emp_code, emp_name, work, absent, night,
                     special, sick, vacation, leave_day)
                SELECT work_date, emp_code, emp_name, work, absent, night,
                       special, sick, vacation, leave_day
                FROM attendance
                WHERE work_date < CURRENT_DATE
                ON CONFLICT (work_date, emp_code) DO NOTHING
            """)
            cur.execute("DELETE FROM attendance WHERE work_date < CURRENT_DATE")
            conn.commit()
            cur.execute("""
                SELECT DISTINCT work_date
                FROM attendance_history
                ORDER BY work_date DESC
            """)
            dates = [row[0].isoformat() for row in cur.fetchall()]
        return jsonify(dates)
    finally:
        conn.close()
    

# ================= GET =================



# =========================
# SAVE EXERCISE
# =========================
# ---------------------------------------------------------------------------
# Exercise APIs
# ---------------------------------------------------------------------------
@app.route("/api/save_exercise", methods=["POST"])
def save_exercise():

    data = request.get_json(force=True)

    factory = data.get("factory")
    if factory not in VALID_FACTORY:
        return jsonify({"error": "Invalid factory"}), 400

    emp_code = data.get("emp_code")
    position = data.get("position")

    exercise_date = data.get("exercise_date")
    status = data.get("status")

    conn = get_conn()
    cur = conn.cursor()

    employee = employee_from_db(cur, factory, emp_code)
    if employee is None:
        cur.close()
        conn.close()
        return jsonify({"error": "Employee not found"}), 404
    emp_code, emp_name, db_position = employee
    position = db_position or position or ""
    set_factory_schema(cur, factory)

    cur.execute("""
        INSERT INTO exercise
            (emp_code, emp_name, position, exercise_date, status)

        VALUES (%s,%s,%s,%s,%s)

        ON CONFLICT (exercise_date, emp_code)

        DO UPDATE SET
            status = EXCLUDED.status,
            position = EXCLUDED.position,
            emp_name = EXCLUDED.emp_name
    """, (
        emp_code,
        emp_name,
        position,
        exercise_date,
        status
    ))

    conn.commit()

    cur.close()
    conn.close()

    return jsonify({"message": "saved"})


# =========================
# GET EXERCISE
# =========================
@app.route("/api/get_exercise/<year>/<month>")
def get_exercise(year, month):

    factory = request.args.get("factory")
    if factory not in VALID_FACTORY:
        return jsonify({"error": "Invalid factory"}), 400

    conn = get_conn()
    cur = conn.cursor()

    # ⭐ เปลี่ยน schema
    set_factory_schema(cur, factory)

    cur.execute("""
        SELECT emp_code, emp_name, exercise_date, status
        FROM exercise
        WHERE EXTRACT(YEAR FROM exercise_date)=%s
        AND EXTRACT(MONTH FROM exercise_date)=%s
    """, (year, month))

    rows = cur.fetchall()

    cur.close()
    conn.close()

    result = []

    for r in rows:
        result.append({
            "emp_code": r[0],
            "emp_name": r[1],
            "date": r[2].strftime("%Y-%m-%d"),
            "status": r[3]
        })

    return jsonify(result)

# =========================
# DELETE EXERCISE
# =========================
@app.route("/api/delete_exercise", methods=["POST"])
def delete_exercise():

    data = request.get_json()

    factory = data.get("factory")
    if factory not in VALID_FACTORY:
        return jsonify({"error": "Invalid factory"}), 400

    conn = get_conn()
    cur = conn.cursor()

    # ⭐ สลับ schema
    set_factory_schema(cur, factory)

    cur.execute("""
        DELETE FROM exercise
        WHERE emp_code=%s
        AND exercise_date=%s
    """, (
        data["emp_code"],
        data["exercise_date"]
    ))

    conn.commit()

    cur.close()
    conn.close()

    return jsonify({"message":"deleted"})


# ---------------------------------------------------------------------------
# Yearly PM and employee profile APIs
# ---------------------------------------------------------------------------
@app.route("/api/pm/save", methods=["POST"])
def pm_save():

    data = request.get_json()

    conn = get_conn()
    cur = conn.cursor()

    # ⭐ เพิ่ม
    set_factory_schema(cur, session.get("factory", "mt1"))

    cur.execute("""
        INSERT INTO pm_yearly(id,value)
        VALUES(%s,%s)
        ON CONFLICT(id)
        DO UPDATE SET value=EXCLUDED.value
    """, (data["id"], "1"))

    conn.commit()

    cur.close()
    conn.close()

    return jsonify({"status":"ok"})


@app.route("/api/pm/delete", methods=["POST"])
def pm_delete():

    data = request.get_json()

    conn = get_conn()
    cur = conn.cursor()

    # ⭐ เพิ่ม
    set_factory_schema(cur, session.get("factory", "mt1"))

    cur.execute("""
        DELETE FROM pm_yearly
        WHERE id=%s
    """, (data["id"],))

    conn.commit()

    cur.close()
    conn.close()

    return jsonify({"status":"ok"})


@app.route("/api/pm/load")
def pm_load():

    conn = get_conn()
    cur = conn.cursor()

    # ⭐ เพิ่ม
    set_factory_schema(cur, session.get("factory", "mt1"))

    cur.execute("SELECT id FROM pm_yearly")

    rows = [r[0] for r in cur.fetchall()]

    cur.close()
    conn.close()

    return jsonify(rows)



@app.route("/api/profile/save", methods=["POST"])
def profile_save():

    data = request.get_json()

    key_fc = f"PRO_{data['id']}_FC"
    key_al = f"PRO_{data['id']}_AL"

    conn = get_conn()
    cur = conn.cursor()

    set_factory_schema(cur, session.get("factory", "mt1"))

    if data["profc"]:
        cur.execute("""
        INSERT INTO pm_yearly(id,value)
        VALUES(%s,1)
        ON CONFLICT(id) DO UPDATE SET value=1
        """,(key_fc,))
    else:
        cur.execute("DELETE FROM pm_yearly WHERE id=%s",(key_fc,))

    if data["proal"]:
        cur.execute("""
        INSERT INTO pm_yearly(id,value)
        VALUES(%s,1)
        ON CONFLICT(id) DO UPDATE SET value=1
        """,(key_al,))
    else:
        cur.execute("DELETE FROM pm_yearly WHERE id=%s",(key_al,))

    conn.commit()
    cur.close()
    conn.close()

    return jsonify(ok=True)

@app.route("/api/profile/load")
def profile_load():

    conn = get_conn()
    cur = conn.cursor()

    set_factory_schema(cur, session.get("factory", "mt1"))
    cur.execute("""
        SELECT id
        FROM pm_yearly
        WHERE id LIKE 'PRO_%'
    """)

    rows = [r[0] for r in cur.fetchall()]

    cur.close()
    conn.close()

    return jsonify(rows)


@app.route('/api/pm/clear', methods=['POST'])
def clear_pm():

    data = request.get_json()
    year = data['year']

    conn = get_conn()
    cur = conn.cursor()

    set_factory_schema(cur, session.get("factory", "mt1"))

    # ลบ PM ของปีนั้นทั้งหมด (รวม PRO ด้วย)
    cur.execute("""
        DELETE FROM pm_yearly
        WHERE id LIKE %s
    """, (f"%_{year}_%",))

    conn.commit()
    cur.close()
    conn.close()

    return jsonify({"status":"ok"})


#---summar_yearly-----
@app.route("/api/pm/summary")
def pm_summary():

    year = request.args.get("year")
    month = request.args.get("month")

    # ⭐ default เป็น mt1
    factory = request.args.get("factory", "mt1")

    conn = get_conn()
    cur = conn.cursor()

    set_factory_schema(cur, factory)

    if month:

        cur.execute("""
            SELECT
                split_part(id,'_',3) AS month,

                COUNT(*) FILTER (
                    WHERE split_part(id,'_',5)='P'
                ) AS p_count,

                COUNT(*) FILTER (
                    WHERE split_part(id,'_',5)='A'
                ) AS a_count

            FROM pm_yearly

            WHERE split_part(id,'_',2)=%s
            AND split_part(id,'_',3)=%s

            GROUP BY month
            ORDER BY month

        """, (year, month))

    else:

        cur.execute("""
            SELECT
                split_part(id,'_',3) AS month,

                COUNT(*) FILTER (
                    WHERE split_part(id,'_',5)='P'
                ) AS p_count,

                COUNT(*) FILTER (
                    WHERE split_part(id,'_',5)='A'
                ) AS a_count

            FROM pm_yearly

            WHERE split_part(id,'_',2)=%s

            GROUP BY month
            ORDER BY month

        """, (year,))

    rows = cur.fetchall()

    cur.close()
    conn.close()

    result = []

    for r in rows:
        result.append({
            "month": int(r[0]),
            "p": r[1] or 0,
            "a": r[2] or 0
        })

    return jsonify(result)


#---pm_month----
# ---------------------------------------------------------------------------
# Monthly PM and summary APIs
# ---------------------------------------------------------------------------
@app.route("/api/pm_monthly/save", methods=["POST"])
def save_pm_monthly():

    data = request.get_json()

    conn = get_conn()
    cur = conn.cursor()

    # ⭐ เพิ่ม
    set_factory_schema(cur, session.get("factory", "mt1"))

    cur.execute("""
        INSERT INTO pm_monthly
        (year, month, machine_code, day, type, status)

        VALUES (%s,%s,%s,%s,%s,%s)

        ON CONFLICT (year, month, machine_code, day, type)
        DO UPDATE SET status = EXCLUDED.status
    """, (
        data["year"],
        data["month"],
        data["machine_code"],
        data["day"],
        data["type"],
        data["status"]
    ))

    conn.commit()

    cur.close()
    conn.close()

    return jsonify({"status":"ok"})



@app.route("/api/pm_monthly/load")
def load_pm_monthly():

    year = request.args.get("year")
    month = request.args.get("month")

    conn = get_conn()
    cur = conn.cursor()

    # ⭐ เพิ่ม
    set_factory_schema(cur, session.get("factory", "mt1"))

    cur.execute("""
        SELECT machine_code, day, type, status
        FROM pm_monthly
        WHERE year=%s AND month=%s
    """, (year, month))

    rows = cur.fetchall()

    cur.close()
    conn.close()

    result = []

    for r in rows:
        result.append({
            "machine_code": r[0],
            "day": r[1],
            "type": r[2],
            "status": r[3]
        })

    return jsonify(result)

#=================== Pdf 5S Upload ==================

# =================== PDF 5S SYSTEM ===================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
VALID_5S_FACTORIES = (
    "factory1", "factory2", "factory3", "factory5", "mt1", "mt2", "mt3"
)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# ---------------------------------------------------------------------------
# 5S storage, page route, and file APIs
# ---------------------------------------------------------------------------
def get_5s_folder(factory):
    safe_factory = secure_filename(factory or "")
    if safe_factory not in VALID_5S_FACTORIES or safe_factory != factory:
        return None
    folder = os.path.join(UPLOAD_FOLDER, safe_factory)
    if os.path.commonpath([UPLOAD_FOLDER, folder]) != UPLOAD_FOLDER:
        return None
    return folder


# 📄 หน้า Action Board (MT Dashboard)
@app.route("/action_board", methods=['GET', 'POST'])
def page_action_board():
    factory = session.get("factory", "mt1")
    return render_template("pages/documents/action_board.html", factory=factory, can_edit="employee_id" in session)


# 📄 หน้า 5S
@app.route("/5s", methods=['GET', 'POST'])
def page_5s():

    if request.method == 'POST':
        file = request.files.get('file')
        factory = request.form.get('factory')

        if file and file.filename and factory:

            filename = secure_filename(file.filename)
            factory_path = get_5s_folder(factory)

            if not factory_path:
                return "❌ โรงงานไม่ถูกต้อง", 400

            if not filename.lower().endswith(".pdf"):
                return "❌ กรุณาอัปโหลด PDF เท่านั้น"

            os.makedirs(factory_path, exist_ok=True)

            filepath = os.path.join(factory_path, filename)
            file.save(filepath)

    return render_template("pages/documents/five_s.html", can_edit="employee_id" in session)


# 📂 list โรงงาน
@app.route("/api/factories")
def factories():
    for factory in VALID_5S_FACTORIES:
        os.makedirs(get_5s_folder(factory), exist_ok=True)
    return {"factories": list(VALID_5S_FACTORIES)}


# 📂 list PDF ตามโรงงาน
@app.route("/api/pdf_list")
def pdf_list():
    factory = request.args.get("factory")

    folder = get_5s_folder(factory)
    if not folder:
        return {"files": []}

    if not os.path.exists(folder):
        return {"files": []}

    files = [f for f in os.listdir(folder) if f.lower().endswith(".pdf")]
    files.sort(reverse=True)

    return {"files": files}


# 📂 เปิดไฟล์ PDF
@app.route('/uploads/<factory>/<filename>')
def uploaded_file(factory, filename):
    folder = get_5s_folder(factory)
    if not folder:
        return "Not found", 404
    return send_from_directory(
        folder,
        filename
    )


# 🗑 ลบไฟล์ล่าสุด
@app.route('/delete_latest', methods=['POST'])
def delete_latest():
    factory = request.form.get("factory")

    folder = get_5s_folder(factory)
    if not folder:
        return redirect(url_for('page_5s'))

    if not os.path.isdir(folder):
        return redirect(url_for('page_5s'))

    pdfs = [f for f in os.listdir(folder) if f.lower().endswith(".pdf")]

    if pdfs:
        latest = max(
            [os.path.join(folder, f) for f in pdfs],
            key=os.path.getctime
        )
        os.remove(latest)

    return redirect(url_for('page_5s'))


# 💣 ลบทั้งหมด
@app.route('/delete_all', methods=['POST'])
def delete_all():
    factory = request.form.get("factory")

    if not factory:
        return redirect(url_for('page_5s'))

    folder = os.path.join(UPLOAD_FOLDER, factory)

    for f in os.listdir(folder):
        if f.endswith(".pdf"):
            os.remove(os.path.join(folder, f))

    return redirect(url_for('page_5s'))


# 📋 ACTION BOARD ENDPOINTS
# ═══════════════════════════════════════════════════════════════

# 📤 อัปโหลด PDF สำหรับ Action Board
# ---------------------------------------------------------------------------
# Action Board upload and image APIs
# ---------------------------------------------------------------------------
@app.route('/actionboard/upload', methods=['POST'])
def actionboard_upload():
    """บันทึก PNG images ที่ส่งมาจาก client"""
    factory = request.form.get('factory')
    section = request.form.get('section')  # KPI, Manpower, Problem
    replace = request.form.get('replace', 'true').lower() == 'true'  # default: replace old files
    
    print(f"[DEBUG] Upload request: factory={factory}, section={section}, replace={replace}")
    
    if not all([factory, section]):
        return {"error": "Missing parameters"}, 400

    try:
        # สร้างโฟลเดอร์ actionboard
        ab_folder = os.path.join(UPLOAD_FOLDER, factory, 'actionboard', section.lower())
        os.makedirs(ab_folder, exist_ok=True)
        print(f"[DEBUG] Folder: {ab_folder}")

        # หาเลขลำดับสูงสุด (สำหรับ append mode)
        existing_files = []
        max_index = 0
        
        if os.path.exists(ab_folder):
            for f in os.listdir(ab_folder):
                if f.endswith(('.png', '.jpg', '.jpeg')):
                    existing_files.append(f)
                    # ดึงเลขลำดับจาก filename (เช่น "problem_001.png" -> 1)
                    try:
                        parts = f.split('_')
                        if len(parts) >= 2:
                            num = int(parts[-1].replace('.png', '').replace('.jpg', '').replace('.jpeg', ''))
                            max_index = max(max_index, num)
                    except:
                        pass

        print(f"[DEBUG] Existing files: {len(existing_files)}, max_index: {max_index}")

        # ถ้า replace mode ให้ลบไฟล์เก่า
        if replace:
            for old_file in existing_files:
                try:
                    os.remove(os.path.join(ab_folder, old_file))
                    print(f"[DEBUG] Deleted: {old_file}")
                except Exception as e:
                    print(f"[DEBUG] Failed to delete {old_file}: {e}")
            max_index = 0  # reset counter

        # รับ images จาก form data (multiple file uploads)
        images = request.files.getlist('images')
        print(f"[DEBUG] Received {len(images)} image files")
        
        if not images:
            return {"error": "No images provided"}, 400

        image_files = []
        for idx, img_file in enumerate(images):
            if img_file and img_file.filename:
                filename = f"{section.lower()}_{max_index + idx + 1:03d}.png"
                img_path = os.path.join(ab_folder, filename)
                img_file.save(img_path)
                image_files.append(filename)
                print(f"[DEBUG] Saved: {filename}")

        print(f"[DEBUG] Upload complete: {len(image_files)} files saved")
        
        return {
            "success": True,
            "count": len(image_files),
            "files": image_files
        }, 200

    except Exception as e:
        print(f"[ERROR] in actionboard_upload: {e}")
        import traceback
        traceback.print_exc()
        return {"error": str(e)}, 500


# 📋 เรียก list รูปภาพ Action Board
@app.route('/api/actionboard/images/<factory>/<section>')
def actionboard_images(factory, section):
    """เรียกรูปภาพทั้งหมดของ section"""
    ab_folder = os.path.join(UPLOAD_FOLDER, factory, 'actionboard', section.lower())
    
    print(f"[DEBUG] Listing images: folder={ab_folder}")
    
    if not os.path.exists(ab_folder):
        print(f"[DEBUG] Folder does not exist")
        return {"images": []}, 200

    try:
        all_files = os.listdir(ab_folder)
        images = [f for f in sorted(all_files) 
                 if f.endswith(('.png', '.jpg', '.jpeg'))]
        print(f"[DEBUG] Found {len(images)} images: {images}")
        return {"images": images}, 200
    except Exception as e:
        print(f"[ERROR] in actionboard_images: {e}")
        return {"error": str(e)}, 500


# 🗑 ลบรูปภาพ Action Board (ทั้งหมด)
@app.route('/api/actionboard/delete/<factory>/<section>', methods=['POST'])
def actionboard_delete(factory, section):
    """ลบรูปภาพทั้งหมดของ section"""
    ab_folder = os.path.join(UPLOAD_FOLDER, factory, 'actionboard', section.lower())
    
    try:
        if os.path.exists(ab_folder):
            for f in os.listdir(ab_folder):
                if f.endswith(('.png', '.jpg', '.jpeg')):
                    os.remove(os.path.join(ab_folder, f))
        return {"success": True}, 200
    except Exception as e:
        return {"error": str(e)}, 500


# 🗑 ลบไฟล์เดี่ยว (สำหรับ problem section)
@app.route('/api/actionboard/delete/<factory>/<section>/<filename>', methods=['POST'])
def actionboard_delete_file(factory, section, filename):
    """ลบไฟล์เดี่ยวและ re-index ไฟล์ที่เหลือ"""
    ab_folder = os.path.join(UPLOAD_FOLDER, factory, 'actionboard', section.lower())
    
    try:
        file_path = os.path.join(ab_folder, filename)
        
        # ลบไฟล์
        if os.path.exists(file_path):
            os.remove(file_path)
            print(f"[DEBUG] Deleted file: {filename}")
        
        # Re-index remaining files (rename to maintain sequential numbering)
        if os.path.exists(ab_folder):
            all_files = sorted([f for f in os.listdir(ab_folder) 
                              if f.endswith(('.png', '.jpg', '.jpeg'))])
            
            for idx, f in enumerate(all_files):
                old_path = os.path.join(ab_folder, f)
                new_filename = f"{section.lower()}_{idx + 1:03d}.png"
                new_path = os.path.join(ab_folder, new_filename)
                
                if old_path != new_path:
                    os.rename(old_path, new_path)
                    print(f"[DEBUG] Renamed {f} to {new_filename}")
        
        return {"success": True}, 200
    except Exception as e:
        print(f"[ERROR] in actionboard_delete_file: {e}")
        return {"error": str(e)}, 500


# 📸 เปิดรูปภาพ Action Board
@app.route('/uploads/<factory>/actionboard/<section>/<filename>')
def actionboard_image(factory, section, filename):
    """เปิดไฟล์รูปภาพจาก Action Board"""
    return send_from_directory(
        os.path.join(UPLOAD_FOLDER, factory, 'actionboard', section.lower()),
        filename
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=6544)

