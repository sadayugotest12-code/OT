"""Create database schemas and seed initial application data."""

# ---------------------------------------------------------------------------
# Imports and seed configuration
# ---------------------------------------------------------------------------
import csv
import os
from datetime import date, timedelta

from psycopg2.extras import execute_values

from database_connection import VALID_FACTORIES, get_connection


EMPLOYEES = [
	("E001", "Anan K.", "Operator", "e001.png"),
	("E002", "Boonmee P.", "Operator", "e002.png"),
	("E003", "Chalida S.", "Technician", "e003.png"),
	("E004", "Darin T.", "Technician", "e004.png"),
	("E005", "Ekkachai R.", "Supervisor", "e005.png"),
	("E006", "Fah N.", "Operator", "e006.png"),
	("E007", "Kittisak M.", "Operator", "e007.png"),
	("E008", "Lalita W.", "Quality", "e008.png"),
	("E009", "Manop J.", "Operator", "e009.png"),
	("E010", "Nicha V.", "Quality", "e010.png"),
	("E011", "Orathai C.", "Supervisor", "e011.png"),
]


TABLE_SQL = """
CREATE TABLE IF NOT EXISTS employees (
	emp_code VARCHAR(30) PRIMARY KEY,
	emp_name VARCHAR(150) NOT NULL,
	position VARCHAR(100),
	avatar VARCHAR(255),
	active BOOLEAN NOT NULL DEFAULT TRUE,
	created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS attendance (
	work_date DATE NOT NULL,
	emp_code VARCHAR(30) NOT NULL REFERENCES employees(emp_code),
	emp_name VARCHAR(150) NOT NULL,
	work BOOLEAN NOT NULL DEFAULT FALSE,
	absent BOOLEAN NOT NULL DEFAULT FALSE,
	night BOOLEAN NOT NULL DEFAULT FALSE,
	special BOOLEAN NOT NULL DEFAULT FALSE,
	sick BOOLEAN NOT NULL DEFAULT FALSE,
	vacation BOOLEAN NOT NULL DEFAULT FALSE,
	leave_day BOOLEAN NOT NULL DEFAULT FALSE,
	updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
	PRIMARY KEY (work_date, emp_code)
);

CREATE TABLE IF NOT EXISTS attendance_history (
	work_date DATE NOT NULL,
	emp_code VARCHAR(30) NOT NULL,
	emp_name VARCHAR(150) NOT NULL,
	work BOOLEAN NOT NULL DEFAULT FALSE,
	absent BOOLEAN NOT NULL DEFAULT FALSE,
	night BOOLEAN NOT NULL DEFAULT FALSE,
	special BOOLEAN NOT NULL DEFAULT FALSE,
	sick BOOLEAN NOT NULL DEFAULT FALSE,
	vacation BOOLEAN NOT NULL DEFAULT FALSE,
	leave_day BOOLEAN NOT NULL DEFAULT FALSE,
	archived_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
	PRIMARY KEY (work_date, emp_code)
);

CREATE TABLE IF NOT EXISTS exercise (
	exercise_date DATE NOT NULL,
	emp_code VARCHAR(30) NOT NULL REFERENCES employees(emp_code),
	emp_name VARCHAR(150) NOT NULL,
	position VARCHAR(100),
	status VARCHAR(10) NOT NULL CHECK (status IN ('✓', 'X', '')), 
	updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
	PRIMARY KEY (exercise_date, emp_code)
);

CREATE TABLE IF NOT EXISTS pm_yearly (
	id VARCHAR(150) PRIMARY KEY,
	value INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS pm_monthly (
	year INTEGER NOT NULL,
	month INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
	machine_code VARCHAR(50) NOT NULL,
	day INTEGER NOT NULL CHECK (day BETWEEN 1 AND 31),
	type VARCHAR(50) NOT NULL,
	status VARCHAR(30),
	updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
	PRIMARY KEY (year, month, machine_code, day, type)
);

CREATE TABLE IF NOT EXISTS location_status (
	work_date DATE NOT NULL,
	emp_name VARCHAR(150) NOT NULL,
	field VARCHAR(50) NOT NULL,
	machine VARCHAR(255) NOT NULL DEFAULT '',
	updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
	PRIMARY KEY (work_date, emp_name, field)
);
"""

AUTH_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS public.employees (
	id INTEGER PRIMARY KEY,
	employee_code VARCHAR(30) UNIQUE NOT NULL,
	name VARCHAR(150) NOT NULL,
	rank VARCHAR(100),
	team_key VARCHAR(50),
	role VARCHAR(30) NOT NULL CHECK (role IN ('admin', 'supervisor', 'employee')),
	supervisor_id INTEGER REFERENCES public.employees(id),
	password_hash VARCHAR(255) NOT NULL,
	must_change_password BOOLEAN NOT NULL DEFAULT FALSE,
	is_active BOOLEAN NOT NULL DEFAULT TRUE,
	created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
	updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
"""

DEMO_MACHINES = (
	"MF-02-FC", "MF-03-FC", "MF-04-FC", "GBF-02",
	"FC-CL-02", "MO-01", "CO-03", "SB-01", "TL-01", "HE-01",
)


# ---------------------------------------------------------------------------
# Factory table data
# ---------------------------------------------------------------------------
def seed_demo_data(cur):
	"""Fill all application tables with repeatable records for testing."""
	attendance_rows = []
	exercise_rows = []
	for day_offset in range(14):
		work_date = date(2026, 8, 1) + timedelta(days=day_offset)
		for employee_index, employee in enumerate(EMPLOYEES):
			emp_code, emp_name, position, _avatar = employee
			attendance_rows.append((
				work_date, emp_code, emp_name,
				True, (employee_index + day_offset) % 13 == 0,
				(employee_index + day_offset) % 4 == 0,
				(employee_index + day_offset) % 11 == 0,
				False, False, False,
			))

			exercise_status = "✓" if (employee_index + day_offset) % 5 else "X"
			exercise_rows.append((work_date, emp_code, emp_name, position, exercise_status))

	execute_values(cur, """
		INSERT INTO attendance
		(work_date, emp_code, emp_name, work, absent, night, special,
		 sick, vacation, leave_day)
		VALUES %s
		ON CONFLICT (work_date, emp_code) DO UPDATE SET
			emp_name = EXCLUDED.emp_name, work = EXCLUDED.work,
			absent = EXCLUDED.absent, night = EXCLUDED.night,
			special = EXCLUDED.special, sick = EXCLUDED.sick,
			vacation = EXCLUDED.vacation, leave_day = EXCLUDED.leave_day,
			updated_at = NOW()
	""", attendance_rows)
	execute_values(cur, """
		INSERT INTO exercise
		(exercise_date, emp_code, emp_name, position, status)
		VALUES %s
		ON CONFLICT (exercise_date, emp_code) DO UPDATE SET
			emp_name = EXCLUDED.emp_name, position = EXCLUDED.position,
			status = EXCLUDED.status, updated_at = NOW()
	""", exercise_rows)

	pm_yearly_rows = []
	pm_monthly_rows = []
	for machine_index, machine_code in enumerate(DEMO_MACHINES):
		for month in range(1, 13):
			for week in range(1, 5):
				for status_type in ("P", "A"):
					if (machine_index + month + week) % 3 != 0:
						pm_yearly_rows.append((f"{machine_code}_2026_{month}_{week}_{status_type}", 1))

			for day in range(1, 29):
				pm_type = "PM" if day % 2 else "SAFETY"
				status = "DONE" if (machine_index + month + day) % 4 else "PENDING"
				pm_monthly_rows.append((2026, month, machine_code, day, pm_type, status))

	execute_values(cur, """
		INSERT INTO pm_yearly (id, value) VALUES %s
		ON CONFLICT (id) DO UPDATE SET value = EXCLUDED.value
	""", pm_yearly_rows)
	execute_values(cur, """
		INSERT INTO pm_monthly
		(year, month, machine_code, day, type, status) VALUES %s
		ON CONFLICT (year, month, machine_code, day, type)
		DO UPDATE SET status = EXCLUDED.status, updated_at = NOW()
	""", pm_monthly_rows)

	profile_rows = []
	for employee_index, employee in enumerate(EMPLOYEES[:6]):
		emp_code = employee[0]
		for profile_type in ("FC", "AL"):
			if (employee_index + (profile_type == "AL")) % 2 == 0:
				profile_rows.append((f"PRO_{emp_code}_2026_{profile_type}", 1))
	if profile_rows:
		execute_values(cur, """
			INSERT INTO pm_yearly (id, value) VALUES %s
			ON CONFLICT (id) DO UPDATE SET value = EXCLUDED.value
		""", profile_rows)


# ---------------------------------------------------------------------------
# Authentication seed data
# ---------------------------------------------------------------------------
def seed_auth_employees(cur):
	"""Create login accounts from the tab-separated employee export."""
	employee_file = os.path.join(
		os.path.dirname(__file__), "data", "seed", "employee_accounts.tsv"
	)
	with open(employee_file, newline="", encoding="utf-8-sig") as file:
		for employee in csv.DictReader(file, delimiter="\t"):
			cur.execute("""
				INSERT INTO public.employees
				(id, employee_code, name, rank, team_key, role, supervisor_id,
				 password_hash, must_change_password, is_active, created_at, updated_at)
				VALUES (%s, %s, %s, %s, %s, %s, NULLIF(%s, '')::INTEGER,
				        %s, %s, %s, %s, %s)
				ON CONFLICT (id) DO UPDATE SET
					employee_code = EXCLUDED.employee_code,
					name = EXCLUDED.name,
					rank = EXCLUDED.rank,
					team_key = EXCLUDED.team_key,
					role = EXCLUDED.role,
					supervisor_id = EXCLUDED.supervisor_id,
					password_hash = EXCLUDED.password_hash,
					must_change_password = EXCLUDED.must_change_password,
					is_active = EXCLUDED.is_active,
					updated_at = EXCLUDED.updated_at
			""", (
				int(employee["id"]),
				employee["employee_code"],
				employee["name"],
				employee["rank"],
				employee["team_key"],
				employee["role"],
				employee["supervisor_id"],
				employee["password_hash"],
				employee["must_change_password"].lower() == "true",
				employee["is_active"].lower() == "true",
				employee["created_at"],
				employee["updated_at"],
			))


# ---------------------------------------------------------------------------
# Initialization entry point
# ---------------------------------------------------------------------------
def initialize_database():
	conn = get_connection()
	try:
		conn.autocommit = True
		with conn.cursor() as cur:
			cur.execute(AUTH_TABLE_SQL)
			seed_auth_employees(cur)
			for factory in VALID_FACTORIES:
				print(f"Seeding {factory}...", flush=True)
				cur.execute('CREATE SCHEMA IF NOT EXISTS "{}"'.format(factory))
				cur.execute('SET search_path TO "{}", public'.format(factory))
				cur.execute(TABLE_SQL)
				for employee in EMPLOYEES:
					cur.execute("""
						INSERT INTO employees (emp_code, emp_name, position, avatar)
						VALUES (%s, %s, %s, %s)
						ON CONFLICT (emp_code) DO UPDATE SET
							emp_name = EXCLUDED.emp_name,
							position = EXCLUDED.position,
							avatar = EXCLUDED.avatar,
							active = TRUE
					""", employee)
				seed_demo_data(cur)
				print(f"Finished {factory}.", flush=True)
	finally:
		conn.close()


if __name__ == "__main__":
	initialize_database()
	print("Database tables and demo employees are ready.")
