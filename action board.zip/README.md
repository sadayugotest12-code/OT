# Action Board project map

## Administrator guide

รายละเอียดการเปลี่ยนค่า ตาราง/คอลัมน์ เครื่องจักร หน้าเว็บ API และไฟล์ upload อยู่ที่ [docs/ADMIN_CONFIGURATION_GUIDE_TH.md](docs/ADMIN_CONFIGURATION_GUIDE_TH.md)

## Start here

- `app.py`: Flask entry point, routes, request guards, API responses, and file serving.
- `database_connection.py`: Active PostgreSQL connection and factory-schema helpers.
- `initialize_database.py`: Database schema creation and seed data.
- `templates/pages/`: Jinja pages grouped by feature.
- `static/css/pages/`: Page styles grouped by feature.
- `static/js/pages/`: Browser behavior grouped by feature.
- `static/css/shared/` and `static/js/shared/`: Shared browser assets.
- `data/seed/employee_accounts.tsv`: Login account seed data.
- `uploads/`: Runtime PDF and image files.
- `data/`: Application data files.

## `app.py` sections

1. Imports and application configuration
2. Authentication and request guards
3. Authentication and factory selection routes
4. Page routes
5. Employee and attendance APIs
6. Exercise APIs
7. Yearly PM and employee profile APIs
8. Monthly PM and summary APIs
9. 5S storage, page route, and file APIs
10. Action Board upload and image APIs

## Debug flow

1. Confirm the browser URL and route in `app.py`.
2. Check the matching template in `templates/pages/<feature>/`.
3. Check the page-specific CSS and JavaScript in the matching `static/*/pages/<feature>/` folder.
4. Check browser Network requests and match them to the API route.
5. Check SQL and factory selection in `database_connection.py`.
6. Check uploaded files under `uploads/`.

## Page file convention

A page normally uses one template, one CSS file, and one JavaScript file:

`templates/pages/<feature>/<page>.html` -> `static/css/pages/<feature>/<page>.css` -> `static/js/pages/<feature>/<page>.js`

Shared files are `static/css/shared/back_button.css` and `static/js/shared/screensaver.js`.

## Database note

`database_connection.py` is the active database interface. `legacy_database.py` is a legacy duplicate and should not receive new application code unless it is intentionally reactivated.

## Validation commands

Run from this directory:

```powershell
.\venv11\Scripts\python.exe -m py_compile app.py database_connection.py initialize_database.py
node --check .\static\js\pages\documents\five_s.js
```

Jinja templates can be parsed with:

```powershell
.\venv11\Scripts\python.exe -c "from jinja2 import Environment, FileSystemLoader; Environment(loader=FileSystemLoader('templates')).get_template('pages/documents/five_s.html'); print('Template parsed')"
```
