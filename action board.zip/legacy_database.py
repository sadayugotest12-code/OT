#db.py
import os
import psycopg2
import psycopg2.extras
from database_connection import get_connection


# 🔸 Production Database (Render)
db_prod = {
    "host": os.getenv("DB_PROD_HOST") or os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PROD_PORT") or os.getenv("DB_PORT") or 5432),
    "user": os.getenv("DB_PROD_USER") or os.getenv("DB_USER", "postgres"),
    "password": os.getenv("DB_PROD_PASSWORD") or os.getenv("DB_PASSWORD", "5432"),
    "dbname": os.getenv("DB_PROD_NAME") or os.getenv("DB_NAME", "factory"),
    "cursor_factory": psycopg2.extras.RealDictCursor,
    "sslmode": os.getenv("DB_SSLMODE", "disable"),
}




# ✅ ฟังก์ชันเชื่อมต่อฐานข้อมูลหลัก
def get_prod_connection():
    return get_connection()

# ✅ ฟังก์ชันสำรอง (ใช้ชื่อเหมือนของเดิมในโปรเจ็กต์)
def get_mt_connection():
    return psycopg2.connect(**db_prod)


def get_historymt1_connection():
    return psycopg2.connect(**db_prod)

def get_neckmt1_connection():
    return psycopg2.connect(**db_prod) 

def get_mcnormalmt1_connection():
    return psycopg2.connect(**db_prod)

def get_operating_time_connection():
    return psycopg2.connect(**db_prod)

# ✅ ดึงข้อมูล (ใช้แทน query_db เดิม)
def query_db(query, params=None):
    conn = get_prod_connection()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(query, params or ())
            return cur.fetchall()
    finally:
        conn.close()

# ✅ ดึงข้อมูลจากตารางที่ใช้บ่อย
def get_prodrepairs():
    return query_db("SELECT * FROM prodrepair ORDER BY id DESC")

def get_mtrepairs():
    return query_db("SELECT * FROM mtrepair ORDER BY id DESC")

def get_historymt1():
    return query_db("SELECT * FROM historymt1 ORDER BY id DESC")



#------ ดึงข้อมูลงานซ่อมที่เสร็จในวันนี้ -----------------------------

def get_mtrepair_done_today():
    """ดึงข้อมูลงานซ่อมที่เสร็จในวันนี้จากฐานข้อมูล MT"""
    conn = get_mt_connection()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("""
            SELECT *
            FROM mtrepair
            WHERE form_date = CURRENT_DATE
              AND status = 'Finish'
            ORDER BY id DESC
        """)
        rows = cur.fetchall()
    conn.close()
    return rows


#-------------------------------------------------------------------------

#-------คำนวณ KPI --------------------------------------------------------

