import qrcode

url = "http://27.254.143.93:5000/qa"

img = qrcode.make(url)
img.save("qa_qr.png")

print("QR Code created: qa_qr.png")
