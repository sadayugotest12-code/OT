@echo off
REM Script สำหรับสร้าง .exe โดยใช้ PyInstaller

setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ====================================
echo  MT ASSISTANT AI - Build EXE
echo ====================================
echo.

REM ใช้ venv12
set PYTHON_PATH=.\venv12\Scripts\python.exe
set PYINSTALLER_PATH=.\venv12\Scripts\pyinstaller.exe

if not exist "%PYTHON_PATH%" (
    echo ❌ Error: ไม่พบ Python ใน venv12
    pause
    exit /b 1
)

echo ✓ Python: %PYTHON_PATH%
echo ✓ PyInstaller: %PYINSTALLER_PATH%
echo.

REM สร้างโฟลเดอร์ build
if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
if exist "run_app.spec" del run_app.spec

echo 📦 Building EXE...
echo.

REM คำสั่ง PyInstaller
%PYINSTALLER_PATH% ^
    --onefile ^
    --windowed ^
    --name "MT-Assistant-AI" ^
    --add-data "static;static" ^
    --add-data "manuals;manuals" ^
    --add-data "backgroud.html;." ^
    --add-data "dashboard.html;." ^
    --add-data "audit.html;." ^
    --hidden-import=langchain ^
    --hidden-import=langchain_ollama ^
    --hidden-import=chromadb ^
    --hidden-import=flask ^
    --hidden-import=docx ^
    --collect-all=chromadb ^
    --collect-all=langchain ^
    --collect-all=langchain_core ^
    run_app.py

echo.
if exist "dist\MT-Assistant-AI.exe" (
    echo ✅ สร้าง EXE สำเร็จ!
    echo.
    echo 📁 ตำแหน่งไฟล์: dist\MT-Assistant-AI.exe
    echo.
    echo คุณสามารถคลิกปุ่ม "Run" เพื่อเริ่มแอปพลิเคชัน
) else (
    echo ❌ การสร้าง EXE ไม่สำเร็จ
    pause
    exit /b 1
)

echo.
pause
