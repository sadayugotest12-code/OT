@echo off
chcp 65001 > nul
title MT ASSISTANT AI - Chat Bot
color 0A

echo.
echo ====================================
echo   MT ASSISTANT AI - Chat Bot
echo ====================================
echo.

cd /d "%~dp0"

echo 🌐 Starting Flask server...
echo    Opening: http://localhost:5000/qa
echo.

REM ใช้ venv12
set PYTHON=.\venv12\Scripts\python.exe

REM ตรวจสอบ Python
if not exist "%PYTHON%" (
    echo Error: Python not found in venv12
    pause
    exit /b 1
)

REM รัน Flask app
"%PYTHON%" run_app.py

pause
