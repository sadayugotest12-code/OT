from __future__ import annotations

import json
import os
import random
import secrets
import threading
import csv
import re
from datetime import timedelta
from collections import Counter, defaultdict
from datetime import datetime
from functools import wraps
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory, session
from werkzeug.utils import secure_filename

from rag_chat_local import (
    answer_question,
    format_answer_from_record,
    initialize_rag_components,
    normalize_for_match,
    warmup_runtime,
)


BASE_DIR = Path(__file__).resolve().parent
MANUALS_DIR = BASE_DIR / "manuals"
ADDITIONAL_HISTORY_FILE = MANUALS_DIR / "additional_repair_history.txt"
ALLOWED_MANUAL_EXTENSIONS = {".txt", ".docx"}
app = Flask(__name__, static_folder="static")
app.secret_key = os.getenv("FLASK_SECRET_KEY") or secrets.token_hex(32)
app.permanent_session_lifetime = timedelta(days=30)

UPLOAD_USERNAME = os.getenv("UPLOAD_USERNAME", "admin")
UPLOAD_PASSWORD = os.getenv("UPLOAD_PASSWORD", "sat2026")
FEEDBACK_FILE = BASE_DIR / "feedback" / "feedback.txt"

_runtime_lock = threading.Lock()
_runtime: dict[str, object] | None = None
_upload_status_lock = threading.Lock()
_upload_status: dict[str, object] = {
    "state": "idle",
    "message": "พร้อมใช้งาน",
    "saved_files": [],
    "skipped_files": [],
    "loaded_files": [],
}


def _warmup_runtime_in_background() -> None:
    """รัน warmup แบบกัน exception เพื่อไม่ให้ thread พ่น traceback"""
    try:
        warmup_runtime(get_runtime())
    except Exception:
        pass


def _set_upload_status(**updates: object) -> None:
    with _upload_status_lock:
        _upload_status.update(updates)


def _get_upload_status() -> dict[str, object]:
    with _upload_status_lock:
        status = dict(_upload_status)

    for key in ("saved_files", "skipped_files", "loaded_files"):
        value = status.get(key)
        status[key] = list(value) if isinstance(value, list) else []
    return status


def _get_loaded_files_snapshot() -> list[str]:
    runtime = _runtime
    if runtime is None:
        return []
    return [file_path.name for file_path in runtime.get("manual_files", [])]


def _refresh_runtime_after_upload(saved_files: list[str], skipped_files: list[str]) -> None:
    """อัปเดตฐานความรู้หลังอัปโหลดแบบ background เพื่อไม่บล็อก request"""
    global _runtime

    _set_upload_status(
        state="processing",
        message="กำลังอัปเดตฐานความรู้จากไฟล์ที่อัปโหลด",
        saved_files=saved_files,
        skipped_files=skipped_files,
    )

    try:
        new_runtime = initialize_rag_components()
        with _runtime_lock:
            _runtime = new_runtime

        loaded_files = [file_path.name for file_path in new_runtime.get("manual_files", [])]
        _set_upload_status(
            state="ready",
            message="อัปโหลดและอัปเดตฐานความรู้สำเร็จ",
            saved_files=saved_files,
            skipped_files=skipped_files,
            loaded_files=loaded_files,
        )

        thread = threading.Thread(target=_warmup_runtime_in_background, daemon=True)
        thread.start()
    except Exception as exc:
        _set_upload_status(
            state="error",
            message=f"อัปเดตฐานความรู้ไม่สำเร็จ: {exc}",
            saved_files=saved_files,
            skipped_files=skipped_files,
            loaded_files=_get_loaded_files_snapshot(),
        )


def _start_warmup_thread() -> None:
    """อุ่น runtime ล่วงหน้าโดยไม่บล็อกการเปิดหน้าเว็บ"""
    thread = threading.Thread(target=_warmup_runtime_in_background, daemon=True)
    thread.start()


def get_runtime() -> dict[str, object]:
    global _runtime
    if _runtime is None:
        with _runtime_lock:
            if _runtime is None:
                _runtime = initialize_rag_components()
    return _runtime


def _is_allowed_manual_file(filename: str) -> bool:
    return Path(filename).suffix.lower() in ALLOWED_MANUAL_EXTENSIONS


def _upload_login_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if not session.get("upload_authenticated"):
            return jsonify({"message": "กรุณาเข้าสู่ระบบก่อนอัปโหลดไฟล์"}), 401
        return view(*args, **kwargs)

    return wrapped_view


def _queue_runtime_refresh(saved_files: list[str], skipped_files: list[str]) -> None:
    _set_upload_status(
        state="queued",
        message="รับข้อมูลแล้ว กำลังรออัปเดตฐานความรู้",
        saved_files=saved_files,
        skipped_files=skipped_files,
        loaded_files=_get_loaded_files_snapshot(),
    )
    thread = threading.Thread(
        target=_refresh_runtime_after_upload,
        args=(saved_files.copy(), skipped_files.copy()),
        daemon=True,
    )
    thread.start()


_start_warmup_thread()


@app.get("/")
@app.get("/qa")
def qa_page():
    page_name = "qa.html" if (BASE_DIR / "qa.html").exists() else "backgroud.html"
    return send_from_directory(BASE_DIR, page_name)


@app.get("/favicon.ico")
def favicon():
    return "", 204


@app.post("/api/feedback")
def submit_feedback():
    payload = request.get_json(silent=True) or {}
    feedback = str(payload.get("feedback", "")).strip()
    if not feedback:
        return jsonify({"message": "กรุณากรอกข้อเสนอแนะ"}), 400
    if len(feedback) > 2000:
        return jsonify({"message": "ข้อเสนอแนะยาวเกิน 2,000 ตัวอักษร"}), 400

    FEEDBACK_FILE.parent.mkdir(parents=True, exist_ok=True)
    with FEEDBACK_FILE.open("a", encoding="utf-8") as file:
        file.write(
            json.dumps(
                {"timestamp": datetime.now().isoformat(timespec="seconds"), "feedback": feedback},
                ensure_ascii=False,
            )
            + "\n"
        )
    return jsonify({"message": "รับข้อเสนอแนะเรียบร้อยแล้ว"})


@app.get("/upload-status")
def upload_status():
    return jsonify(_get_upload_status())


@app.get("/api/upload-auth")
def upload_auth_status():
    return jsonify({"authenticated": bool(session.get("upload_authenticated"))})


@app.post("/api/login")
def login():
    payload = request.get_json(silent=True) or {}
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))

    if username != UPLOAD_USERNAME or password != UPLOAD_PASSWORD:
        return jsonify({"message": "Username หรือ Password ไม่ถูกต้อง"}), 401

    session.clear()
    session.permanent = True
    session["upload_authenticated"] = True
    return jsonify({"authenticated": True})


@app.post("/api/logout")
def logout():
    session.pop("upload_authenticated", None)
    return jsonify({"authenticated": False})


@app.post("/ask")
def ask():
    payload = request.get_json(silent=True) or {}
    question = str(payload.get("question", "")).strip()
    machine = str(payload.get("machine", "")).strip()
    symptom = str(payload.get("symptom", "")).strip()

    if not question:
        if machine and symptom:
            question = f"MACHINE: {machine}\nอาการ: {symptom}"
        elif machine:
            question = machine
        elif symptom:
            question = symptom

    if not question:
        return jsonify({"answer": "กรุณากรอกคำถาม"}), 400

    try:
        runtime = get_runtime()
        answer = answer_question(
            question=question,
            retriever=runtime["retriever"],
            llm=runtime["llm"],
            prompt=runtime["prompt"],
            known_records=runtime["known_records"],
            query_source="web",
        )
    except Exception as exc:
        answer = (
            "MACHINE: ไม่พบข้อมูล\n"
            "อาการ: ไม่พบข้อมูล\n"
            "สาเหตุ: ไม่พบข้อมูล\n"
            f"การแก้ไข: เกิดข้อผิดพลาดในการประมวลผล ({exc})"
        )

    return jsonify({"answer": answer})


@app.post("/upload-manuals")
@_upload_login_required
def upload_manuals():
    uploaded_files = request.files.getlist("files")
    if not uploaded_files:
        return jsonify({"message": "ไม่พบไฟล์ที่อัปโหลด"}), 400

    MANUALS_DIR.mkdir(parents=True, exist_ok=True)
    saved_files: list[str] = []
    skipped_files: list[str] = []

    for file_storage in uploaded_files:
        raw_name = file_storage.filename or ""
        safe_name = secure_filename(raw_name)

        if not safe_name:
            continue

        if not _is_allowed_manual_file(safe_name):
            skipped_files.append(raw_name)
            continue

        save_path = MANUALS_DIR / safe_name
        file_storage.save(save_path)
        saved_files.append(safe_name)

    if not saved_files:
        return jsonify({"message": "ไฟล์ไม่ถูกต้อง รองรับเฉพาะ .txt และ .docx", "skipped_files": skipped_files}), 400

    _queue_runtime_refresh(saved_files, skipped_files)

    return jsonify(
        {
            "message": "รับไฟล์แล้ว กำลังอัปเดตฐานความรู้ในพื้นหลัง",
            "state": "queued",
            "saved_files": saved_files,
            "skipped_files": skipped_files,
            "loaded_files": _get_loaded_files_snapshot(),
        }
    ), 202

@app.post("/api/manual-entry")
@_upload_login_required
def save_manual_entry():
    payload = request.get_json(silent=True) or {}
    fields = {
        "machine": str(payload.get("machine", "")).strip(),
        "symptom": str(payload.get("symptom", "")).strip(),
        "cause": str(payload.get("cause", "")).strip(),
        "fix": str(payload.get("fix", "")).strip(),
    }
    if not all(fields.values()):
        return jsonify({"message": "กรุณากรอกข้อมูลให้ครบทุกช่อง"}), 400
    if any(len(value) > 2000 for value in fields.values()):
        return jsonify({"message": "ข้อมูลแต่ละช่องยาวเกิน 2,000 ตัวอักษร"}), 400

    MANUALS_DIR.mkdir(parents=True, exist_ok=True)
    record = (
        f"=== MACHINE: {fields['machine']} ===\n"
        f"อาการ: {fields['symptom']}\n"
        f"สาเหตุ: {fields['cause']}\n"
        f"การแก้ไข: {fields['fix']}\n"
        "=== END ===\n\n"
    )
    with ADDITIONAL_HISTORY_FILE.open("a", encoding="utf-8") as file:
        file.write(record)

    _queue_runtime_refresh([ADDITIONAL_HISTORY_FILE.name], [])
    return jsonify({"message": "บันทึกประวัติการซ่อมเพิ่มเติมแล้ว กำลังอัปเดตฐานความรู้"}), 202

@app.get("/api/random-dataset")
@_upload_login_required
def random_dataset():
    try:
        runtime = get_runtime()
    except Exception as exc:
        return jsonify({"message": f"ไม่สามารถโหลดฐานข้อมูลสำหรับสุ่มได้: {exc}"}), 500
    records = [record for record in runtime.get("manual_records", []) if record.get("machine") and record.get("symptom")]
    if not records:
        return jsonify({"message": "ไม่พบชุดข้อมูลสำหรับสุ่ม"}), 404
    return jsonify({"record": random.choice(records)})


@app.get("/dashboard")
def dashboard_page():
    return send_from_directory(BASE_DIR, "dashboard.html")


@app.get("/audit")
def audit_page():
    return send_from_directory(BASE_DIR, "audit.html")


def _audit_question(record: dict[str, str], include_machine: bool) -> str:
    if include_machine:
        return f"MACHINE: {record.get('machine', '').strip()}\nอาการ: {record.get('symptom', '').strip()}"
    return record.get("symptom", "").strip()


def _audit_expected_answer(record: dict[str, str]) -> str:
    return format_answer_from_record(record)


def _audit_expected_answers(records: list[dict[str, str]]) -> str:
    return "\n\n".join(_audit_expected_answer(record) for record in records)


def _normalize_audit_answer(text: str) -> str:
    """ทำให้การตรวจไม่ล้มเพราะช่องว่างซ้ำที่ไม่มีผลต่อเนื้อหา"""
    normalized_lines = [re.sub(r"[ \t]+", " ", line).strip() for line in text.splitlines()]
    normalized = "\n".join(normalized_lines).strip()
    normalized = re.sub(r"(?m)^(\d+)\.\s*", r"\1. ", normalized)
    return re.sub(r"(?m)(^|:)\s*(\d+)[.)]\s+", r"\1 \2. ", normalized)


def _audit_answer_records(text: str) -> list[tuple[str, str, str, str]]:
    pattern = re.compile(
        r"^MACHINE\s*:\s*(.*?)\n"
        r"อาการ\s*:\s*(.*?)\n"
        r"สาเหตุ\s*:\s*(.*?)\n"
        r"การแก้ไข\s*:\s*(.*?)(?=^MACHINE\s*:|\Z)",
        re.MULTILINE | re.DOTALL,
    )

    def normalize_field(value: str) -> str:
        value = re.sub(r"[ \t]+", " ", value.replace("\r\n", "\n")).strip()
        value = re.sub(r"(?m)^\s*\(?([A-Za-z])\)?[.)]\s*", r"(\1) ", value)
        value = re.sub(r"(?m)^\s*\(?([0-9]+)\)?[.)]\s*", r"\1. ", value)
        return re.sub(r"\s+", " ", value).strip().lower()

    return sorted(
        (
            normalize_field(machine),
            normalize_field(symptom),
            normalize_field(cause),
            normalize_field(fix),
        )
        for machine, symptom, cause, fix in pattern.findall(text.strip())
    )


def _audit_answers_match(expected: str, answer: str) -> bool:
    expected_records = _audit_answer_records(expected)
    answer_records = _audit_answer_records(answer)
    if expected_records and answer_records:
        return expected_records == answer_records
    return _normalize_audit_answer(expected) == _normalize_audit_answer(answer)


def _refresh_audit_status(audit: dict) -> dict:
    """คำนวณสถานะผลเดิมใหม่ด้วยกติกาการเปรียบเทียบปัจจุบัน"""
    results = audit.get("results", [])
    for item in results:
        expected = item.get("expected", "")
        answer = item.get("answer", "")
        item["status"] = "passed" if _audit_answers_match(expected, answer) else "failed"

    passed = sum(item.get("status") == "passed" for item in results)
    failed = len(results) - passed
    accuracy = round(passed / len(results) * 100, 2) if results else 0.0
    audit["passed"] = passed
    audit["failed"] = failed
    audit["accuracy_percent"] = accuracy
    audit["summary"] = (
        f"สุ่มรูปแบบคำถามทั้งหมด {len(results)} ข้อ: ผ่าน {passed} ข้อ "
        f"ไม่ผ่าน {failed} ข้อ คิดเป็นความแม่นยำ {accuracy}%"
    )
    audit["overall_status"] = "ผ่าน" if failed == 0 else "ควรตรวจสอบ"
    return audit


@app.get("/api/latest-audit")
def latest_audit():
    audit_file = BASE_DIR / "logs" / "latest_audit.json"
    if not audit_file.exists():
        return jsonify({"results": []})
    try:
        with audit_file.open("r", encoding="utf-8") as file:
            audit = _refresh_audit_status(json.load(file))
        with audit_file.open("w", encoding="utf-8") as file:
            json.dump(audit, file, ensure_ascii=False, indent=2)
        return jsonify(audit)
    except (OSError, json.JSONDecodeError):
        return jsonify({"message": "ไม่สามารถอ่านผล audit ล่าสุดได้"}), 500


@app.post("/api/run-audit")
def run_audit():
    payload = request.get_json(silent=True) or {}
    try:
        sample_size = int(payload.get("sample_size", 100))
    except (TypeError, ValueError):
        return jsonify({"message": "จำนวนคำถามไม่ถูกต้อง"}), 400
    if not 1 <= sample_size <= 100000:
        return jsonify({"message": "จำนวนคำถามต้องอยู่ระหว่าง 1 ถึง 100,000 ข้อ"}), 400

    try:
        runtime = get_runtime()
        known_records = [
            record for record in runtime.get("manual_records", [])
            if record.get("symptom", "").strip()
        ]
        if not known_records:
            return jsonify({"message": "ไม่พบข้อมูลอาการสำหรับสุ่มทดสอบ"}), 500

        results = []
        for record in random.choices(known_records, k=sample_size):
            symptom_key = normalize_for_match(record.get("symptom", ""))
            same_symptom_count = sum(
                normalize_for_match(candidate.get("symptom", "")) == symptom_key
                for candidate in known_records
            )
            available_modes = ("machine_and_symptom", "symptom_only") if same_symptom_count == 1 else ("machine_and_symptom",)
            question_mode = random.choice(available_modes)
            question = _audit_question(record, question_mode == "machine_and_symptom")
            record_machine = normalize_for_match(record.get("machine", ""))
            record_symptom = normalize_for_match(record.get("symptom", ""))
            matching_records = [
                candidate
                for candidate in known_records
                if normalize_for_match(candidate.get("machine", "")) == record_machine
                and normalize_for_match(candidate.get("symptom", "")) == record_symptom
            ]
            matching_records = list({
                (
                    normalize_for_match(candidate.get("machine", "")),
                    normalize_for_match(candidate.get("symptom", "")),
                    normalize_for_match(candidate.get("cause", "")),
                    normalize_for_match(candidate.get("fix", "")),
                ): candidate
                for candidate in matching_records
            }.values())
            expected = _audit_expected_answers(matching_records)
            try:
                answer = answer_question(
                    question=question,
                    retriever=runtime["retriever"],
                    llm=runtime["llm"],
                    prompt=runtime["prompt"],
                    known_records=known_records,
                    query_source="program_audit",
                )
                status = "passed" if _audit_answers_match(expected, answer) else "failed"
            except Exception as exc:
                answer = f"เกิดข้อผิดพลาดในการประมวลผล: {exc}"
                status = "failed"
            results.append({
                "question": question,
                "machine": record.get("machine", ""),
                "symptom": record.get("symptom", ""),
                "question_mode": question_mode,
                "expected": expected,
                "answer": answer,
                "status": status,
            })

        passed = sum(item["status"] == "passed" for item in results)
        failed = len(results) - passed
        accuracy = round(passed / len(results) * 100, 2)
        audit = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "sample_size": len(results),
            "question_mode": "random",
            "question_mode_label": "สุ่มเครื่อง + อาการ หรือสุ่มเฉพาะอาการ",
            "passed": passed,
            "failed": failed,
            "accuracy_percent": accuracy,
            "summary": f"สุ่มรูปแบบคำถามทั้งหมด {len(results)} ข้อ: ผ่าน {passed} ข้อ ไม่ผ่าน {failed} ข้อ คิดเป็นความแม่นยำ {accuracy}%",
            "overall_status": "ผ่าน" if failed == 0 else "ควรตรวจสอบ",
            "results": results,
        }
        audit = _refresh_audit_status(audit)
        audit_file = BASE_DIR / "logs" / "latest_audit.json"
        audit_file.parent.mkdir(parents=True, exist_ok=True)
        with audit_file.open("w", encoding="utf-8") as file:
            json.dump(audit, file, ensure_ascii=False, indent=2)
        return jsonify(audit)
    except Exception as exc:
        return jsonify({"message": f"รัน audit ไม่สำเร็จ: {exc}"}), 500


def _is_self_question_source(source: str) -> bool:
    """Classify whether a log entry came from a self-asked question or an audit/program run."""
    normalized = (source or "").strip().lower()
    if not normalized:
        return True

    audit_like = {"program_audit", "audit", "full_random_audit", "random_full_coverage"}
    if normalized in audit_like:
        return False

    self_like = {"web", "self", "terminal", "test", "manual", "browser", "local", "user", "self_question"}
    if normalized in self_like:
        return True

    return True


def _parse_logs(start_date: str = None, end_date: str = None) -> dict[str, object]:
    """Parse log files and return statistics, optionally filtered by date range"""
    logs_dir = BASE_DIR / "logs"
    all_logs = []
    
    # Parse JSONL file
    jsonl_file = logs_dir / "question_logs.jsonl"
    if jsonl_file.exists():
        try:
            with open(jsonl_file, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        all_logs.append(json.loads(line))
        except Exception:
            pass
    
    # Parse CSV files from subdirectories
    for csv_file in logs_dir.glob("*/question_logs.csv"):
        if csv_file.exists():
            try:
                with open(csv_file, "r", encoding="utf-8", newline="") as f:
                    all_logs.extend(dict(row) for row in csv.DictReader(f))
            except Exception:
                pass
    
    # Filter by date range if provided
    if start_date or end_date:
        filtered_logs = []
        for log in all_logs:
            log_date = log.get("date", "")
            if start_date and end_date:
                if start_date <= log_date <= end_date:
                    filtered_logs.append(log)
            elif start_date:
                if log_date >= start_date:
                    filtered_logs.append(log)
            elif end_date:
                if log_date <= end_date:
                    filtered_logs.append(log)
        all_logs = filtered_logs
    
    # Calculate statistics
    stats = {
        "total_questions": len(all_logs),
        "date_range": {},
        "by_source": {},
        "by_hour": {},
        "top_questions": [],
        "questions_by_date": {},
        "answered_questions": 0,
        "unanswered_questions": 0,
        "unknown_status_questions": 0,
        "accuracy_percent": None,
        "unanswered_question_list": [],
        "question_categories": {
            "self_question": {
                "label": "ถามด้วยตัวเอง",
                "total_questions": 0,
                "answered_questions": 0,
                "unanswered_questions": 0,
                "accuracy_percent": None,
                "by_source": {},
                "by_hour": {},
                "questions_by_date": {},
                "top_questions": [],
                "unanswered_question_list": [],
            },
            "program_audit": {
                "label": "audit ด้วยโปรแกรม",
                "total_questions": 0,
                "answered_questions": 0,
                "unanswered_questions": 0,
                "accuracy_percent": None,
                "by_source": {},
                "by_hour": {},
                "questions_by_date": {},
                "top_questions": [],
                "unanswered_question_list": [],
            },
        },
    }
    
    if all_logs:
        # Date range
        dates = sorted([log.get("date", "") for log in all_logs if log.get("date")])
        if dates:
            stats["date_range"] = {
                "start": dates[0],
                "end": dates[-1]
            }
        
        # Questions by source
        sources = Counter(log.get("source", "unknown") for log in all_logs)
        stats["by_source"] = dict(sources)
        
        # Questions by hour
        hourly = defaultdict(int)
        for log in all_logs:
            time_str = log.get("time", "")
            if time_str:
                try:
                    hour = time_str.split(":")[0]
                    hourly[hour] += 1
                except Exception:
                    pass
        stats["by_hour"] = dict(sorted(hourly.items()))
        
        # Top questions
        questions = Counter(log.get("question", "") for log in all_logs if log.get("question"))
        top_10 = questions.most_common(10)
        stats["top_questions"] = [{"question": q, "count": c} for q, c in top_10]

        # Accuracy is calculated only from logs written with a known result.
        answered = sum(1 for log in all_logs if log.get("answer_status") == "answered")
        unanswered = sum(1 for log in all_logs if log.get("answer_status") == "unanswered")
        unknown_status = len(all_logs) - answered - unanswered
        evaluated_questions = answered + unanswered
        stats["answered_questions"] = answered
        stats["unanswered_questions"] = unanswered
        stats["unknown_status_questions"] = unknown_status
        stats["accuracy_percent"] = round(answered / evaluated_questions * 100, 2) if evaluated_questions else None
        stats["unanswered_question_list"] = [
            {
                "date": log.get("date", ""),
                "time": log.get("time", ""),
                "source": log.get("source", "unknown"),
                "question": log.get("question", ""),
            }
            for log in reversed(all_logs)
            if log.get("answer_status") == "unanswered" and log.get("question")
        ][:50]
        
        # Questions by date
        daily = defaultdict(int)
        for log in all_logs:
            date = log.get("date", "")
            if date:
                daily[date] += 1
        stats["questions_by_date"] = dict(sorted(daily.items()))

        # แยกผลแสดงตามวิธีการสร้างคำถาม:
        # รวม source ที่ใช้งานจริงจากการถามด้วยตัวเอง เช่น web, terminal, test, manual
        category_logs = defaultdict(list)
        for log in all_logs:
            source = str(log.get("source") or "").strip()
            category = "self_question" if _is_self_question_source(source) else "program_audit"
            category_logs[category].append(log)

        for category_name, category_log_items in category_logs.items():
            category_stats = stats["question_categories"][category_name]
            category_stats["total_questions"] = len(category_log_items)
            category_stats["answered_questions"] = sum(
                1 for log in category_log_items if log.get("answer_status") == "answered"
            )
            category_stats["unanswered_questions"] = sum(
                1 for log in category_log_items if log.get("answer_status") == "unanswered"
            )
            evaluated_category_questions = (
                category_stats["answered_questions"] + category_stats["unanswered_questions"]
            )
            category_stats["accuracy_percent"] = (
                round(category_stats["answered_questions"] / evaluated_category_questions * 100, 2)
                if evaluated_category_questions
                else None
            )
            category_sources = Counter(log.get("source", "unknown") for log in category_log_items)
            category_stats["by_source"] = dict(category_sources)
            category_hourly = defaultdict(int)
            for log in category_log_items:
                time_str = log.get("time", "")
                if time_str:
                    category_hourly[time_str.split(":")[0]] += 1
            category_stats["by_hour"] = dict(sorted(category_hourly.items()))
            category_daily = defaultdict(int)
            for log in category_log_items:
                date = log.get("date", "")
                if date:
                    category_daily[date] += 1
            category_stats["questions_by_date"] = dict(sorted(category_daily.items()))
            category_questions = Counter(
                log.get("question", "") for log in category_log_items if log.get("question")
            )
            category_stats["top_questions"] = [
                {"question": question, "count": count}
                for question, count in category_questions.most_common(10)
            ]
            category_stats["unanswered_question_list"] = [
                {
                    "date": log.get("date", ""),
                    "time": log.get("time", ""),
                    "source": log.get("source", "unknown"),
                    "question": log.get("question", ""),
                }
                for log in reversed(category_log_items)
                if log.get("answer_status") == "unanswered" and log.get("question")
            ][:50]
    
    return stats


@app.get("/api/logs-statistics")
def logs_statistics():
    """Return log statistics for dashboard with optional date filtering"""
    start_date = request.args.get("start_date", None)
    end_date = request.args.get("end_date", None)
    
    stats = _parse_logs(start_date=start_date, end_date=end_date)
    return jsonify(stats)


@app.get("/api/available-dates")
def available_dates():
    """Return all available dates in logs for date picker"""
    logs_dir = BASE_DIR / "logs"
    all_dates = set()
    
    # Parse JSONL file
    jsonl_file = logs_dir / "question_logs.jsonl"
    if jsonl_file.exists():
        try:
            with open(jsonl_file, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        data = json.loads(line)
                        if "date" in data:
                            all_dates.add(data["date"])
        except Exception:
            pass
    
    # Parse CSV files
    for csv_file in logs_dir.glob("*/question_logs.csv"):
        if csv_file.exists():
            try:
                with open(csv_file, "r", encoding="utf-8", newline="") as f:
                    for row in csv.DictReader(f):
                        if row.get("date"):
                            all_dates.add(row["date"])
            except Exception:
                pass
    
    sorted_dates = sorted(list(all_dates))
    
    # Get unique months
    months = set()
    for date in sorted_dates:
        try:
            month = date[:7]  # YYYY-MM format
            months.add(month)
        except Exception:
            pass
    
    return jsonify({
        "dates": sorted_dates,
        "months": sorted(list(months))
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
