@echo off
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
	echo Error: Python not found in .venv
	pause
	exit /b 1
)

".venv\Scripts\python.exe" run_app.py

pause