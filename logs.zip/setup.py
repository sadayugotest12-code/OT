from py2exe import py2exe
from distutils.core import setup

setup(
    name="MT Assistant AI",
    version="1.0",
    description="Machine Maintenance Chat Bot",
    author="Maintenance Team",
    windows=[
        {
            "script": "run_app.py",
            "dest_base": "MT-Assistant-AI",
            "icon_resources": [(1, "static/Ta/BG.png")],
        }
    ],
    zipfile=None,
    options={
        "py2exe": {
            "includes": [
                "flask",
                "langchain",
                "langchain_ollama",
                "chromadb",
                "python_docx",
                "jinja2",
                "werkzeug",
            ],
            "packages": [
                "langchain",
                "langchain_core",
                "langchain_ollama",
                "chromadb",
            ],
        }
    },
)
